# LUNA VİP SORGU v4

## Kurulum
1. `pip install -r requirements.txt`
2. `php/` klasörünü XAMPP htdocs'a at
3. `sms_bomber.php`'yi htdocs köküne at
4. `config.py` doldur
5. `python main.py`
