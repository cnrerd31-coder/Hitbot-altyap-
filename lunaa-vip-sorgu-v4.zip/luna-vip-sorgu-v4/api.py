# api.py
import json
import requests
from config import PHP_BASE


def call_php(path, params=None, timeout=120):
    url = PHP_BASE.rstrip("/") + path
    try:
        r = requests.get(url, params=params, timeout=timeout)
        r.encoding = "utf-8-sig"
        if r.status_code != 200:
            return {"success": False, "error": f"HTTP {r.status_code}"}
        ctype = r.headers.get("Content-Type", "")
        if "json" in ctype or r.text.strip().startswith(("{", "[")):
            try:
                return {"success": True, "data": r.json()}
            except Exception:
                return {"success": True, "raw": r.text}
        return {"success": True, "raw": r.text}
    except requests.Timeout:
        return {"success": False, "error": "Zaman aşımı"}
    except requests.ConnectionError:
        return {"success": False, "error": "Bağlantı hatası"}
    except Exception as e:
        return {"success": False, "error": str(e)[:200]}


def format_json(data, max_len=3500):
    try:
        s = json.dumps(data, ensure_ascii=False, indent=2)
    except Exception:
        s = str(data)
    return s[:max_len] + ("\n..." if len(s) > max_len else "")