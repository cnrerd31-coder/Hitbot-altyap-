# bot_basma.py
import requests
from config import SMM_API_URL, SMM_API_KEY, SMM_SERVICES


def send_order(platform, target_link, quantity):
    svc = SMM_SERVICES.get(platform)
    if not svc:
        return {"success": False, "error": "Bilinmeyen platform"}
    payload = {
        "key": SMM_API_KEY,
        "action": "add",
        "service": svc["service_id"],
        "link": target_link,
        "quantity": quantity,
    }
    try:
        r = requests.post(SMM_API_URL, data=payload, timeout=30)
        if r.status_code != 200:
            return {"success": False, "error": f"HTTP {r.status_code}"}
        data = r.json()
        if "order" in data:
            return {"success": True, "order_id": data["order"], "service": svc["name"]}
        return {"success": False, "error": data.get("error", "bilinmeyen hata")}
    except Exception as e:
        return {"success": False, "error": str(e)[:200]}


def get_order_status(order_id):
    payload = {"key": SMM_API_KEY, "action": "status", "order": order_id}
    try:
        r = requests.post(SMM_API_URL, data=payload, timeout=30)
        return r.json()
    except Exception as e:
        return {"error": str(e)[:200]}