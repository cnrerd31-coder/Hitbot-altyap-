<?php
header('Content-Type: application/json; charset=utf-8');

// GET parametrelerini al ve decode et
$ad = isset($_GET['ad']) ? trim(urldecode($_GET['ad'])) : '';
$soyad = isset($_GET['soyad']) ? trim(urldecode($_GET['soyad'])) : '';
$il = isset($_GET['il']) ? trim(urldecode($_GET['il'])) : '';
$ilce = isset($_GET['ilce']) ? trim(urldecode($_GET['ilce'])) : '';

// ad parametresini = ile ayırarak birleştir
$ad_parts = explode('=', $ad); // MEHMET=EMİN -> ['MEHMET', 'EMİN']
$ad = implode(' ', array_map('trim', $ad_parts)); // MEHMET EMİN

// Giriş parametrelerini logla
error_log("Giriş: ad=$ad, soyad=$soyad, il=$il, ilce=$ilce");

// Veritabanı bağlantı bilgileri
$host = "localhost";
$user = "root";
$password = ""; // Şifrenizi buraya girin
$dbname = "101m";

try {
    // PDO ile veritabanı bağlantısı
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);
} catch (PDOException $e) {
    error_log("Bağlantı Hatası: " . $e->getMessage());
    http_response_code(500);
    die(json_encode(['error' => 'Veritabanı bağlantısı başarısız: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE));
}

// Parametre doğrulama
if (empty($ad) || empty($soyad)) {
    error_log("Hata: ad ve soyad eksik.");
    http_response_code(400);
    die(json_encode(['error' => 'ad ve soyad parametreleri zorunludur.'], JSON_UNESCAPED_UNICODE));
}

// SQL sorgusu
$sql = "SELECT 
            id,
            TC AS tc,
            ADI AS ad,
            SOYADI AS soyad,
            DOGUMTARIHI AS dogum_tarihi,
            NUFUSIL AS nufus_il,
            NUFUSILCE AS nufus_ilce,
            ANNEADI AS anne_adi,
            ANNETC AS anne_tc,
            BABAADI AS baba_adi,
            BABATC AS baba_tc,
            UYRUK AS uyruk
        FROM 101m 
        WHERE ADI = :ad AND SOYADI = :soyad";
$params = [
    ':ad' => $ad,
    ':soyad' => $soyad
];

// Opsiyonel il filtresi
if (!empty($il)) {
    $sql .= " AND NUFUSIL = :il";
    $params[':il'] = $il;
}

// Opsiyonel ilce filtresi
if (!empty($ilce)) {
    $sql .= " AND NUFUSILCE = :ilce";
    $params[':ilce'] = $ilce;
}

// Sorguyu logla
error_log("SQL: $sql, Parametreler: " . json_encode($params, JSON_UNESCAPED_UNICODE));

try {
    // Sorguyu hazırla ve çalıştır
    $start = microtime(true);
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    $data = [];

    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch()) {
            // Tam eşleşme kontrolü
            if ($row['ad'] === $ad && $row['soyad'] === $soyad && (empty($il) || $row['nufus_il'] === $il) && (empty($ilce) || $row['nufus_ilce'] === $ilce)) {
                $data[] = array_map(function($value) {
                    return htmlspecialchars($value ?? 'Bulunamadı', ENT_QUOTES, 'UTF-8');
                }, $row);
                error_log("Eşleşen Kayıt: " . json_encode($row, JSON_UNESCAPED_UNICODE));
            }
        }
    }

    // Eğer veri yoksa, "Bulunamadı" yanıtı
    if (empty($data)) {
        error_log("Kayıt bulunamadı.");
        $data[] = [
            'id' => 'Bulunamadı',
            'tc' => 'Bulunamadı',
            'ad' => 'Bulunamadı',
            'soyad' => 'Bulunamadı',
            'dogum_tarihi' => 'Bulunamadı',
            'nufus_il' => 'Bulunamadı',
            'nufus_ilce' => 'Bulunamadı',
            'anne_adi' => 'Bulunamadı',
            'anne_tc' => 'Bulunamadı',
            'baba_adi' => 'Bulunamadı',
            'baba_tc' => 'Bulunamadı',
            'uyruk' => 'Bulunamadı'
        ];
    }

    // Performans loglama
    $duration = microtime(true) - $start;
    error_log("Sorgu süresi: $duration saniye");

} catch (PDOException $e) {
    error_log("Sorgu Hatası: " . $e->getMessage());
    http_response_code(500);
    die(json_encode(['error' => 'Sorgu hatası: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE));
}

// JSON çıktısı
$output = [
    'success' => true,
    'telegram' => 'Luna Vip Panel',
    'author' => 'by Luna',
    'api ismi' => 'Ad Soyad İl İlçe Sorgu',
    'data' => $data
];

echo json_encode($output, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// Bağlantıyı kapat
$conn = null;
?>