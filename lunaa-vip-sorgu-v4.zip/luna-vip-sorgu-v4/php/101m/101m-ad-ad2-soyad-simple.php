<?php
header('Content-Type: application/json; charset=utf-8');

$adi = isset($_GET['adi']) ? trim($_GET['adi']) : '';
$soyadi = isset($_GET['soyadi']) ? trim($_GET['soyadi']) : '';
$nufusil = isset($_GET['nufusil']) ? trim($_GET['nufusil']) : '';

if (!$adi || !$soyadi) {
    die(json_encode(["error" => "Ad ve soyad zorunludur."], JSON_UNESCAPED_UNICODE));
}

try {
    $conn = new mysqli("localhost", "root", "", "101m");
    $conn->set_charset("utf8mb4");
    
    // Türkçe uppercase
    $adi = mb_strtoupper($adi, 'UTF-8');
    $soyadi = mb_strtoupper($soyadi, 'UTF-8');
    $nufusil = $nufusil ? mb_strtoupper($nufusil, 'UTF-8') : '';
    
    // Ad sözcükleri ayrı ayrı
    $ad_parcalar = array_filter(explode(' ', trim($adi)));
    
    // WHERE koşulları
    $where = [];
    $params = [];
    $types = '';
    
    foreach ($ad_parcalar as $kelime) {
        $where[] = "UPPER(ADI) LIKE ?";
        $params[] = "%$kelime%";
        $types .= 's';
    }
    
    $where[] = "UPPER(SOYADI) LIKE ?";
    $params[] = "%$soyadi%";
    $types .= 's';
    
    if ($nufusil) {
        $where[] = "UPPER(NUFUSIL) = ?";
        $params[] = $nufusil;
        $types .= 's';
    }
    
    $where_clause = implode(" AND ", $where);
    
    $sql = "
        SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE,
               ANNEADI, ANNETC, BABAADI, BABATC, UYRUK
        FROM `101m`
        WHERE $where_clause
        ORDER BY ADI ASC, SOYADI ASC
        LIMIT 50000
    ";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    
    if (empty($data)) {
        echo json_encode(["success" => false, "message" => "Bulunamadı"], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(["success" => true, "data" => $data, "footer" => "API-BY-LUNA"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    
} catch (Exception $e) {
    die(json_encode(["error" => "DB Error: " . $e->getMessage()], JSON_UNESCAPED_UNICODE));
}
?>
