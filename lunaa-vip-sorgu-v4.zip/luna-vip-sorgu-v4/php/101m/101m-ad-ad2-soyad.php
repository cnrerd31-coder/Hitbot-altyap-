<?php
// 101m-ad-ad2-soyad.php → IŞIN HIZINDA + LIMITSIZ + %100 DOĞRU SONUÇ
header('Content-Type: application/json; charset=utf-8');

// Hızlı bağlantı + hata gizleme (gerekirse açarsın)
// error_reporting(0);

$conn = new mysqli("localhost", "root", "", "101m");
if ($conn->connect_error) {
    die(json_encode(["hata" => "Bağlantı hatası"]));
}
$conn->set_charset("utf8mb4");

// === BU KISIM KRİTİK: NORMALİZE ALANLAR OLUŞTUR (BİR KERE ÇALIŞTIR) ===
// Bu komutları phpMyAdmin veya terminalde 1 kez çalıştır:
// ALTER TABLE 101m ADD COLUMN IF NOT EXISTS ADI_NORM VARCHAR(255) GENERATED ALWAYS AS (UPPER(ADI)) STORED;
// ALTER TABLE 101m ADD COLUMN IF NOT EXISTS SOYADI_NORM VARCHAR(255) GENERATED ALWAYS AS (UPPER(SOYADI)) STORED;
// ALTER TABLE 101m ADD COLUMN IF NOT EXISTS NUFUSIL_NORM VARCHAR(100) GENERATED ALWAYS AS (UPPER(NUFUSIL)) STORED;
// CREATE INDEX IF NOT EXISTS idx_ara ON 101m(ADI_NORM, SOYADI_NORM, NUFUSIL_NORM);

// Eğer yukarıdaki alanlar yoksa, geçici olarak eski yöntemle çalışsın:
$use_generated = true;
$result = $conn->query("SHOW COLUMNS FROM 101m LIKE 'ADI_NORM'");
if ($result->num_rows == 0) $use_generated = false;

$adi_raw    = trim($_GET['adi'] ?? '');
$soyadi_raw = trim($_GET['soyadi'] ?? '');
$nufusil    = trim($_GET['nufusil'] ?? '');

if ($adi_raw === '' || $soyadi_raw === '') {
    die(json_encode(["hata" => "Ad ve soyad zorunlu"]));
}

// Türkçe karakterleri düzeltmeden direkt UPPER yapıyoruz (MySQL zaten hallediyor)
$ad_parcalar   = array_filter(explode(' ', mb_strtoupper($adi_raw, 'UTF-8')));
$soyadi_upper  = mb_strtoupper($soyadi_raw, 'UTF-8');
$nufusil_upper = $nufusil !== '' ? mb_strtoupper($nufusil, 'UTF-8') : null;

// Sorgu hazırlığı
$conditions = [];
$params = [];
$types = '';

foreach ($ad_parcalar as $kelime) {
    if ($use_generated) {
        $conditions[] = "ADI_NORM LIKE ?";
    } else {
        $conditions[] = "UPPER(ADI) LIKE ?";
    }
    $params[] = "%$kelime%";
    $types .= 's';
}

if ($use_generated) {
    $conditions[] = "SOYADI_NORM LIKE ?";
} else {
    $conditions[] = "UPPER(SOYADI) LIKE ?";
}
$params[] = $soyadi_upper;
$types .= 's';

if ($nufusil_upper !== null) {
    if ($use_generated) {
        $conditions[] = "NUFUSIL_NORM = ?";
    } else {
        $conditions[] = "UPPER(NUFUSIL) = ?";
    }
    $params[] = $nufusil_upper;
    $types .= 's';
}

$sql = "SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE, ANNEADI, ANNETC, BABAADI, BABATC, UYRUK 
        FROM 101m 
        WHERE " . implode(" AND ", $conditions) . " 
        ORDER BY ADI ASC";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die(json_encode(["hata" => "Sorgu hatası"]));
}

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_all(MYSQLI_ASSOC);

if (empty($data)) {
    echo json_encode(["hata" => "Sonuç bulunamadı."]);
} else {
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
}

$stmt->close();
$conn->close();
?>