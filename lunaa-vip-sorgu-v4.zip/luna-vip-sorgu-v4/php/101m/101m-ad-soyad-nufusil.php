<?php
header('Content-Type: application/json; charset=utf-8');

// GET parametrelerini al
$ad = isset($_GET['ad']) ? trim($_GET['ad']) : '';
$soyad = isset($_GET['soyad']) ? trim($_GET['soyad']) : '';
$il = isset($_GET['il']) ? trim($_GET['il']) : '';
$ilce = isset($_GET['ilce']) ? trim($_GET['ilce']) : '';

// Veritabanı bağlantı bilgileri
$host = "localhost";
$user = "root";
$password = ""; // Şifrenizi buraya girin
$dbname = "101m";

try {
    // PDO ile veritabanı bağlantısı
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password, [
        PDO::ATTR_PERSISTENT => true,
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['error' => 'Veritabanı bağlantısı başarısız.'], JSON_UNESCAPED_UNICODE));
}

// Parametre doğrulama
if ((!empty($ilce) && empty($il)) || ((!empty($il) && (empty($ad) || empty($soyad))))) {
    http_response_code(400);
    die(json_encode(['error' => 'Lütfen parametreleri doğru şekilde kullanın'], JSON_UNESCAPED_UNICODE));
}

if (empty($ad) || empty($soyad)) {
    http_response_code(400);
    die(json_encode(['error' => 'Lütfen adi ve soyadi parametrelerini girin.'], JSON_UNESCAPED_UNICODE));
}

// SQL sorgusu - Tüm alanları seç
$sql = "SELECT 
            id,
            TC AS tc,
            ADI AS ad,
            SOYADI AS soyad,
            DOGUMTARIHI AS dogum_tarihi,
            NUFUSIL AS nufus_il,
            NUFUSILCE AS nufus_ilce,
            ANNEADI AS anne_adi,
            ANNETC AS anne_tc,
            BABAADI AS baba_adi,
            BABATC AS baba_tc,
            UYRUK AS uyruk
        FROM 101m 
        WHERE 1=1";
$params = [];

// Filtreleme: ad ve soyad (tam eşleşme)
if (!empty($ad) && !empty($soyad)) {
    $sql .= " AND ADI = :ad AND SOYADI = :soyad";
    $params[':ad'] = $ad;
    $params[':soyad'] = $soyad;
}

// Opsiyonel filtreler: il ve ilce
if (!empty($il)) {
    $sql .= " AND NUFUSIL = :il";
    $params[':il'] = $il;
}
if (!empty($ilce)) {
    $sql .= " AND NUFUSILCE = :ilce";
    $params[':ilce'] = $ilce;
}

try {
    // Sorguyu hazırla ve çalıştır
    $start = microtime(true); // Performans ölçümü
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    $data = [];

    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            foreach ($row as $key => $value) {
                $row[$key] = htmlspecialchars($value ?? 'Bulunamadı', ENT_QUOTES, 'UTF-8');
            }
            $data[] = $row;
        }
    } else {
        // Varsayılan "Bulunamadı" yanıtı
        $data[] = [
            'id' => 'Bulunamadı',
            'tc' => 'Bulunamadı',
            'ad' => 'Bulunamadı',
            'soyad' => 'Bulunamadı',
            'dogum_tarihi' => 'Bulunamadı',
            'nufus_il' => 'Bulunamadı',
            'nufus_ilce' => 'Bulunamadı',
            'anne_adi' => 'Bulunamadı',
            'anne_tc' => 'Bulunamadı',
            'baba_adi' => 'Bulunamadı',
            'baba_tc' => 'Bulunamadı',
            'uyruk' => 'Bulunamadı'
        ];
    }

    // Performans loglama
    $duration = microtime(true) - $start;
    error_log("Sorgu süresi: $duration saniye");

} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['error' => 'Sorgu hatası.'], JSON_UNESCAPED_UNICODE));
}

// JSON çıktısı
$output = [
    'success' => true,
    'telegram' => 'Luna Vip Panel',
    'author' => 'by Luna',
    'api ismi' => 'Ad Soyad İl İlçe Sorgu',
    'data' => $data
];

echo json_encode($output, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// Bağlantıyı kapat
$conn = null;
?>