<?php
// GÜVENLİ AD-SOYAD SORGUSU (v2)
require_once __DIR__ . '/../config/DatabaseConnection.php';
require_once __DIR__ . '/../config/APIHelper.php';

header('Content-Type: application/json; charset=utf-8');

// Parametreleri al
$adi = APIHelper::getParam('adi', '');
$soyadi = APIHelper::getParam('soyadi', '');
$nufusil = APIHelper::getParam('nufusil', '');

if (!$adi || !$soyadi) {
    APIHelper::error('Ad ve soyad parametreleri zorunludur.');
}

try {
    $conn = DatabaseConnection::getMysqli('101m');
    
    // Türkçe karakterleri uppercase yap
    $adi = mb_strtoupper($adi, 'UTF-8');
    $soyadi = mb_strtoupper($soyadi, 'UTF-8');
    $nufusil = $nufusil ? mb_strtoupper($nufusil, 'UTF-8') : '';
    
    // Sorgu hazırla
    $where = "UPPER(ADI) LIKE ? AND UPPER(SOYADI) LIKE ?";
    $params = ["%$adi%", "%$soyadi%"];
    $types = "ss";
    
    if ($nufusil) {
        $where .= " AND UPPER(NUFUSIL) = ?";
        $params[] = $nufusil;
        $types .= "s";
    }
    
    $sql = "
        SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE,
               ANNEADI, ANNETC, BABAADI, BABATC, UYRUK
        FROM `101m`
        WHERE $where
        ORDER BY ADI ASC, SOYADI ASC
        LIMIT 10000
    ";
    
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        throw new Exception("Sorgu hazırlanırken hata: " . $conn->error);
    }
    
    // Parametreleri bind et (dinamik)
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    
    if (empty($data)) {
        APIHelper::response(false, null, 'Sonuç bulunamadı.');
    }
    
    APIHelper::response(true, $data, null, 'API-BY-LUNA');
    
} catch (Exception $e) {
    APIHelper::error('Sorgu hatası', $e->getMessage());
}
?>
