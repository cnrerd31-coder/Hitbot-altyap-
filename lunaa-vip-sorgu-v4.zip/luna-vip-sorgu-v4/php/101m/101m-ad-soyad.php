<?php
// Veritabanı bağlantı bilgileri
$servername = "localhost";
$username = "root";
$password = ""; // MySQL root kullanıcısının şifresi
$dbname = "101m"; // Veritabanı adı

// Veritabanına bağlan
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die(json_encode(["error" => "Veritabanı bağlantısı başarısız: " . $conn->connect_error], JSON_PRETTY_PRINT));
}

// API'yi kullanarak sorgulama parametrelerini al
$adi = $_GET['adi'] ?? '';
$soyadi = $_GET['soyadi'] ?? '';
$nufusil = $_GET['nufusil'] ?? '';

if ($adi && $soyadi) {
    // ADI ve SOYADI parametrelerine göre veritabanında arama yap
    if ($nufusil) {
        $stmt = $conn->prepare("SELECT * FROM `101m` WHERE ADI = ? AND SOYADI = ? AND NUFUSIL = ?");
        $stmt->bind_param("sss", $adi, $soyadi, $nufusil);
    } else {
        $stmt = $conn->prepare("SELECT * FROM `101m` WHERE ADI = ? AND SOYADI = ?");
        $stmt->bind_param("ss", $adi, $soyadi);
    }
    
    if ($stmt === false) {
        die(json_encode(["error" => "SQL sorgusu hazırlanırken hata oluştu: " . $conn->error], JSON_PRETTY_PRINT));
    }

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result === false) {
        die(json_encode(["error" => "SQL sorgusu çalıştırılırken hata oluştu: " . $stmt->error], JSON_PRETTY_PRINT));
    }

    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }

    header('Content-Type: application/json');
    if (empty($users)) {
        echo json_encode(["error" => "Belirtilen kriterlere ait kayıt bulunamadı."], JSON_PRETTY_PRINT);
    } else {
        echo json_encode($users, JSON_PRETTY_PRINT);
    }

    // Prepared statement'i kapat
    $stmt->close();
} else {
    echo json_encode(["error" => "Lütfen adi ve soyadi parametrelerini girin."], JSON_PRETTY_PRINT);
}

// Veritabanı bağlantısını kapat
$conn->close();
?>