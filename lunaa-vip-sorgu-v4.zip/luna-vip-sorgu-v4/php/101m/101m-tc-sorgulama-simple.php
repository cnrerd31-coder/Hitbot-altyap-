<?php
header('Content-Type: application/json; charset=utf-8');

$tc = isset($_GET['tc']) ? trim($_GET['tc']) : '';

if (!$tc || !preg_match('/^\d{11}$/', $tc)) {
    die(json_encode(["error" => "Geçersiz TC numarası."], JSON_UNESCAPED_UNICODE));
}

try {
    $conn = new mysqli("localhost", "root", "", "101m");
    $conn->set_charset("utf8mb4");
    
    $stmt = $conn->prepare("
        SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE,
               ANNEADI, ANNETC, BABAADI, BABATC, UYRUK
        FROM `101m`
        WHERE TC = ?
        LIMIT 1
    ");
    
    $stmt->bind_param("s", $tc);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(["success" => false, "message" => "Bulunamadı"], JSON_UNESCAPED_UNICODE);
    } else {
        $data = $result->fetch_assoc();
        echo json_encode(["success" => true, "data" => $data, "footer" => "API-BY-LUNA  "], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    
} catch (Exception $e) {
    die(json_encode(["error" => "DB Error: " . $e->getMessage()], JSON_UNESCAPED_UNICODE));
}
?>
