<?php
// Veritabanı bağlantı bilgileri
$servername = "localhost";
$username = "root";
$password = ""; // MySQL root kullanıcısının şifresi
$dbname = "101m"; // Veritabanı adı

// Veritabanına bağlan
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die(json_encode(["error" => "Veritabanı bağlantısı başarısız: " . $conn->connect_error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// API'yi kullanarak sorgulama parametrelerini al
$tc = $_GET['tc'] ?? '';

if ($tc) {
    $all_users = [];
    $visited_tcs = [];
    $tc_queue = [$tc];

    while (!empty($tc_queue)) {
        $current_tc = array_shift($tc_queue);

        // Ziyaret edilen TC numaralarını kontrol et
        if (in_array($current_tc, $visited_tcs)) {
            continue;
        }
        
        // TC numarasına göre veritabanında arama yap
        $stmt = $conn->prepare("SELECT * FROM `101m` WHERE TC = ?");
        if ($stmt === false) {
            die(json_encode(["error" => "SQL sorgusu hazırlanırken hata oluştu: " . $conn->error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }

        $stmt->bind_param("s", $current_tc);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result === false) {
            die(json_encode(["error" => "SQL sorgusu çalıştırılırken hata oluştu: " . $stmt->error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }

        while ($row = $result->fetch_assoc()) {
            $all_users[] = $row;

            // Anne ve baba TC numaralarını sorgu kuyruğuna ekle
            if (!empty($row['ANNETC']) && !in_array($row['ANNETC'], $visited_tcs)) {
                $tc_queue[] = $row['ANNETC'];
            }
            if (!empty($row['BABATC']) && !in_array($row['BABATC'], $visited_tcs)) {
                $tc_queue[] = $row['BABATC'];
            }
        }

        // Ziyaret edilen TC numarasını işaretle
        $visited_tcs[] = $current_tc;
    }

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($all_users, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    // Prepared statement'i kapat
    $stmt->close();
} else {
    echo json_encode(["error" => "Lütfen bir TC numarası girin."], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

// Veritabanı bağlantısını kapat
$conn->close();
?>