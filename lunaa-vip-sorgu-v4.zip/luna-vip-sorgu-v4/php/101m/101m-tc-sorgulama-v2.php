<?php
// GÜVENLİ TC SORGUSU (v2)
require_once __DIR__ . '/../config/DatabaseConnection.php';
require_once __DIR__ . '/../config/APIHelper.php';

header('Content-Type: application/json; charset=utf-8');

// TC'yi al ve doğrula
$tc = APIHelper::getParam('tc', '', '/^\d{11}$/');

if (!$tc) {
    APIHelper::error('Geçersiz TC numarası. 11 haneli sayı girin.');
}

try {
    $conn = DatabaseConnection::getMysqli('101m');
    
    // Prepared statement kullan
    $stmt = $conn->prepare("
        SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE, 
               ANNEADI, ANNETC, BABAADI, BABATC, UYRUK
        FROM `101m` 
        WHERE TC = ?
        LIMIT 1
    ");
    
    if (!$stmt) {
        throw new Exception("Sorgu hazırlanırken hata: " . $conn->error);
    }
    
    $stmt->bind_param("s", $tc);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        APIHelper::response(false, null, 'Bu TC numarasına ait kayıt bulunamadı.');
    }
    
    $data = $result->fetch_assoc();
    APIHelper::response(true, $data, null, 'API-BY-LUNA');
    
} catch (Exception $e) {
    APIHelper::error('Sorgu hatası', $e->getMessage());
}
?>
