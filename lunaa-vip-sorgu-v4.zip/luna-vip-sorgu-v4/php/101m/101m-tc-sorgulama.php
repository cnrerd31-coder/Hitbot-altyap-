<?php
// Veritabanı bağlantı bilgileri
$servername = "localhost";
$username = "root";
$password = ""; // MySQL root kullanıcısının şifresi
$dbname = "101m"; // Veritabanı adı

// Veritabanına bağlan
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die(json_encode(["error" => "Veritabanı bağlantısı başarısız: " . $conn->connect_error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// API'yi kullanarak sorgulama parametrelerini al
$tc = $_GET['tc'] ?? '';

if ($tc) {
    // TC parametresine göre veritabanında arama yap
    $stmt = $conn->prepare("SELECT * FROM `101m` WHERE TC = ?");
    if ($stmt === false) {
        die(json_encode(["error" => "SQL sorgusu hazırlanırken hata oluştu: " . $conn->error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    $stmt->bind_param("s", $tc);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result === false) {
        die(json_encode(["error" => "SQL sorgusu çalıştırılırken hata oluştu: " . $stmt->error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    $users = [];
    while ($row = $result->fetch_assoc()) {
        // Verileri okunabilir hale getir
        $users[] = [
            "ID" => $row["id"],
            "TC Kimlik Numarası" => $row["TC"],
            "Adı" => $row["ADI"],
            "Soyadı" => $row["SOYADI"],
            "Doğum Tarihi" => $row["DOGUMTARIHI"],
            "Nüfus İl" => $row["NUFUSIL"],
            "Nüfus İlçe" => $row["NUFUSILCE"],
            "Anne Adı" => $row["ANNEADI"],
            "Anne TC" => $row["ANNETC"],
            "Baba Adı" => $row["BABAADI"],
            "Baba TC" => $row["BABATC"],
            "Uyruk" => $row["UYRUK"] ?? "Bilinmiyor"
        ];
    }

    header('Content-Type: application/json');
    if (empty($users)) {
        echo json_encode(["error" => "Belirtilen TC numarasına ait kayıt bulunamadı.", "footer" => "API-BY-LUNA"], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(["data" => $users, "footer" => "API-BY-LUNA"], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }

    // Prepared statement'i kapat
    $stmt->close();
} else {
    echo json_encode(["error" => "Lütfen bir TC numarası girin.", "footer" => "API-BY-LUNA"], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

// Veritabanı bağlantısını kapat
$conn->close();
?>