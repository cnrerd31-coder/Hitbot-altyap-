﻿<?php

header("Content-Type: application/json; charset=utf-8");

$host = "localhost";
$dbname = "101m";
$user = "root";
$password = "";

try {
    $link = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "server error"]);
    die();
}

ini_set("display_errors", 0);
error_reporting(0);

function fetch_data($link, $sql, $params) {
    $stmt = $link->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

if (isset($_GET['tc'])) {
    $tc = htmlspecialchars($_GET['tc']);
    
    $sqlSelf = "SELECT * FROM `101m` WHERE `TC` = :tc";
    $resultArraySelf = fetch_data($link, $sqlSelf, ['tc' => $tc]);

    if (empty($resultArraySelf)) {
        echo json_encode(["success" => false, "message" => "not found"]);
        die();
    }

    $rowSelf = $resultArraySelf[0];
    $rowSelf["Yakınlık"] = "Kendi";

    $annesiTC = $rowSelf['ANNETC'];
    $babasiTC = $rowSelf['BABATC'];

    $sqlMother = "SELECT * FROM `101m` WHERE `TC` = :tc";
    $motherArray = fetch_data($link, $sqlMother, ['tc' => $annesiTC]);
    foreach ($motherArray as &$row) {
        $row["Yakınlık"] = "Anne";
    }

    $sqlSiblings = "SELECT * FROM `101m` WHERE `ANNETC` = :tc AND `TC` != :self_tc";
    $siblingsArray = fetch_data($link, $sqlSiblings, ['tc' => $annesiTC, 'self_tc' => $tc]);
    foreach ($siblingsArray as &$row) {
        $row["Yakınlık"] = "Kardeş";
    }

    $sqlChildren = "SELECT * FROM `101m` WHERE `BABATC` = :tc OR `ANNETC` = :tc";
    $childrenArray = fetch_data($link, $sqlChildren, ['tc' => $tc]);
    foreach ($childrenArray as &$row) {
        $row["Yakınlık"] = "Çocuk";
    }

    $sqlFather = "SELECT * FROM `101m` WHERE `TC` = :tc";
    $fatherArray = fetch_data($link, $sqlFather, ['tc' => $babasiTC]);
    foreach ($fatherArray as &$row) {
        $row["Yakınlık"] = "Baba";
    }

    $allData = array_merge([$rowSelf], $motherArray, $siblingsArray, $childrenArray, $fatherArray);

    echo json_encode([
        "success" => true,
        "data" => $allData,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    die();
}
?>