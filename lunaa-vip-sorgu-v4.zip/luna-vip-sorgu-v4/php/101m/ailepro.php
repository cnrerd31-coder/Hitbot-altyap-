﻿<?php

header("Content-Type: application/json; charset=utf-8");

$host = "localhost";
$dbname = "101m";
$user = "root";
$password = "";

try {
    $link = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "server error"]);
    die();
}

ini_set("display_errors", 0);
error_reporting(0);

function fetch_data($link, $sql, $params) {
    $stmt = $link->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// GSM verisini çeken fonksiyon
function fetch_gsm($tc) {
    $url = "http://localhost/116m/gsm2024.php?value=" . urlencode($tc);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    $response = curl_exec($ch);

    if (curl_errno($ch) || !$response) {
        curl_close($ch);
        return ["Bulunamadı"];
    }

    curl_close($ch);

    $json = json_decode($response, true);

    if (!is_array($json) || isset($json["error"])) {
        return ["Bulunamadı"];
    }

    $gsm_list = [];

    foreach ($json as $item) {
        if (isset($item["GSM"]) && !empty($item["GSM"])) {
            $gsm_list[] = $item["GSM"];
        }
    }

    return !empty($gsm_list) ? $gsm_list : ["Bulunamadı"];
}

// Anahtarları sıralayan ve "id" kaldıran fonksiyon
function reorder_keys($arr) {
    if (isset($arr['id'])) {
        unset($arr['id']);
    }

    $order = ["Yakınlık", "TC", "ADI", "SOYADI", "DOGUMTARIHI", "NUFUSIL", "NUFUSILCE", "ANNEADI", "ANNETC", "BABAADI", "BABATC", "UYRUK", "GSM"];
    $newArr = [];
    foreach ($order as $key) {
        if (isset($arr[$key])) {
            $newArr[$key] = $arr[$key];
        }
    }
    // Sırada olmayan varsa sona ekle
    foreach ($arr as $key => $value) {
        if (!in_array($key, $order)) {
            $newArr[$key] = $value;
        }
    }
    return $newArr;
}

if (isset($_GET['tc'])) {
    $tc = htmlspecialchars($_GET['tc']);

    $sqlSelf = "SELECT * FROM `101m` WHERE `TC` = :tc";
    $resultArraySelf = fetch_data($link, $sqlSelf, ['tc' => $tc]);

    if (empty($resultArraySelf)) {
        echo json_encode(["success" => false, "message" => "not found"]);
        die();
    }

    $rowSelf = $resultArraySelf[0];
    $rowSelf["Yakınlık"] = "Kendi";
    $rowSelf["GSM"] = fetch_gsm($rowSelf["TC"]);
    $rowSelf = reorder_keys($rowSelf);

    $annesiTC = $rowSelf['ANNETC'];
    $babasiTC = $rowSelf['BABATC'];

    // Anne
    $motherArray = fetch_data($link, "SELECT * FROM `101m` WHERE `TC` = :tc", ['tc' => $annesiTC]);
    foreach ($motherArray as &$row) {
        $row["Yakınlık"] = "Anne";
        $row["GSM"] = fetch_gsm($row["TC"]);
        $row = reorder_keys($row);
    }

    // Baba
    $fatherArray = fetch_data($link, "SELECT * FROM `101m` WHERE `TC` = :tc", ['tc' => $babasiTC]);
    foreach ($fatherArray as &$row) {
        $row["Yakınlık"] = "Baba";
        $row["GSM"] = fetch_gsm($row["TC"]);
        $row = reorder_keys($row);
    }

    // Kardeşler
    $siblingsArray = fetch_data($link, "SELECT * FROM `101m` WHERE `ANNETC` = :tc AND `TC` != :self_tc", [
        'tc' => $annesiTC,
        'self_tc' => $tc
    ]);
    foreach ($siblingsArray as &$row) {
        $row["Yakınlık"] = "Kardeş";
        $row["GSM"] = fetch_gsm($row["TC"]);
        $row = reorder_keys($row);
    }

    // Çocuklar
    $childrenArray = fetch_data($link, "SELECT * FROM `101m` WHERE `BABATC` = :tc OR `ANNETC` = :tc", ['tc' => $tc]);
    foreach ($childrenArray as &$row) {
        $row["Yakınlık"] = "Çocuk";
        $row["GSM"] = fetch_gsm($row["TC"]);
        $row = reorder_keys($row);
    }

    $allData = array_merge([$rowSelf], $motherArray, $fatherArray, $siblingsArray, $childrenArray);

    echo json_encode([
        "success" => true,
        "data" => $allData,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    die();
}
?>
