<?php
// GÜVENLİ SOY AĞACI SORGUSU (v2)
// HTML çıktısından JSON çıktısına geçiş
require_once __DIR__ . '/../config/DatabaseConnection.php';
require_once __DIR__ . '/../config/APIHelper.php';

header('Content-Type: application/json; charset=utf-8');

// Parametreleri al
$key = APIHelper::getParam('key', '');
$tc = APIHelper::getParam('tc', '', '/^\d{11}$/');

// Anahtar kontrolü
if ($key !== 'lunaxcarma') {
    APIHelper::error('Geçersiz anahtar.');
}

if (!$tc) {
    APIHelper::error('Geçersiz TC numarası.');
}

try {
    $conn = DatabaseConnection::getMysqli('101m');
    
    // Ana kişiyi bul
    $stmt = $conn->prepare("
        SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE,
               ANNEADI, ANNETC, BABAADI, BABATC, UYRUK
        FROM `101m`
        WHERE TC = ?
        LIMIT 1
    ");
    
    $stmt->bind_param("s", $tc);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        APIHelper::response(false, null, 'TC bulunamadı.');
    }
    
    $self = $result->fetch_assoc();
    $self['Yakınlık'] = 'KENDİSİ';
    
    // Sonuç verileri
    $data = [$self];
    
    // Çocuklarını bul (her iki ebeveyn de olabilir)
    $stmt = $conn->prepare("
        SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE,
               ANNEADI, ANNETC, BABAADI, BABATC, UYRUK
        FROM `101m`
        WHERE BABATC = ? OR ANNETC = ?
    ");
    $stmt->bind_param("ss", $tc, $tc);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $row['Yakınlık'] = 'ÇOCUĞU';
        $data[] = $row;
    }
    
    // Kardeşlerini bul (aynı ebeveynler)
    $annesi = $self['ANNETC'];
    $babasi = $self['BABATC'];
    
    if ($annesi || $babasi) {
        $stmt = $conn->prepare("
            SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE,
                   ANNEADI, ANNETC, BABAADI, BABATC, UYRUK
            FROM `101m`
            WHERE TC != ? AND (ANNETC = ? OR BABATC = ?)
        ");
        $stmt->bind_param("sss", $tc, $annesi, $babasi);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $row['Yakınlık'] = 'KARDEŞİ';
            $data[] = $row;
        }
    }
    
    // Ebeveynleri bul
    if ($annesi) {
        $stmt = $conn->prepare("
            SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE,
                   ANNEADI, ANNETC, BABAADI, BABATC, UYRUK
            FROM `101m`
            WHERE TC = ?
        ");
        $stmt->bind_param("s", $annesi);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $row['Yakınlık'] = 'ANASI';
            $data[] = $row;
        }
    }
    
    if ($babasi) {
        $stmt = $conn->prepare("
            SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE,
                   ANNEADI, ANNETC, BABAADI, BABATC, UYRUK
            FROM `101m`
            WHERE TC = ?
        ");
        $stmt->bind_param("s", $babasi);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $row['Yakınlık'] = 'BABASI';
            $data[] = $row;
        }
    }
    
    APIHelper::response(true, $data, null, 'API-BY-LUNA');
    
} catch (Exception $e) {
    APIHelper::error('Sorgu hatası', $e->getMessage());
}
?>
