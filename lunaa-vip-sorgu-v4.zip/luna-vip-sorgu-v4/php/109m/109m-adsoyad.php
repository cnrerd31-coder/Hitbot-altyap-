<?php
header('Content-Type: application/json; charset=utf-8');

$startTime = microtime(true);

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$ad = isset($_GET['ad']) ? trim($_GET['ad']) : '';
$soyad = isset($_GET['soyad']) ? trim($_GET['soyad']) : '';
$il = isset($_GET['il']) ? trim($_GET['il']) : '';

$host = "localhost";
$user = "root";
$password = "";
$dbname = "109m";

// Optional: File-based caching
$cacheKey = md5($ad . $soyad . $il);
$cacheFile = "cache/$cacheKey.json";
if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 3600) {
    echo file_get_contents($cacheFile);
    exit;
}

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password, [
        PDO::ATTR_PERSISTENT => true,
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    $response = [
        'ap-by' => 'Luna',
        'executionTime' => '0.000 saniye',
        'status' => 'error',
        'totalCount' => 0,
        'data' => [],
        'error' => 'Veritabanı bağlantısı başarısız.'
    ];
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

if (!empty($il) && (empty($ad) || empty($soyad))) {
    $response = [
        'ap-by' => 'Luna',
        'executionTime' => '0.000 saniye',
        'status' => 'error',
        'totalCount' => 0,
        'data' => [],
        'error' => 'Lütfen parametreleri doğru şekilde kullanın'
    ];
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

$sql = "SELECT ID, TC, AD, SOYAD, GSM, BABAADI, BABATC, ANNEADI, ANNETC, DOGUMTARIHI, OLUMTARIHI, DOGUMYERI, MEMLEKETIL, MEMLEKETILCE, MEMLEKETKOY, ADRESIL, AILESIRANO, BIREYSIRANO, MEDENIHAL, CINSIYET FROM 109m WHERE 1=1";
$params = [];

if (!empty($ad) && !empty($soyad)) {
    $sql .= " AND AD = :ad AND SOYAD = :soyad";
    $params[':ad'] = $ad;
    $params[':soyad'] = $soyad;
}

if (!empty($il)) {
    $sql .= " AND ADRESIL = :il";
    $params[':il'] = $il;
}

try {
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    $data = [];
    $sira = 1;
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if ($rows) {
        foreach ($rows as $row) {
            $row['sira'] = $sira++;
            $data[] = $row;
        }
    } else {
        $data[] = [
            'ID' => 'Bulunamadı',
            'TC' => 'Bulunamadı',
            'AD' => 'Bulunamadı',
            'SOYAD' => 'Bulunamadı',
            'GSM' => 'Bulunamadı',
            'BABAADI' => 'Bulunamadı',
            'BABATC' => 'Bulunamadı',
            'ANNEADI' => 'Bulunamadı',
            'ANNETC' => 'Bulunamadı',
            'DOGUMTARIHI' => 'Bulunamadı',
            'OLUMTARIHI' => 'Bulunamadı',
            'DOGUMYERI' => 'Bulunamadı',
            'MEMLEKETIL' => 'Bulunamadı',
            'MEMLEKETILCE' => 'Bulunamadı',
            'MEMLEKETKOY' => 'Bulunamadı',
            'ADRESIL' => 'Bulunamadı',
            'AILESIRANO' => 'Bulunamadı',
            'BIREYSIRANO' => 'Bulunamadı',
            'MEDENIHAL' => 'Bulunamadı',
            'CINSIYET' => 'Bulunamadı',
            'sira' => $sira
        ];
    }

    $executionTime = microtime(true) - $startTime;
    $response = [
        'ap-by' => 'Luna',
        'executionTime' => number_format($executionTime, 3) . ' saniye',
        'status' => 'success',
        'totalCount' => count($rows) ?: 1,
        'data' => $data
    ];

    if (!is_dir('cache')) mkdir('cache', 0755, true);
    file_put_contents($cacheFile, json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    $response = [
        'ap-by' => 'Luna',
        'executionTime' => '0.000 saniye',
        'status' => 'error',
        'totalCount' => 0,
        'data' => [],
        'error' => 'Sorgu hatası.'
    ];
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

$conn = null;
?>