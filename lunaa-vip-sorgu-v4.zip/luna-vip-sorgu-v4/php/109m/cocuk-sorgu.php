﻿<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = ""; // Update this with your database password
$dbname = "109m"; // Update this with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the TC from the query parameters
$tc = isset($_GET['tc']) ? $_GET['tc'] : null;

// Default data structure with "Bulunamadı"
$defaultData = array(
    'TC' => 'Bulunamadı',
    'AD' => 'Bulunamadı',
    'SOYAD' => 'Bulunamadı',
    'GSM' => 'Bulunamadı',
    'BABAADI' => 'Bulunamadı',
    'BABATC' => 'Bulunamadı',
    'ANNEADI' => 'Bulunamadı',
    'ANNETC' => 'Bulunamadı',
    'DOGUMTARIHI' => 'Bulunamadı',
    'OLUMTARIHI' => 'Bulunamadı',
    'DOGUMYERI' => 'Bulunamadı',
    'MEMLEKETIL' => 'Bulunamadı',
    'MEMLEKETILCE' => 'Bulunamadı',
    'MEMLEKETKOY' => 'Bulunamadı',
    'ADRESIL' => 'Bulunamadı',
    'ADRESILCE' => 'Bulunamadı',
    'AILESIRANO' => 'Bulunamadı',
    'BIREYSIRANO' => 'Bulunamadı',
    'MEDENIHAL' => 'Bulunamadı',
    'CINSIYET' => 'Bulunamadı'
);

if ($tc) {
    // Query the database to find matches for the given TC
    $stmt = $conn->prepare("SELECT * FROM 109m WHERE TC = ? OR ANNETC = ? OR BABATC = ?");
    $stmt->bind_param("sss", $tc, $tc, $tc);
    $stmt->execute();
    $result = $stmt->get_result();

    // Prepare the response array
    $response = [];

    if ($result->num_rows > 0) {
        // Loop through all matching rows
        while ($row = $result->fetch_assoc()) {
            $response[] = array(
                'TC' => $row['TC'] ?? 'Bulunamadı',
                'AD' => $row['AD'] ?? 'Bulunamadı',
                'SOYAD' => $row['SOYAD'] ?? 'Bulunamadı',
                'GSM' => $row['GSM'] ?? 'Bulunamadı',
                'BABAADI' => $row['BABAADI'] ?? 'Bulunamadı',
                'BABATC' => $row['BABATC'] ?? 'Bulunamadı',
                'ANNEADI' => $row['ANNEADI'] ?? 'Bulunamadı',
                'ANNETC' => $row['ANNETC'] ?? 'Bulunamadı',
                'DOGUMTARIHI' => $row['DOGUMTARIHI'] ?? 'Bulunamadı',
                'OLUMTARIHI' => $row['OLUMTARIHI'] ?? 'Bulunamadı',
                'DOGUMYERI' => $row['DOGUMYERI'] ?? 'Bulunamadı',
                'MEMLEKETIL' => $row['MEMLEKETIL'] ?? 'Bulunamadı',
                'MEMLEKETILCE' => $row['MEMLEKETILCE'] ?? 'Bulunamadı',
                'MEMLEKETKOY' => $row['MEMLEKETKOY'] ?? 'Bulunamadı',
                'ADRESIL' => $row['ADRESIL'] ?? 'Bulunamadı',
                'ADRESILCE' => $row['ADRESILCE'] ?? 'Bulunamadı',
                'AILESIRANO' => $row['AILESIRANO'] ?? 'Bulunamadı',
                'BIREYSIRANO' => $row['BIREYSIRANO'] ?? 'Bulunamadı',
                'MEDENIHAL' => $row['MEDENIHAL'] ?? 'Bulunamadı',
                'CINSIYET' => $row['CINSIYET'] ?? 'Bulunamadı'
            );
        }
    } else {
        // If no results found, return the default data structure
        $response[] = $defaultData;
    }

    $stmt->close();
} else {
    // If no TC is provided, return an error
    $response = ["error" => "Please provide a TC number in the query string. Example: ?tc=19214110122"];
}

// Output the data as JSON
header('Content-Type: application/json');
echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

$conn->close();
?>