﻿<?php
header('Content-Type: application/json');

// Veritabanı bağlantısı için bilgiler
$host = "localhost";
$dbname = "109m";
$user = "root";
$password = "";

// Veritabanına bağlan
try {
    // Kalıcı bağlantı ve hata yönetimi için PDO ayarları
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, // Hata modu
        PDO::ATTR_PERSISTENT => true // Kalıcı bağlantı
    ]);
} catch (PDOException $e) {
    // Veritabanı bağlantısı hatası
    echo json_encode(['success' => false, 'message' => 'Veritabanı bağlantısı başarısız.']);
    exit;
}

// Kullanıcıdan GSM parametresini al
if (empty($_GET['gsm'])) {
    echo json_encode(['success' => false, 'message' => 'GSM parametresi gereklidir.']);
    exit;
}

$gsm = $_GET['gsm'];

// GSM formatını doğrula
if (!preg_match('/^\d{10,15}$/', $gsm)) {
    echo json_encode(['success' => false, 'message' => 'Lütfen geçerli bir GSM numarası giriniz.']);
    exit;
}

// Veritabanında GSM numarasına göre sorgu yap
try {
    // Sadece gerekli sütunları sorgula ve LIMIT 1 ekle
    $stmt = $pdo->prepare("SELECT ID, TC, AD, SOYAD, GSM FROM `109m` WHERE `GSM` = :gsm LIMIT 1");
    $stmt->bindParam(':gsm', $gsm, PDO::PARAM_STR);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        // Başarılı bir şekilde veri bulundu
        echo json_encode(['success' => true, 'data' => $result], JSON_UNESCAPED_UNICODE);
    } else {
        // Kayıt bulunamadı
        echo json_encode(['success' => false, 'message' => 'Belirtilen GSM için kayıt bulunamadı.']);
    }
} catch (PDOException $e) {
    // Sorgu sırasında hata oluştu
    echo json_encode(['success' => false, 'message' => 'Bir hata oluştu. Lütfen tekrar deneyin.']);
}
?>