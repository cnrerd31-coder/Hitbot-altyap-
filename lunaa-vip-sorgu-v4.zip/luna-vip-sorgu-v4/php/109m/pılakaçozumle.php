<?php
// Veritabanı bağlantı bilgileri
$servername = "localhost";
$username = "root";
$password = ""; // MySQL root kullanıcısının şifresi
$dbname = "101m"; // Veritabanı adı

// Veritabanına bağlan
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die(json_encode(["error" => "Veritabanı bağlantısı başarısız: " . $conn->connect_error], JSON_PRETTY_PRINT));
}

// API'yi kullanarak sorgulama parametrelerini al
$tc_adsoyad = $_GET['tc'] ?? '';
if ($tc_adsoyad) {
    // TC ve ad-soyad bilgilerini ayır
    list($tc, $adsoyad) = explode(' ', $tc_adsoyad);
    
    // TC numarasının ilk iki ve son iki hanesini al
    $tc_start = substr($tc, 0, 2);
    $tc_end = substr($tc, -2);

    // Ad ve soyadın ilk harflerini al
    list($ad, $soyad) = explode('*', $adsoyad);
    $ad = substr(trim($ad), 0, 1);
    $soyad = substr(trim($soyad), 0, 1);

    // İlk iki ve son iki haneye göre veritabanında arama yap
    $stmt = $conn->prepare("SELECT * FROM `101m` WHERE TC LIKE CONCAT(?, '%', ?) AND ADI LIKE CONCAT(?, '%') AND SOYADI LIKE CONCAT(?, '%')");
    if ($stmt === false) {
        die(json_encode(["error" => "SQL sorgusu hazırlanırken hata oluştu: " . $conn->error], JSON_PRETTY_PRINT));
    }

    $stmt->bind_param("ssss", $tc_start, $tc_end, $ad, $soyad);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result === false) {
        die(json_encode(["error" => "SQL sorgusu çalıştırılırken hata oluştu: " . $stmt->error], JSON_PRETTY_PRINT));
    }

    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }

    header('Content-Type: application/json');
    if (empty($users)) {
        echo json_encode(["error" => "Belirtilen kriterlere ait kayıt bulunamadı."], JSON_PRETTY_PRINT);
    } else {
        echo json_encode($users, JSON_PRETTY_PRINT);
    }

    // Prepared statement'i kapat
    $stmt->close();
} else {
    echo json_encode(["error" => "Lütfen bir TC numarası ve ad soyad girin."], JSON_PRETTY_PRINT);
}

// Veritabanı bağlantısını kapat
$conn->close();
?>