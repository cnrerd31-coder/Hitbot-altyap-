﻿<?php
header('Content-Type: application/json'); // JSON yanıtı için başlık ayarlama

// Veritabanı bağlantı bilgileri
$host = "localhost";
$dbname = "109m";
$user = "root";
$password = "";

try {
    // Veritabanı bağlantısı
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['error' => 'Veritabanı bağlantısı başarısız: ' . $e->getMessage()]));
}

// HTML özel karakterlerinden arındırma fonksiyonu
function sanitize_output($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

// TC kimlik numarasını alma ve doğrulama
$tc = isset($_GET['tc']) ? strip_tags($_GET['tc']) : '';

if (empty($tc) || !preg_match('/^\d{11}$/', $tc)) {
    $hata = array('success' => false, 'message' => 'Lütfen 11 haneli geçerli bir TC kimlik numarası giriniz');
    echo json_encode($hata, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // 109m veritabanından veri çekme
    $sql = "SELECT TC, AD AS ADI, SOYAD AS SOYADI, ANNEADI, ANNETC, BABAADI, BABATC, DOGUMTARIHI, OLUMTARIHI, DOGUMYERI, MEMLEKETIL, MEMLEKETILCE, MEMLEKETKOY, ADRESIL, ADRESILCE, AILESIRANO, BIREYSIRANO, MEDENIHAL, CINSIYET, GSM FROM 109m WHERE TC = :tc";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':tc', $tc, PDO::PARAM_STR);
    $stmt->execute();

    // Varsayılan değerler
    $data = array(
        'TC' => 'Bulunamadı',
        'AD' => 'Bulunamadı',
        'SOYAD' => 'Bulunamadı',
        'GSM' => 'Bulunamadı',
        'BABAADI' => 'Bulunamadı',
        'BABATC' => 'Bulunamadı',
        'ANNEADI' => 'Bulunamadı',
        'ANNETC' => 'Bulunamadı',
        'DOGUMTARIHI' => 'Bulunamadı',
        'OLUMTARIHI' => 'Bulunamadı',
        'DOGUMYERI' => 'Bulunamadı',
        'MEMLEKETIL' => 'Bulunamadı',
        'MEMLEKETILCE' => 'Bulunamadı',
        'MEMLEKETKOY' => 'Bulunamadı',
        'ADRESIL' => 'Bulunamadı',
        'ADRESILCE' => 'Bulunamadı',
        'AILESIRANO' => 'Bulunamadı',
        'BIREYSIRANO' => 'Bulunamadı',
        'MEDENIHAL' => 'Bulunamadı',
        'CINSIYET' => 'Bulunamadı'
    );

    if ($stmt->rowCount() > 0) {
        $data = $stmt->fetch(PDO::FETCH_ASSOC); // Veriyi al
        foreach ($data as $key => $value) {
            $data[$key] = sanitize_output($value) ?: 'Bulunamadı'; // Veriyi temizle ve boşsa 'Bulunamadı' yap
        }
    }

    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE, 4);

} catch (PDOException $e) {
    echo json_encode(['error' => 'Sorgu hatası: ' . $e->getMessage()]);
}

// Veritabanı bağlantısını kapatma
$conn = null;
?>