﻿<?php
header('Content-Type: application/json');

$host1 = "localhost";
$dbname1 = "109m";
$user1 = "root";
$password1 = "";

$host2 = "localhost";
$dbname2 = "82m";
$user2 = "root";
$password2 = "";

try {
    $conn1 = new PDO("mysql:host=$host1;dbname=$dbname1;charset=utf8", $user1, $password1);
    $conn1->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['error' => 'Birinci veritabanı bağlantısı başarısız: ' . $e->getMessage()]));
}

try {
    $conn2 = new PDO("mysql:host=$host2;dbname=$dbname2;charset=utf8", $user2, $password2);
    $conn2->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['error' => 'İkinci veritabanı bağlantısı başarısız: ' . $e->getMessage()]));
}

function sanitize_output($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

$tc = isset($_GET['tc']) ? strip_tags($_GET['tc']) : '';

if (empty($tc) || !preg_match('/^\d{11}$/', $tc)) {
    $hata = array('success' => false, 'message' => 'Lütfen 11 haneli geçerli bir TC kimlik numarası giriniz.');
    echo json_encode($hata, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $sql1 = "SELECT TC, AD, SOYAD, GSM, ANNEADI, ANNETC, BABAADI, BABATC, MEMLEKETIL, MEMLEKETILCE, MEMLEKETKOY, ADRESIL, ADRESILCE, AILESIRANO, BIREYSIRANO, MEDENIHAL, CINSIYET FROM 109m WHERE TC = :tc";
    $stmt1 = $conn1->prepare($sql1);
    $stmt1->bindParam(':tc', $tc, PDO::PARAM_STR);
    $stmt1->execute();

    $data1 = array(
        'TC' => 'Bulunamadı',
        'AD' => 'Bulunamadı',
        'SOYAD' => 'Bulunamadı',
        'GSM' => 'Bulunamadı',
        'BABAADI' => 'Bulunamadı',
        'BABATC' => 'Bulunamadı',
        'ANNEADI' => 'Bulunamadı',
        'ANNETC' => 'Bulunamadı',
        'DOGUMTARIHI' => 'Bulunamadı',
        'OLUMTARIHI' => 'Bulunamadı',
        'DOGUMYERI' => 'Bulunamadı',
        'MEMLEKETIL' => 'Bulunamadı',
        'MEMLEKETILCE' => 'Bulunamadı',
        'MEMLEKETKOY' => 'Bulunamadı',
        'ADRESIL' => 'Bulunamadı',
        'ADRESILCE' => 'Bulunamadı',
        'AILESIRANO' => 'Bulunamadı',
        'BIREYSIRANO' => 'Bulunamadı',
        'MEDENIHAL' => 'Bulunamadı',
        'CINSIYET' => 'Bulunamadı'
    );

    if ($stmt1->rowCount() > 0) {
        $data1 = $stmt1->fetch(PDO::FETCH_ASSOC);
        foreach ($data1 as $key => $value) {
            $data1[$key] = sanitize_output($value);
        }
    }

    $sql2 = "SELECT KimlikNo,  VergiNumarasi, Ikametgah FROM datam WHERE kimlikNo = :kimlikNo";
    $stmt2 = $conn2->prepare($sql2);
    $stmt2->bindParam(':kimlikNo', $tc, PDO::PARAM_STR);
    $stmt2->execute();

    $data2 = array(
        'VergiNumarasi' => 'Bulunamadı',
        'Ikametgah' => 'Bulunamadı'
    );

    if ($stmt2->rowCount() > 0) {
        $data2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        foreach ($data2 as $key => $value) {
            $data2[$key] = sanitize_output($value);
        }
    }
    $data1['VergiNumarasi'] = $data2['VergiNumarasi'];
    $data1['Ikametgah'] = $data2['Ikametgah'];

    echo json_encode($data1, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE, 4);

} catch (PDOException $e) {
    echo json_encode(['error' => 'Sorgu hatası: ' . $e->getMessage()]);
}

$conn1 = null;
$conn2 = null;
?>