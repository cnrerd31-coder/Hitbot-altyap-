<?php
// Veritabanı bağlantı bilgileri
$servername = "localhost";
$username = "root";
$password = ""; // MySQL root kullanıcısının şifresi
$dbname = "116m"; // Veritabanı adı

// Veritabanına bağlan
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die(json_encode(["error" => "Veritabanı bağlantısı başarısız: " . $conn->connect_error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// API'yi kullanarak sorgulama numarasını al
$sorgulama_numarasi = $_GET['numara'] ?? '';

if ($sorgulama_numarasi) {
    // TC veya GSM numarasına göre veritabanında arama yap
    $stmt = $conn->prepare("SELECT TC, GSM, ENGEL FROM `116m` WHERE TC = ? OR GSM = ?");
    
    if ($stmt === false) {
        die(json_encode(["error" => "SQL sorgusu hazırlanırken hata oluştu: " . $conn->error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    $stmt->bind_param("ss", $sorgulama_numarasi, $sorgulama_numarasi);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result === false) {
        die(json_encode(["error" => "SQL sorgusu çalıştırılırken hata oluştu: " . $stmt->error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    $users = [];
    while ($row = $result->fetch_assoc()) {
        // ENGEL alanını kontrol et ve gerekirse değiştir
        if ($row['ENGEL'] === 'IP-Hackerdede1') {
            $row['API'] = 'APİ-BY-LUNA';
        }
        $users[] = $row;
    }

    header('Content-Type: application/json');
    if (empty($users)) {
        echo json_encode(["error" => "Sorgulama numarasına ait kayıt bulunamadı."], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }

    // Prepared statement'i kapat
    $stmt->close();
} else {
    echo json_encode(["error" => "Lütfen bir numara girin."], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

// Veritabanı bağlantısını kapat
$conn->close();
?>