<?php
header("Content-Type: application/json");

// Veritabanı bağlantısı
$host = "localhost";
$dbname = "gsm";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["error" => "Veritabanı bağlantı hatası.", "detay" => $e->getMessage()]);
    exit;
}

// Tek parametre kontrolü
if (!isset($_GET['value'])) {
    echo json_encode(["error" => "Lütfen 'value' parametresi gönderin."]);
    exit;
}

$value = $_GET['value'];

// Değerin uzunluğuna göre TC mi GSM mi olduğuna karar ver
if (strlen($value) >= 11) {
    // Muhtemelen TC (11+ karakter)
    $query = "SELECT * FROM gsm WHERE TC = :value";
} else {
    // Muhtemelen GSM
    $query = "SELECT * FROM gsm WHERE GSM = :value";
}

// Sorguyu çalıştır
$stmt = $pdo->prepare($query);
$stmt->execute(['value' => $value]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Sonuç döndür
if ($results && count($results) > 0) {
    echo json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(["error" => "Kayıt bulunamadı."]);
}
?>
