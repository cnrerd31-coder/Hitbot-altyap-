<?php
header('Content-Type: application/json; charset=utf-8');

$gsm = isset($_GET['gsm']) ? trim($_GET['gsm']) : '';

if (!$gsm || !preg_match('/^\d{10,15}$/', $gsm)) {
    die(json_encode(["error" => "Geçersiz GSM numarası."], JSON_UNESCAPED_UNICODE));
}

try {
    // GSM'den TC bul
    $pdo_gsm = new PDO("mysql:host=localhost;dbname=116m;charset=utf8mb4", "root", "");
    
    $stmt = $pdo_gsm->prepare("SELECT TC FROM `116m` WHERE GSM = ? LIMIT 1");
    $stmt->execute([$gsm]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$row) {
        echo json_encode(["success" => true, "data" => [], "footer" => "API-BY-LUNA"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }
    
    $tc = $row['TC'];
    
    // Kişi bilgileri al
    $conn = new mysqli("localhost", "root", "", "101m");
    $conn->set_charset("utf8mb4");
    
    $stmt = $conn->prepare("
        SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE,
               ANNEADI, ANNETC, BABAADI, BABATC, UYRUK
        FROM `101m`
        WHERE TC = ?
        LIMIT 1
    ");
    
    $stmt->bind_param("s", $tc);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(["success" => false, "message" => "Kişi bulunamadı"], JSON_UNESCAPED_UNICODE);
    } else {
        $data = $result->fetch_assoc();
        echo json_encode(["success" => true, "data" => $data, "footer" => "API-BY-LUNA"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    
} catch (Exception $e) {
    die(json_encode(["error" => "DB Error: " . $e->getMessage()], JSON_UNESCAPED_UNICODE));
}
?>
