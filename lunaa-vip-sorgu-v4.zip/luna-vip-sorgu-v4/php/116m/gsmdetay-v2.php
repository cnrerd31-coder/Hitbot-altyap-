<?php
// GÜVENLİ GSM DETAY SORGUSU (v2)
require_once __DIR__ . '/../config/DatabaseConnection.php';
require_once __DIR__ . '/../config/APIHelper.php';

header('Content-Type: application/json; charset=utf-8');

// GSM numarasını al ve doğrula
$gsm = APIHelper::getParam('gsm', '', '/^\d{10,15}$/');

if (!$gsm) {
    APIHelper::error('Geçersiz GSM numarası.');
}

try {
    // GSM veritabanından TC bul
    $connGsm = DatabaseConnection::getMysqli('116m');
    
    $stmt = $connGsm->prepare("SELECT TC FROM `116m` WHERE GSM = ? LIMIT 1");
    $stmt->bind_param("s", $gsm);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        APIHelper::response(true, [], null, 'API-BY-LUNA');
    }
    
    $row = $result->fetch_assoc();
    $tc = $row['TC'];
    
    // 101m veritabanından kişi bilgileri al
    $connAile = DatabaseConnection::getMysqli('101m');
    
    $stmt2 = $connAile->prepare("
        SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE,
               ANNEADI, ANNETC, BABAADI, BABATC, UYRUK
        FROM `101m`
        WHERE TC = ?
        LIMIT 1
    ");
    
    $stmt2->bind_param("s", $tc);
    $stmt2->execute();
    $result2 = $stmt2->get_result();
    
    if ($result2->num_rows === 0) {
        APIHelper::response(false, null, 'Kişi bilgileri bulunamadı.');
    }
    
    $data = $result2->fetch_assoc();
    
    APIHelper::response(true, $data, null, 'API-BY-LUNA');
    
} catch (Exception $e) {
    APIHelper::error('Sorgu hatası', $e->getMessage());
}
?>
