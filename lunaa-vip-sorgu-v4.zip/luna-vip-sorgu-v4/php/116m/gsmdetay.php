﻿<?php

// JSON çıktısı için header ayarı
header("Content-Type: application/json; charset=utf-8");

// Hata raporlamayı aç (geliştirme aşamasında kullanılır)
ini_set("display_errors", 1);
error_reporting(E_ALL);

// Veritabanı bağlantı bilgileri
$servername = "localhost";
$username = "root";
$password = ""; // MySQL root kullanıcısının şifresi
$dbnameGsm = "116m"; // GSM veritabanı adı
$dbnameAile = "101m"; // Aile bilgileri veritabanı adı

// GSM veritabanı bağlantısı
$connGsm = new mysqli($servername, $username, $password, $dbnameGsm);
// Aile bilgileri veritabanı bağlantısı
$connAile = new mysqli($servername, $username, $password, $dbnameAile);

// Bağlantıyı kontrol et
if ($connGsm->connect_error) {
    die(json_encode(["error" => "GSM veritabanı bağlantısı başarısız: " . $connGsm->connect_error], JSON_PRETTY_PRINT));
}
if ($connAile->connect_error) {
    die(json_encode(["error" => "Aile bilgileri veritabanı bağlantısı başarısız: " . $connAile->connect_error], JSON_PRETTY_PRINT));
}

// GSM numarasını al
$gsm = isset($_GET['gsm']) ? $_GET['gsm'] : '';

if (empty($gsm)) {
    echo json_encode(['success' => false, 'message' => 'GSM numarası eksik.']);
    exit;
}

// GSM numarasına göre TC bilgisini al
$sqlGsm = "SELECT TC FROM `116m` WHERE GSM = ?";
$stmtGsm = $connGsm->prepare($sqlGsm);
if (!$stmtGsm) {
    echo json_encode(['success' => false, 'message' => 'Veritabanı hatası: ' . $connGsm->error], JSON_PRETTY_PRINT);
    exit;
}
$stmtGsm->bind_param("s", $gsm);
$stmtGsm->execute();
$resultGsm = $stmtGsm->get_result();

if (!$resultGsm || $resultGsm->num_rows == 0) {
    echo json_encode(['success' => false, 'message' => 'Veritabanı hatası veya TC bilgisi bulunamadı.']);
    exit;
}

$rowGsm = $resultGsm->fetch_assoc();
$tc = $rowGsm['TC'];

if (empty($tc)) {
    echo json_encode(['success' => false, 'message' => 'TC bilgisi bulunamadı.']);
    exit;
}

// TC bilgisine göre aile bilgilerini al
$sqlAile = "SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE, ANNEADI, ANNETC, BABAADI, BABATC, UYRUK FROM `101m` WHERE TC = ?";
$stmtAile = $connAile->prepare($sqlAile);
if (!$stmtAile) {
    echo json_encode(["success" => false, "message" => "Aile bilgisi getirme hatası: " . $connAile->error], JSON_PRETTY_PRINT);
    exit;
}
$stmtAile->bind_param("s", $tc);
$stmtAile->execute();
$resultAile = $stmtAile->get_result();

if (!$resultAile) {
    echo json_encode(["success" => false, "message" => "Aile bilgisi getirme hatası"], JSON_PRETTY_PRINT);
    exit;
}

$resultArrayAile = [];
if ($resultAile->num_rows > 0) {
    while ($rowAile = $resultAile->fetch_assoc()) {
        // Aile bilgilerini diziye ekle ve null değerleri kontrol et
        $resultArrayAile[] = [
            "TC" => isset($rowAile['TC']) ? $rowAile['TC'] : null,
            "ADI" => isset($rowAile['ADI']) ? $rowAile['ADI'] : null,
            "SOYADI" => isset($rowAile['SOYADI']) ? $rowAile['SOYADI'] : null,
            "DOGUMTARIHI" => isset($rowAile['DOGUMTARIHI']) ? $rowAile['DOGUMTARIHI'] : null,
            "NUFUSIL" => isset($rowAile['NUFUSIL']) ? $rowAile['NUFUSIL'] : null,
            "NUFUSILCE" => isset($rowAile['NUFUSILCE']) ? $rowAile['NUFUSILCE'] : null,
            "ANNEADI" => isset($rowAile['ANNEADI']) ? $rowAile['ANNEADI'] : null,
            "ANNETC" => isset($rowAile['ANNETC']) ? $rowAile['ANNETC'] : null,
            "BABAADI" => isset($rowAile['BABAADI']) ? $rowAile['BABAADI'] : null,
            "BABATC" => isset($rowAile['BABATC']) ? $rowAile['BABATC'] : null,
            "UYRUK" => isset($rowAile['UYRUK']) ? $rowAile['UYRUK'] : null
        ];
    }
} else {
    echo json_encode(["success" => false, "message" => "Aile bilgisi bulunamadı"], JSON_PRETTY_PRINT);
    exit;
}

// JSON formatında başarılı yanıtı döndür
echo json_encode([
    "success" => true,
    "Data" => $resultArrayAile,
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// Veritabanı bağlantılarını kapat
$stmtGsm->close();
$stmtAile->close();
$connGsm->close();
$connAile->close();

?>