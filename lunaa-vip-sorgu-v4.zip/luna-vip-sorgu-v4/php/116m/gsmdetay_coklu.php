﻿<?php
// TÜM ÇIKTILARI TEMİZLE – BOM, BOŞLUK, UYARI YOK!
ob_clean();
header("Content-Type: application/json; charset=utf-8");
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Veritabanı
$connGsm  = new mysqli("localhost", "root", "", "116m");
$connAile = new mysqli("localhost", "root", "", "101m");

if ($connGsm->connect_error || $connAile->connect_error) {
    echo json_encode(["success" => false, "message" => "Veritabanı hatası"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$gsm = trim($_GET['gsm'] ?? '');
if ($gsm === '' || !preg_match('/^\d{10,15}$/', $gsm)) {
    echo json_encode(["success" => false, "message" => "Geçersiz GSM"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// +90 FORMATI
$clean = preg_replace('/\D/', '', $gsm);
if (strlen($clean) === 10 && $clean[0] === '5') $clean = '90' . $clean;
elseif (strlen($clean) === 11 && $clean[0] === '0') $clean = '90' . substr($clean, 1);
elseif (strlen($clean) !== 12 || substr($clean, 0, 2) !== '90') $clean = '90' . substr($clean, -10);
$full_gsm = '+' . $clean;

// OPERATÖR
$prefix = (int)substr($clean, 2, 3);
$operator = match (true) {
    in_array($prefix, [501,505,506,507,551,552,553,554,555,559]) => "TÜRKTELEKOM",
    in_array($prefix, [530,531,532,533,534,535,536,537,538,539]) => "TURKCELL",
    in_array($prefix, [540,541,542,543,544,545,546,547,548,549]) => "VODAFONE",
    $prefix >= 542850 && $prefix <= 542889 => "KKTC TELSIM",
    $prefix >= 533830 && $prefix <= 533879 => "KKTC TURKCELL",
    default => "BİLİNMEYEN OPERATÖR"
};

// TC BUL
$stmt = $connGsm->prepare("SELECT TC FROM `116m` WHERE GSM = ? LIMIT 1");
$stmt->bind_param("s", $gsm);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    echo json_encode([
        "success"   => true,
        "Data"      => [],
        "gsm"       => $gsm,
        "full_gsm"  => $full_gsm,
        "operator"  => $operator
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$tc = $res->fetch_assoc()['TC'];

// KİŞİ BİLGİSİ
$stmt2 = $connAile->prepare("SELECT TC, ADI, SOYADI, DOGUMTARIHI, NUFUSIL, NUFUSILCE, ANNEADI, ANNETC, BABAADI, BABATC, UYRUK FROM `101m` WHERE TC = ?");
$stmt2->bind_param("s", $tc);
$stmt2->execute();
$res2 = $stmt2->get_result();

$data = [];
while ($row = $res2->fetch_assoc()) {
    $data[] = [
        "TC"          => $row['TC']          ?? "-",
        "ADI"         => $row['ADI']         ?? "-",
        "SOYADI"      => $row['SOYADI']      ?? "-",
        "DOGUMTARIHI" => $row['DOGUMTARIHI'] ?? "-",
        "NUFUSIL"     => $row['NUFUSIL']     ?? "-",
        "NUFUSILCE"   => $row['NUFUSILCE']   ?? "-",
        "ANNEADI"     => $row['ANNEADI']     ?? "-",
        "ANNETC"      => $row['ANNETC']      ?? "-",
        "BABAADI"     => $row['BABAADI']     ?? "-",
        "BABATC"      => $row['BABATC']      ?? "-",
        "UYRUK"       => $row['UYRUK']       ?? "-"
    ];
}

// EN GÜZEL ALT ALTA JSON – JSON_PRETTY_PRINT HER ZAMAN AÇIK!
echo json_encode([
    "success"   => true,
    "Data"      => $data,
    "gsm"       => $gsm,
    "full_gsm"  => $full_gsm,
    "operator"  => $operator
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

$stmt->close();
$stmt2->close();
$connGsm->close();
$connAile->close();
exit;
?>