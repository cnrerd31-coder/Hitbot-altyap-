<?php
// GÜVENLİ GSM→TC SORGUSU (v2)
require_once __DIR__ . '/../config/DatabaseConnection.php';
require_once __DIR__ . '/../config/APIHelper.php';

header('Content-Type: application/json; charset=utf-8');

// GSM numarasını al ve doğrula
$gsm = APIHelper::getParam('gsm', '', '/^\d{10,15}$/');

if (!$gsm) {
    APIHelper::error('Geçersiz GSM numarası. 10-15 haneli sayı girin.');
}

try {
    $pdo = DatabaseConnection::getPDO('gsm');
    
    // GSM'den TC bul
    $stmt = $pdo->prepare("SELECT TC FROM `145mgsm` WHERE GSM = ? LIMIT 1");
    $stmt->execute([$gsm]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$row) {
        APIHelper::response(false, null, 'Bu GSM numarasına ait kişi bulunamadı.');
    }
    
    $tc = $row['TC'];
    
    // GSM veritabanından tüm bilgileri çek
    $stmt2 = $pdo->prepare("SELECT * FROM `145mgsm` WHERE GSM = ?");
    $stmt2->execute([$gsm]);
    $data = $stmt2->fetchAll(PDO::FETCH_ASSOC);
    
    APIHelper::response(true, ['data' => $data], null, 'API-BY-LUNA');
    
} catch (Exception $e) {
    APIHelper::error('Sorgu hatası', $e->getMessage());
}
?>
