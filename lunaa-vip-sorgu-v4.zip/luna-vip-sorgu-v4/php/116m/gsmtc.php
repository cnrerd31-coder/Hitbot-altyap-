<?php
error_reporting(0);
header('Content-Type: application/json');

$host = "localhost";
$user = "root";
$password = "";
$dbname = "gsm";

$conn = mysqli_connect($host, $user, $password, $dbname);

if (!$conn) {
  die("Bağlantı başarısız: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8");

$gsm = $_GET['gsm'];

if (!isset($gsm)) {
  $hata = array('success' => false, 'error' => 'GSM değeri belirtilmemiş');
  echo json_encode($hata, JSON_UNESCAPED_UNICODE);
  exit;
}


$sql = "SELECT * FROM 145mgsm WHERE GSM = '$gsm'";
$result = mysqli_query($conn, $sql);

// Eğer veri bulunamazsa hata mesajı dön
if (mysqli_num_rows($result) === 0) {
  $error = array('error' => 'Belirtilen GSM numarasına sahip kişi bulunamadı.');
  echo json_encode($error, JSON_UNESCAPED_UNICODE);
} else {
  // Verileri alıp JSON formatında döndürün
  $data = mysqli_fetch_all($result, MYSQLI_ASSOC); // Veriyi dizi olarak al

  $output = [
      "data" => $data
  ];

  echo json_encode($output, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

mysqli_close($conn);

function checkAuthToken() {
  $auth = $_GET['auth'];

  if ($auth == "fire") {
    return true;
  } else {
    return false;
  }
}
?>
