<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "116m";

// Veritabanı bağlantısını oluştur
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// API endpoint tanımla
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['query'])) {
    $query = $_GET['query'];
    
    // SQL sorgusunu hazırla
    $sql = "SELECT * FROM data WHERE TC = ? OR GSM = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $query, $query);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Verileri çek ve JSON olarak döndür
    if ($result->num_rows > 0) {
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                'tc' => $row['TC'],
                'gsm' => $row['GSM']
            ];
        }
        echo json_encode($data, JSON_PRETTY_PRINT);
    } else {
        echo json_encode(["message" => "No results found"], JSON_PRETTY_PRINT);
    }
    
    $stmt->close();
} else {
    echo json_encode(["message" => "Invalid request. Please provide a 'query' parameter."], JSON_PRETTY_PRINT);
}

$conn->close();
?>