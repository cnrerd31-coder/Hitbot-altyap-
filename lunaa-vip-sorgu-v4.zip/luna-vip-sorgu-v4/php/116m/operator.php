<?php
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['gsm'])) {
    $phone = $_GET['gsm'];
    $opsorgu = substr($phone, 0, 3);
    $telekom = array(501, 505, 506, 507, 551, 552, 553, 554, 555, 559); // TÜRKTELEKOM
    $turkcell = array(530, 531, 532, 533, 534, 535, 536, 537, 538, 539); // TURKCELL
    $vodafone = array(540, 541, 542, 543, 544, 545, 546, 547, 548, 549); // VODAFONE
    $kktc_telsim = array(54285, 54286, 54287, 54288);  // KKTC TELSIM
    $kktc_turkcell = array(53383, 53384, 53385, 53386, 53387);  // KKTC TURKCELL

    if (in_array($opsorgu, $telekom)) {
        $operator = "TÜRKTELEKOM";
    } elseif (in_array($opsorgu, $turkcell)) {
        $operator = "TURKCELL";
    } elseif (in_array($opsorgu, $vodafone)) {
        $operator = "VODAFONE";
    } elseif (in_array($opsorgu, $kktc_telsim)) {
        $operator = "KKTC TELSIM";
    } elseif (in_array($opsorgu, $kktc_turkcell)) {
        $operator = "KKTC TURKCELL";
    } else {
        $operator = "Bilinmeyen Operatör";
    }

    $response = array(
        'operator' => $operator,
        'gsm' => $phone
    );

    echo json_encode($response);
} else {
    echo json_encode(array('error' => 'Geçersiz İstek'));
}
?>
