<?php
header('Content-Type: application/json; charset=utf-8');

$tc = isset($_GET['tc']) ? trim($_GET['tc']) : '';

if (!$tc || !preg_match('/^\d{11}$/', $tc)) {
    die(json_encode(["error" => "Geçersiz TC numarası."], JSON_UNESCAPED_UNICODE));
}

try {
    $pdo = new PDO("mysql:host=localhost;dbname=gsm;charset=utf8mb4", "root", "");
    
    $stmt = $pdo->prepare("SELECT * FROM `145mgsm` WHERE TC = ?");
    $stmt->execute([$tc]);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($data)) {
        echo json_encode(["success" => false, "message" => "Bulunamadı"], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(["success" => true, "data" => $data, "footer" => "API-BY-LUNA"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
} catch (Exception $e) {
    die(json_encode(["error" => "DB Error: " . $e->getMessage()], JSON_UNESCAPED_UNICODE));
}
?>
