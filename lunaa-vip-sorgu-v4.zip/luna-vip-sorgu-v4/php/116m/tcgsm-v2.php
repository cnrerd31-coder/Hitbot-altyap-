<?php
// GÜVENLİ TC→GSM SORGUSU (v2)
require_once __DIR__ . '/../config/DatabaseConnection.php';
require_once __DIR__ . '/../config/APIHelper.php';

header('Content-Type: application/json; charset=utf-8');

// TC'yi al ve doğrula
$tc = APIHelper::getParam('tc', '', '/^\d{11}$/');

if (!$tc) {
    APIHelper::error('Geçersiz TC numarası. 11 haneli sayı girin.');
}

try {
    $pdo = DatabaseConnection::getPDO('gsm');
    
    // TC'den GSM bul
    $stmt = $pdo->prepare("SELECT * FROM `145mgsm` WHERE TC = ?");
    $stmt->execute([$tc]);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($data)) {
        APIHelper::response(false, null, 'Bu TC numarasına ait GSM bulunamadı.');
    }
    
    APIHelper::response(true, ['data' => $data], null, 'API-BY-LUNA');
    
} catch (Exception $e) {
    APIHelper::error('Sorgu hatası', $e->getMessage());
}
?>
