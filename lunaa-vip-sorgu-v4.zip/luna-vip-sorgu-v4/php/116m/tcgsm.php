<?php
error_reporting(E_ALL); // Hataları tümüyle göster
header('Content-Type: application/json');

$host = "localhost";
$user = "root";
$password = "";
$dbname = "gsm";

$conn = mysqli_connect($host, $user, $password, $dbname);

if (!$conn) {
    die(json_encode(array('success' => false, 'error' => 'Bağlantı başarısız: ' . mysqli_connect_error()), JSON_UNESCAPED_UNICODE));
}

mysqli_set_charset($conn, "utf8");

$tc = isset($_GET['tc']) ? $_GET['tc'] : null;

if (!$tc) {
    $hata = array('success' => false, 'error' => 'TC değeri belirtilmemiş');
    echo json_encode($hata, JSON_UNESCAPED_UNICODE);
    exit;
}

// SQL sorgusunun doğru olup olmadığını kontrol edelim
$sql = "SELECT * FROM `145mgsm` WHERE TC = ?";
$stmt = mysqli_prepare($conn, $sql);

if ($stmt === false) {
    // SQL sorgusu hata veriyorsa, hata mesajını gösterelim
    $error = array('success' => false, 'error' => 'SQL sorgusu hatalı: ' . mysqli_error($conn));
    echo json_encode($error, JSON_UNESCAPED_UNICODE);
    exit;
}

mysqli_stmt_bind_param($stmt, 's', $tc); // 's' parametresi string olduğu için
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

// Eğer veri bulunamazsa hata mesajı döndür
if (mysqli_num_rows($result) === 0) {
    $error = array('error' => 'Belirtilen TC numarasına sahip kişi bulunamadı.');
    echo json_encode($error, JSON_UNESCAPED_UNICODE);
} else {
    // Verileri alıp JSON formatında döndürün
    $data = mysqli_fetch_all($result, MYSQLI_ASSOC); // Veriyi dizi olarak al

    $output = [
        "data" => $data
    ];

    echo json_encode($output, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

mysqli_close($conn);

function checkAuthToken() {
    $auth = isset($_GET['auth']) ? $_GET['auth'] : '';
    if ($auth == "fire") {
        return true;
    } else {
        return false;
    }
}
?>
