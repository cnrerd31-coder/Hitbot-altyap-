<?php
header("Content-Type: application/json; charset=utf-8");

// gsm veritabanı bağlantısı (PDO)
try {
    $pdo_gsm = new PDO("mysql:host=localhost;dbname=gsm;charset=utf8mb4", "root", "", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    die(json_encode(["error" => "GSM veritabanı bağlantı hatası"], JSON_UNESCAPED_UNICODE));
}

// 101m veritabanı bağlantısı (mysqli)
$conn = new mysqli("localhost", "root", "", "101m");
if ($conn->connect_error) {
    die(json_encode(["error" => "101m veritabanı bağlantı hatası"], JSON_UNESCAPED_UNICODE));
}
$conn->set_charset("utf8mb4");

// Parametre kontrolü
if (!isset($_GET['value']) || trim($_GET['value']) === '') {
    die(json_encode(["error" => "Lütfen 'value' parametresi gönderin."], JSON_UNESCAPED_UNICODE));
}

$value = trim($_GET['value']);
$tc = null;

// 1. value TC mi yoksa GSM mi? → TC'yi bul
if (strlen($value) >= 11) {
    // TC olarak geldi
    $stmt = $pdo_gsm->prepare("SELECT TC FROM gsm WHERE TC = ? LIMIT 1");
    $stmt->execute([$value]);
} else {
    // GSM olarak geldi
    $stmt = $pdo_gsm->prepare("SELECT TC FROM gsm WHERE GSM = ? LIMIT 1");
    $stmt->execute([$value]);
}

$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    die(json_encode(["error" => "Bu TC veya GSM numarasına ait kayıt bulunamadı."], JSON_UNESCAPED_UNICODE));
}

$tc = $row['TC'];

// 2. 101m tablosundan sadece bu TC'ye ait kişiyi çek
$stmt2 = $conn->prepare("SELECT * FROM `101m` WHERE TC = ? LIMIT 1");
$stmt2->bind_param("s", $tc);
$stmt2->execute();
$result = $stmt2->get_result();

if ($result->num_rows === 0) {
    die(json_encode(["error" => "Kişi 101m veritabanında bulunamadı."], JSON_UNESCAPED_UNICODE));
}

$person = $result->fetch_assoc();

// 3. Bu TC'ye ait tüm GSM numaralarını çek
$gsm_stmt = $pdo_gsm->prepare("SELECT GSM FROM gsm WHERE TC = ?");
$gsm_stmt->execute([$tc]);
$gsms = $gsm_stmt->fetchAll(PDO::FETCH_COLUMN);

// Sonuç (sadece şahıs)
$sonuc = [
    "TC"          => $person['TC'],
    "ADI"         => $person['ADI'],
    "SOYADI"      => $person['SOYADI'],
    "DOGUMTARIHI" => $person['DOGUMTARIHI'],
    "NUFUSIL"     => $person['NUFUSIL'],
    "NUFUSILCE"   => $person['NUFUSILCE'],
    "ANNEADI"     => $person['ANNEADI'],
    "ANNETC"      => $person['ANNETC'],
    "BABAADI"     => $person['BABAADI'],
    "BABATC"      => $person['BABATC'],
    "UYRUK"       => $person['UYRUK'] ?? "TR",
    "GSM"         => array_map('strval', $gsms)
];

// Çıktı
echo json_encode([
    "data"   => $sonuc,
    "footer" => "   API-BY-LUNA"
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// Kapat
$stmt2->close();
$conn->close();
?>