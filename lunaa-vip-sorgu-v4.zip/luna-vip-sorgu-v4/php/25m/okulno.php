<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "25m";

// Veritabanı bağlantısını oluştur
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// API endpoint tanımla
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['tc'])) {
    $tc = $_GET['tc'];
    
    // SQL sorgusunu hazırla
    $sql = "SELECT id, TC, OKULNO, ADI, SOYADI, DURUM FROM okulno WHERE TC = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $tc);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Verileri çek ve JSON olarak döndür
    header('Content-Type: application/json');
    if ($result->num_rows > 0) {
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                'id' => $row['id'],
                'tc' => $row['TC'],
                'okulno' => $row['OKULNO'],
                'adi' => $row['ADI'],
                'soyadi' => $row['SOYADI'],
                'durum' => $row['DURUM']
            ];
        }
        echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(["message" => "No results found"], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
    
    $stmt->close();
} else {
    header('Content-Type: application/json');
    echo json_encode(["message" => "Invalid request. Please provide a 'tc' parameter."], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

$conn->close();
?>