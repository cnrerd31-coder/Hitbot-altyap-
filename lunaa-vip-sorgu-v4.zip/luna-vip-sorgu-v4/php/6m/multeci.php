<?php
header('Content-Type: application/json');

// Database connection configuration
$host = 'localhost';
$db = '6m';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}

// Check if the TC parameter is set
if (isset($_GET['tc'])) {
    $tc = $_GET['tc'];

    // Prepare and execute the SQL query
    $stmt = $pdo->prepare('SELECT * FROM multeci_6m WHERE TC = ? LIMIT 1');
    $stmt->execute([$tc]);

    // Fetch the result
    $result = $stmt->fetch();

    // Check if a row is found
    if ($result) {
        // Change author value
        $result['author'] = 'API-BY-LUNA';

        // Return the result as formatted JSON
        echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        // Return an error message if no row is found
        echo json_encode(['error' => 'No record found'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
} else {
    // Return an error message if the TC parameter is not set
    echo json_encode(['error' => 'TC parameter is required'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}
?>