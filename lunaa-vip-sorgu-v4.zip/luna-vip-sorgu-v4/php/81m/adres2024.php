<?php
header("Content-Type: application/json");

// Veritabanı bağlantısı
$host = "localhost";
$dbname = "98m";
$username = "root";
$password = ""; // XAMPP için genelde şifre boş olur

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["error" => "Veritabanına bağlanılamadı.", "detay" => $e->getMessage()]);
    exit;
}

// TC parametresi kontrolü
if (!isset($_GET['tc'])) {
    echo json_encode(["error" => "Lütfen 'tc' parametresi gönderin. Örnek: ?tc=10001000282"]);
    exit;
}

$tc = $_GET['tc'];

// Sorgu
$sql = "SELECT ID, TC, ADRES2024, ADRES2023, ADRES2017, ADRES2015, ADRES2009 FROM `98m` WHERE TC = :tc";
$stmt = $pdo->prepare($sql);
$stmt->execute(['tc' => $tc]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);

if ($data) {
    $json = [
        "ID" => $data["ID"],
        "TC" => $data["TC"],
        "Adresler" => [
            "2024" => $data["ADRES2024"],
            "2023" => $data["ADRES2023"],
            "2017" => $data["ADRES2017"],
            "2015" => $data["ADRES2015"],
            "2009" => $data["ADRES2009"]
        ]
    ];
    echo json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(["error" => "Kayıt bulunamadı."]);
}
?>
