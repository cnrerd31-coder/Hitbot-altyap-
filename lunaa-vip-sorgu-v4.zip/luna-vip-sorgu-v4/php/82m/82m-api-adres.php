﻿<?php
// Veritabanı bağlantı bilgileri
$servername = "localhost";
$username = "root";
$password = ""; // MySQL root kullanıcısının şifresi
$dbname = "82m"; // Veritabanı adı

// Veritabanına bağlan
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die(json_encode(["error" => "Veritabanı bağlantısı başarısız: " . $conn->connect_error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// API'yi kullanarak sorgulama parametrelerini al
$kimlikNo = $_GET['kimlikNo'] ?? '';

if ($kimlikNo) {
    // KimlikNo parametresine göre veritabanında arama yap
    $stmt = $conn->prepare("SELECT * FROM `datam` WHERE KimlikNo = ?");
    if ($stmt === false) {
        die(json_encode(["error" => "SQL sorgusu hazırlanırken hata oluştu: " . $conn->error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    $stmt->bind_param("s", $kimlikNo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result === false) {
        die(json_encode(["error" => "SQL sorgusu çalıştırılırken hata oluştu: " . $stmt->error], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    $records = [];
    while ($row = $result->fetch_assoc()) {
        $records[] = $row;
    }

    header('Content-Type: application/json');
    if (empty($records)) {
        echo json_encode(["error" => "Belirtilen kimlik numarasına ait kayıt bulunamadı."], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode($records, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }

    // Prepared statement'i kapat
    $stmt->close();
} else {
    echo json_encode(["error" => "Lütfen bir kimlik numarası girin."], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

// Veritabanı bağlantısını kapat
$conn->close();
?>