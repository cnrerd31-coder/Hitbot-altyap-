﻿<?php
header('Content-Type: application/json; charset=UTF-8');

// Gelen kimlik numarasını al
$kimlikNo = $_GET['kimlikNo'] ?? '';

if ($kimlikNo) {
    // API'nin URL'si
    $apiUrl = "http://localhost/82m/82m-api-adres.php?kimlikNo=" . urlencode($kimlikNo);

    // API'ye istek gönder
    $response = @file_get_contents($apiUrl);

    if ($response === false) {
        die(json_encode([
            "error" => "API'ye ulaşılamadı veya bir bağlantı hatası oluştu."
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    // UTF-8 BOM varsa temizle
    $response = preg_replace('/^\xEF\xBB\xBF/', '', $response);

    // JSON yanıtını çözümle
    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        die(json_encode([
            "error" => "API yanıtı geçerli bir JSON formatında değil.",
            "json_error" => json_last_error_msg(),
            "raw_response" => $response
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    // "Ikametgah" bilgisini kontrol et
    if (!empty($data[0]['Ikametgah'])) {
        $ikametgah = $data[0]['Ikametgah'];

        // Google Maps URL'sini oluştur
        $baseUrl = "https://www.google.com/maps/search/";
        $encodedAddress = urlencode($ikametgah);
        $googleMapsUrl = $baseUrl . $encodedAddress . "/@41.0331247,28.4155528,12.02z?hl=tr&entry=ttu";

        // Google Maps URL'sini döndür (tıklanabilir halde)
        echo json_encode([
            "mapsUrl" => $googleMapsUrl
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    } else {
        echo json_encode([
            "error" => "Ikametgah bilgisi bulunamadı veya boş."
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
} else {
    echo json_encode([
        "error" => "Lütfen bir kimlik numarası girin."
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}
?>
