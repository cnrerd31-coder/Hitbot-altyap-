// Gelen kimlik numarasını al
$kimlikNo = $_GET['kimlikNo'] ?? '';

if ($kimlikNo) {
    // İlk API'nin URL'si
    $apiUrl = "http://localhost/82m/82m-api-adres.php?kimlikNo=" . urlencode($kimlikNo);

    // İlk API'ye istek gönder
    $response = @file_get_contents($apiUrl); // Hata oluşursa @ ile susturuluyor
    if ($response === false) {
        die(json_encode(["error" => "API'ye ulaşılamadı veya bir bağlantı hatası oluştu."], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    // JSON yanıtını çözümle
    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        die(json_encode(["error" => "API yanıtı geçerli bir JSON formatında değil."], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    // "Ikametgah" bilgisini kontrol et
    if (!empty($data[0]['Ikametgah'])) {
        $ikametgah = $data[0]['Ikametgah'];

        // Sonundaki boşluk ve rakamları kaldır
        $ikametgah = preg_replace('/\s*\d+$/', '', $ikametgah);

        // Google Maps URL'sini oluştur
        $baseUrl = "https://www.google.com/maps/search/";
        $encodedAddress = urlencode($ikametgah);
        $googleMapsUrl = $baseUrl . $encodedAddress . "/@41.0331247,28.4155528,12.02z?hl=tr&entry=ttu&g_ep=EgoyMDI1MDQzMC4xIKXMDSoASAFQAw%3D%3D";

        // Google Maps URL'sini döndür
        header('Content-Type: application/json');
        echo json_encode(["mapsUrl" => $googleMapsUrl], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(["error" => "Ikametgah bilgisi bulunamadı veya boş."], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
} else {
    echo json_encode(["error" => "Lütfen bir kimlik numarası girin."], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}