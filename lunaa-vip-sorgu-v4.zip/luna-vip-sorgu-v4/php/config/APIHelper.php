<?php
/**
 * API Yardımcı Sınıfı
 * JSON yanıtları, veri temizliği ve hata yönetimi
 */

class APIHelper {
    /**
     * JSON yanıtı döndür
     */
    public static function response($success, $data = null, $message = null, $footer = null) {
        header('Content-Type: application/json; charset=utf-8');
        
        $response = [
            "success" => $success,
        ];
        
        if ($message) {
            $response["message"] = $message;
        }
        
        if ($data !== null) {
            $response["data"] = $data;
        }
        
        if ($footer) {
            $response["footer"] = $footer;
        }
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }
    
    /**
     * Error yanıtı döndür
     */
    public static function error($message, $details = null) {
        header('Content-Type: application/json; charset=utf-8');
        
        $response = [
            "error" => $message
        ];
        
        if ($details && !empty($_GET['debug'] ?? false)) {
            $response["details"] = $details;
        }
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }
    
    /**
     * GET parametresi al ve temizle
     */
    public static function getParam($name, $default = "", $pattern = null) {
        $value = isset($_GET[$name]) ? trim($_GET[$name]) : $default;
        
        if ($value && $pattern && !preg_match($pattern, $value)) {
            return null;
        }
        
        return $value;
    }
    
    /**
     * Veri satırını temizle ve null değerleri işle
     */
    public static function cleanRow($row, $defaults = []) {
        $cleaned = [];
        
        if (is_array($row)) {
            foreach ($row as $key => $value) {
                $cleaned[$key] = !empty($value) ? $value : ($defaults[$key] ?? null);
            }
        }
        
        return $cleaned;
    }
    
    /**
     * Tablo sütunlarını seç
     */
    public static function selectColumns($row, $columns = []) {
        $result = [];
        
        foreach ($columns as $col) {
            $result[$col] = $row[$col] ?? null;
        }
        
        return $result;
    }
}
?>
