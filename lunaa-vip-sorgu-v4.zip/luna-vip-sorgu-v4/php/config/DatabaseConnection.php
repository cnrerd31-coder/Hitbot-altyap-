<?php
/**
 * Merkez Veritabanı Bağlantı Sınıfı
 * Tüm API dosyalarının kullanması için
 */

class DatabaseConnection {
    private static $connections = [];
    
    /**
     * MySQLi bağlantısı al
     * @param string $dbname - Veritabanı adı
     * @return mysqli
     */
    public static function getMysqli($dbname = "101m") {
        $key = "mysqli_" . $dbname;
        
        if (!isset(self::$connections[$key])) {
            $conn = new mysqli("localhost", "root", "", $dbname);
            
            if ($conn->connect_error) {
                die(json_encode([
                    "error" => "Veritabanı bağlantısı başarısız",
                    "details" => $conn->connect_error
                ], JSON_UNESCAPED_UNICODE));
            }
            
            $conn->set_charset("utf8mb4");
            self::$connections[$key] = $conn;
        }
        
        return self::$connections[$key];
    }
    
    /**
     * PDO bağlantısı al
     * @param string $dbname - Veritabanı adı
     * @return PDO
     */
    public static function getPDO($dbname = "101m") {
        $key = "pdo_" . $dbname;
        
        if (!isset(self::$connections[$key])) {
            try {
                $pdo = new PDO(
                    "mysql:host=localhost;dbname=$dbname;charset=utf8mb4",
                    "root",
                    "",
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                );
                self::$connections[$key] = $pdo;
            } catch (PDOException $e) {
                die(json_encode([
                    "error" => "Veritabanı bağlantısı başarısız",
                    "details" => $e->getMessage()
                ], JSON_UNESCAPED_UNICODE));
            }
        }
        
        return self::$connections[$key];
    }
    
    /**
     * Tüm bağlantıları kapat
     */
    public static function closeAll() {
        foreach (self::$connections as $conn) {
            if ($conn instanceof mysqli) {
                $conn->close();
            } elseif ($conn instanceof PDO) {
                $conn = null;
            }
        }
        self::$connections = [];
    }
}
?>
