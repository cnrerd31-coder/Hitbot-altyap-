# PHP API Quick Start

## Kurulum

1. **Config dosyalarını import et**
```php
require_once __DIR__ . '/../config/DatabaseConnection.php';
require_once __DIR__ . '/../config/APIHelper.php';
```

2. **Header ayarla**
```php
header('Content-Type: application/json; charset=utf-8');
```

## Sık Kullanılan Patterns

### 1. TC Sorgusu
```php
$tc = APIHelper::getParam('tc', '', '/^\d{11}$/');
if (!$tc) APIHelper::error('Geçersiz TC');

$conn = DatabaseConnection::getMysqli('101m');
$stmt = $conn->prepare("SELECT * FROM `101m` WHERE TC = ? LIMIT 1");
$stmt->bind_param("s", $tc);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

APIHelper::response(true, $data);
```

### 2. Çoklu Sonuç
```php
$adi = APIHelper::getParam('adi');
$soyadi = APIHelper::getParam('soyadi');

$conn = DatabaseConnection::getMysqli('101m');
$stmt = $conn->prepare("
    SELECT * FROM `101m` 
    WHERE UPPER(ADI) LIKE ? AND UPPER(SOYADI) LIKE ?
    LIMIT 1000
");
$stmt->bind_param("ss", "%$adi%", "%$soyadi%");
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

APIHelper::response(true, $data);
```

### 3. İki Veritabanı Join
```php
$gsm = APIHelper::getParam('gsm');

// 1. GSM→TC
$pdo_gsm = DatabaseConnection::getPDO('gsm');
$stmt = $pdo_gsm->prepare("SELECT TC FROM gsm WHERE GSM = ?");
$stmt->execute([$gsm]);
$tc = $stmt->fetch()['TC'];

// 2. TC→Bilgiler
$conn_101 = DatabaseConnection::getMysqli('101m');
$stmt = $conn_101->prepare("SELECT * FROM `101m` WHERE TC = ?");
$stmt->bind_param("s", $tc);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

APIHelper::response(true, $data);
```

### 4. Hata Yönetimi
```php
try {
    $conn = DatabaseConnection::getMysqli('101m');
    // queries...
    APIHelper::response(true, $data);
} catch (Exception $e) {
    APIHelper::error('Sorgu hatası', $e->getMessage());
}
```

## Response Formats

### Başarılı (Tek Veri)
```json
{
  "success": true,
  "data": {...},
  "footer": "API-BY-LUNA"
}
```

### Başarılı (Çoklu Veri)
```json
{
  "success": true,
  "data": [{...}, {...}],
  "footer": "API-BY-LUNA"
}
```

### Hata
```json
{
  "error": "Hata mesajı"
}
```

### Boş Sonuç
```json
{
  "success": false,
  "message": "Sonuç bulunamadı."
}
```

## Veritabanı Bağlantıları

```php
// MySQLi (Default - çoğu zaman bu)
$conn = DatabaseConnection::getMysqli('101m');

// PDO (Optional)
$pdo = DatabaseConnection::getPDO('gsm');
```

## Input Doğrulama Patterns

```php
// TC (11 hane)
$tc = APIHelper::getParam('tc', '', '/^\d{11}$/');

// GSM (10-15 hane)
$gsm = APIHelper::getParam('gsm', '', '/^\d{10,15}$/');

// Metin (zorunlu)
$adi = APIHelper::getParam('adi', '');
if (!$adi) APIHelper::error('Ad zorunludur');

// Opsiyonel
$il = APIHelper::getParam('il', '');  // Default: ""
```

## Debugging

```php
// Debug mode açmak için
APIHelper::error('Hata', $e->getMessage());  // details gösterir
```

## Best Practices

✅ **Yap**
- Prepared statements kullan
- APIHelper::getParam() ile input al
- APIHelper::response() ile cevap ver
- Try-catch ile hata yönet

❌ **Yapma**
- String interpolasyon SQL'de
- $_GET direkt kullan
- `die()` ile error ver
- Hardcoded DB credentials

---

**Son Güncelleme**: 2025-12-18


