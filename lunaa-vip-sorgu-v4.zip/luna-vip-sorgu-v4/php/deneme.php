<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Hız için buffer'ı kapat
if (ob_get_level()) ob_end_clean();

// --- HEADER ---
header("Content-Type: application/json; charset=UTF-8");

// --- TC PARAMETRESİ ---
$tc = $_GET['tc'] ?? '';
if ($tc === '') {
    echo json_encode(["success" => false, "error" => "TC numarası gerekli"]);
    exit;
}

// --- VERİTABANI BAĞLANTISI ---
try {
    $pdo = new PDO("mysql:host=localhost;dbname=vesika;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["success" => false, "error" => "Veritabanı bağlantı hatası: ".$e->getMessage()]);
    exit;
}

// --- TC'YE GÖRE SORGU ---
$stmt = $pdo->prepare("SELECT `VESIKA` FROM `vesika` WHERE `TC` = ? LIMIT 1");
$stmt->execute([$tc]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    echo json_encode(["success" => false, "error" => "Kayıt bulunamadı"]);
    exit;
}

$base64 = $row['VESIKA'];

// --- HTML MODU ---
if (isset($_GET['format']) && $_GET['format'] === 'html') {
    header("Content-Type: text/html; charset=UTF-8");
    echo "<!DOCTYPE html><html><body style='background:#111;text-align:center;color:#fff;font-family:Arial'>";

    // TC numarası üstte
    echo "<h3>TC: " . htmlspecialchars($tc) . "</h3>";

    // --- Vesika görselinin üstüne: Token ve API Founder ---
    echo "<div style='margin-bottom:10px; padding:5px; background:#222; display:inline-block; border-radius:8px'>";
    echo "<span style='opacity:0.8'>Token: <b>V3QVHHBFwc4OTDN</b> | API Founder: <b>Luna</b></span>";
    echo "</div><br>";

    // Vesika görseli
    echo "<img src='data:image/jpeg;base64," . $base64 . "' style='max-width:90%;border-radius:10px;box-shadow:0 0 15px #000'>";

    echo "</body></html>";
    exit;
}

// --- JSON ÇIKTISI ---
echo json_encode([
    "success" => true,
    "Token" => "V3QVHHBFwc4OTDN",
    "ApiFounder" => "@lunacarma",
    "ApiBilgi" => "bu api @LunaVipSorgu_bot için yazılmıştır.",
    "tc" => $tc,
    "base64" => $base64
], JSON_UNESCAPED_SLASHES);
