<!DOCTYPE html>
<html>
<head>
  <title>Plaka Sorgu (SBM'siz)</title>
  <style>
    body { font-family: Arial; background: #f4f4f4; padding: 20px; }
    .box { max-width: 600px; margin: auto; background: white; padding: 20px; border-radius: 10px; }
    input, button { width: 100%; padding: 12px; margin: 10px 0; }
    button { background: #d32f2f; color: white; border: none; cursor: pointer; }
    pre { background: #eee; padding: 15px; white-space: pre-wrap; }
  </style>
</head>
<body>
<div class="box">
  <h2>Plaka Sorgu (Yasal)</h2>
  <form method="post">
    <input name="p" placeholder="Plaka" required>
    <button>SORGULA</button>
  </form>

  <?php
  if ($_POST['p']) {
    $p = strtoupper($_POST['p']);
    echo "<pre>";
    echo "PLAKA: $p\n";
    echo "────────────────────────────────────\n";

    // MUAYENE
    $ch = curl_init("https://www.tuvturk.com.tr/muayene-sorgulama");
    curl_setopt_array($ch, [CURLOPT_POST=>1, CURLOPT_POSTFIELDS=>http_build_query(['Plaka'=>$p,'AramaTuru'=>'plaka']), CURLOPT_RETURNTRANSFER=>1, CURLOPT_TIMEOUT=>10]);
    $html = curl_exec($ch); curl_close($ch);
    preg_match('/\d{2}\.\d{2}\.\d{4}/', $html, $m);
    echo "MUAYENE: " . ($m[0] ?? "Bulunamadı") . "\n";

    // İHLALLİ GEÇİŞ
    $ch = curl_init("https://ccis.cordisnetwork.com/CWC/bridgeDebt");
    curl_setopt_array($ch, [CURLOPT_POST=>1, CURLOPT_POSTFIELDS=>"query=plakatabtoplamborc&PlateNumber=$p&IsTotalDebtQuery=1&Hash=99331", CURLOPT_RETURNTRANSFER=>1]);
    $html = curl_exec($ch); curl_close($ch);
    preg_match('/(\d+,\d+)/', $html, $m);
    echo "İHLALLİ GEÇİŞ: " . ($m[1] ?? "0,00") . " TL\n";

    // SİGORTA
    echo "SİGORTA: 5664'e '$p' yazıp gönder → cevap gelir\n";

    echo "────────────────────────────────────\n";
    echo "TC / AD / TELEFON: YASAL OLARAK VERİLEMEZ\n";
    echo "</pre>";
  }
  ?>
</div>
</body>
</html>