<?php
// ====================================================
// DRAGON V80 – %100 TEMİZ JSON
// HİÇBİR SCRIPT, HİÇBİR HTML, HİÇBİR EKSTRA YOK!
// SEKME AÇMA YOK – SADECE SONUÇ!
// ====================================================

ob_start(); // Çıktıyı yakala

$tc = $_GET['tc'] ?? '';
if (!preg_match('/^\d{11}$/', $tc)) {
    $result = ["success"=>false,"error"=>"11 haneli TC gir","footer"=>"API-BY-LUNA"];
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// 101m'den doğum tarihi
$conn = new mysqli("localhost", "root", "", "101m");
if ($conn->connect_error) {
    $result = ["success"=>false,"error"=>"DB hatası","footer"=>"API-BY-LUNA"];
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$stmt = $conn->prepare("SELECT DOGUMTARIHI FROM `101m` WHERE TC = ?");
$stmt->bind_param("s", $tc);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    $result = ["success"=>false,"error"=>"TC bulunamadı","tc"=>$tc,"footer"=>"API-BY-LUNA"];
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$dogum_tarihi = trim($res->fetch_assoc()['DOGUMTARIHI']);
$stmt->close();
$conn->close();

// Format → 10.03.1949
$dt = DateTime::createFromFormat('Y-m-d', $dogum_tarihi)
    ?: DateTime::createFromFormat('d.m.Y', $dogum_tarihi)
    ?: DateTime::createFromFormat('d/m/Y', $dogum_tarihi);

if (!$dt) {
    $result = ["success"=>false,"error"=>"Tarih okunamadı","footer"=>"API-BY-LUNA"];
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$formatted_dt = $dt->format('d.m.Y');
$target_url = "http://localhost:8031/api/adres?tc=$tc&dt=$formatted_dt";

// SONUCU ÇEK
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $target_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    CURLOPT_HTTPHEADER => [
        'Accept: application/json',
        'Referer: http://localhost:8031/',
        'Origin: http://localhost:8031'
    ]
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// HATA KONTROL
if (!$response || $http_code !== 200) {
    $error = json_decode($response, true) ?: ["raw" => substr($response, 0, 500)];
    $error['success'] = false;
    $error['error'] = $error['error'] ?? "Bağlantı hatası (HTTP: $http_code)";
    $error['footer'] = "API-BY-LUNA";
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($error, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    ob_end_flush();
    exit;
}

// BAŞARILI → TEMİZ JSON + FOOTER
$result = json_decode($response, true);
$result['footer'] = "API-BY-LUNA";

header('Content-Type: application/json; charset=utf-8');
echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

ob_end_flush();
exit;