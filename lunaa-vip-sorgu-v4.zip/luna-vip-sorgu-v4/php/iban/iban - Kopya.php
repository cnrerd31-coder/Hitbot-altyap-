<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$response = [
    'success' => false,
    'data' => null,
    'error' => null
];

if (!isset($_GET['iban']) && !isset($_POST['iban'])) {
    http_response_code(400);
    $response['error'] = 'IBAN parametresi gerekli';
    echo json_encode($response);
    exit;
}

$iban = trim($_GET['iban'] ?? $_POST['iban']);

if (empty($iban)) {
    http_response_code(400);
    $response['error'] = 'IBAN boş olamaz';
    echo json_encode($response);
    exit;
}

// Query the external API
$url = "https://hesapno.com/cozumleme_iban.php";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "iban=" . urlencode($iban));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$result = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200 || !$result) {
    http_response_code(500);
    $response['error'] = 'Dış API\'ye erişim başarısız';
    echo json_encode($response);
    exit;
}

// Parse HTML response
$data = [
    'iban' => $iban
];

// Extract bank info
if (preg_match('/Ad:\s*(.+?)<br/i', $result, $m)) $data['banka']['ad'] = trim(strip_tags($m[1]));
if (preg_match('/Kod:\s*(.+?)<br/i', $result, $m)) $data['banka']['kod'] = trim(strip_tags($m[1]));
if (preg_match('/Swift:\s*(.+?)<br/i', $result, $m)) $data['banka']['swift'] = trim(strip_tags($m[1]));
if (preg_match('/Hesap\s+No:\s*(.+?)<br/i', $result, $m)) $data['banka']['hesap_no'] = trim(strip_tags($m[1]));

// Extract branch info - find after ŞUBE BİLGİLERİ
if (preg_match('/ŞUBE\s+BİLGİLERİ.+?<b>Ad:<\/b>\s*([^<]+)<br/is', $result, $m)) $data['sube']['ad'] = trim($m[1]);
if (preg_match('/ŞUBE\s+BİLGİLERİ.+?<b>Kod:<\/b>\s*([^<]+)<br/is', $result, $m)) $data['sube']['kod'] = trim($m[1]);
if (preg_match('/ŞUBE\s+BİLGİLERİ.+?<b>İl:<\/b>\s*([^<]+)<br/is', $result, $m)) $data['sube']['il'] = trim($m[1]);
if (preg_match('/ŞUBE\s+BİLGİLERİ.+?<b>İlçe:<\/b>\s*([^<]+)<br/is', $result, $m)) $data['sube']['ilce'] = trim($m[1]);
if (preg_match('/ŞUBE\s+BİLGİLERİ.+?<b>Tel:<\/b>\s*([^<]+)<br/is', $result, $m)) $data['sube']['tel'] = trim($m[1]);
if (preg_match('/ŞUBE\s+BİLGİLERİ.+?<b>Fax:<\/b>\s*([^<]+)<br/is', $result, $m)) $data['sube']['fax'] = trim($m[1]);
if (preg_match('/ŞUBE\s+BİLGİLERİ.+?<b>Adres:<\/b>\s*([^<]+)<br/is', $result, $m)) $data['sube']['adres'] = trim($m[1]);

$response['success'] = true;
$response['data'] = $data;
http_response_code(200);
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
