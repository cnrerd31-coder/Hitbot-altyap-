﻿<?php
header("Content-Type: application/json; charset=UTF-8");

// Veritabanı bağlantısı
$servername = "localhost";
$username = "root"; // MySQL kullanıcı adı
$password = ""; // MySQL şifresi (Varsayılan olarak boş)
$database = "isyeri";

$conn = new mysqli($servername, $username, $password, $database);

// Bağlantı kontrolü
if ($conn->connect_error) {
    die(json_encode(["error" => "Veritabanı bağlantı hatası: " . $conn->connect_error]));
}

// TC kimlik numarası al
if (!isset($_GET['tc']) || empty($_GET['tc'])) {
    echo json_encode(["error" => "Lütfen bir TC kimlik numarası girin."]);
    exit;
}

$tc = $conn->real_escape_string($_GET['tc']);

// Sorguyu hazırla ve çalıştır
$sql = "SELECT * FROM sgkyetki WHERE yetkiliTckn = '$tc'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = [];

    while ($row = $result->fetch_assoc()) {
        $data[] = [
            "ID" => $row["_id"],
            "AdSoyad" => $row["yetkiliAdSoyad"],
            "YetkiTuru" => $row["yetkiTuru"],
            "İşyeriUnvanı" => $row["isyeriUnvani"],
            "SGK_Sicil_No" => $row["sgkSicilNo"],
            "YetkililikDurumu" => $row["yetkililikDurumu"]
        ];
    }

    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(["error" => "Belirtilen TC kimlik numarasına ait kayıt bulunamadı."]);
}

// Bağlantıyı kapat
$conn->close();
?>
