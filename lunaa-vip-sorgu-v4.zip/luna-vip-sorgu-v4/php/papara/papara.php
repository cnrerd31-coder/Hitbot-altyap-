﻿<?php
// Database configuration
$servername = "127.0.0.1";
$username = "root"; // Default username for XAMPP
$password = ""; // Default password for XAMPP
$dbname = "papara";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the content type to application/json and charset to UTF-8
header('Content-Type: application/json; charset=utf-8');

// Get the paparano from the request
$paparano = isset($_GET['paparano']) ? intval($_GET['paparano']) : 0;

if ($paparano > 0) {
    // Prepare and execute the query
    $stmt = $conn->prepare("SELECT id, paparano, adsoyad FROM papara WHERE paparano = ?");
    $stmt->bind_param("i", $paparano);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the result as an associative array
        $row = $result->fetch_assoc();
        
        // Format the response
        $response = [
            "PAPARA NO" => $row['paparano'],
            "İSİM SOY İSİM" => $row['adsoyad']
        ];
        
        // Return the result as JSON
        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    } else {
        // Return an empty JSON object if no result is found
        echo json_encode([]);
    }

    // Close the statement
    $stmt->close();
} else {
    // Return an error message if the paparano is not provided or invalid
    echo json_encode(["error" => "Invalid or missing paparano"]);
}

// Close the connection
$conn->close();
?>