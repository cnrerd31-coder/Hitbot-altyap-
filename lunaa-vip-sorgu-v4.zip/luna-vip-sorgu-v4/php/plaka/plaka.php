﻿<?php
// Database configuration
$servername = "127.0.0.1";
$username = "root"; // Default username for XAMPP
$password = ""; // Default password for XAMPP
$dbname = "75k_plaka";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the content type to application/json and charset to UTF-8
header('Content-Type: application/json; charset=utf-8');

// Get the Plaka_No from the request
$plaka_no = isset($_GET['Plaka_No']) ? $_GET['Plaka_No'] : '';

if (!empty($plaka_no)) {
    // Prepare and execute the query
    $stmt = $conn->prepare("SELECT Plaka_No, Isim FROM 75k_plaka WHERE Plaka_No = ?");
    $stmt->bind_param("s", $plaka_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the result as an associative array
        $row = $result->fetch_assoc();
        
        // Format the response
        $response = [
            "PLAKA" => $row['Plaka_No'],
            "AD SOYAD" => $row['Isim']
        ];
        
        // Return the result as JSON
        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    } else {
        // Return an empty JSON object if no result is found
        echo json_encode([]);
    }

    // Close the statement
    $stmt->close();
} else {
    // Return an error message if the Plaka_No is not provided or invalid
    echo json_encode(["error" => "Invalid or missing Plaka_No"]);
}

// Close the connection
$conn->close();
?>