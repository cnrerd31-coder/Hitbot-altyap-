<?php
header('Content-Type: application/json');

$host = "localhost";
$dbname = "sgk";
$user = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Veritabanı bağlantısı başarısız: ' . $e->getMessage()]);
    exit;
}

function sanitize_output($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

$tc = isset($_GET['tc']) ? strip_tags($_GET['tc']) : '';

if (empty($tc) || !preg_match('/^\d{11}$/', $tc)) {
    $hata = array('success' => false, 'message' => 'Lütfen 11 haneli geçerli bir TC kimlik numarası giriniz');
    echo json_encode($hata, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // 1. Verilen TC'ye göre çalışanın isyeriId ve isyeriUnvani alınıyor
    $sql1 = "SELECT isyeriId, isyeriUnvani FROM theos WHERE calisanKimlikNo = :tc LIMIT 1";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bindParam(':tc', $tc, PDO::PARAM_STR);
    $stmt1->execute();

    if ($stmt1->rowCount() == 0) {
        echo json_encode(['success' => false, 'message' => 'Çalışan bulunamadı'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $result = $stmt1->fetch(PDO::FETCH_ASSOC);
    $isyeriId = $result['isyeriId'];
    $isyeriUnvani = $result['isyeriUnvani'];

    // 2. Aynı işyeriId'ye bağlı tüm çalışanları çekiyoruz
    $sql2 = "SELECT * FROM theos WHERE isyeriId = :isyeriId ORDER BY calisanAdSoyad ASC";
    $stmt2 = $conn->prepare($sql2);
    $stmt2->bindParam(':isyeriId', $isyeriId, PDO::PARAM_STR);
    $stmt2->execute();

    $calisanlar = $stmt2->fetchAll(PDO::FETCH_ASSOC);

    // 3. Her çalışanın verisini sanitize ediyoruz ve sıralama numarası ekliyoruz
    foreach ($calisanlar as $index => &$calisan) {
        foreach ($calisan as $key => $value) {
            $calisan[$key] = sanitize_output($value) ?: 'Bulunamadı';
        }
        $calisan['sira'] = $index + 1;
    }

    $response = [
        'success' => true,
        'total_calisan' => count($calisanlar),
        'isyeriUnvani' => sanitize_output($isyeriUnvani),
        'data' => $calisanlar
    ];

    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    echo json_encode(['error' => 'Sorgu hatası: ' . $e->getMessage()]);
}

$conn = null;
?>
