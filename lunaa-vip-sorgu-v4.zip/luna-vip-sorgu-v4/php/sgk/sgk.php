<?php
header('Content-Type: application/json');

$host = "localhost";
$dbname = "sgk";
$user = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Veritabanı bağlantısı başarısız: ' . $e->getMessage()]);
    exit;
}

function sanitize_output($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

$tc = isset($_GET['tc']) ? strip_tags($_GET['tc']) : '';

if (empty($tc) || !preg_match('/^\d{11}$/', $tc)) {
    $hata = array('success' => false, 'message' => 'Lütfen 11 haneli geçerli bir TC kimlik numarası giriniz');
    echo json_encode($hata, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $sql = "SELECT * FROM theos WHERE calisanKimlikNo = :tc";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':tc', $tc, PDO::PARAM_STR);
    $stmt->execute();
    
    $data = array();
    if ($stmt->rowCount() > 0) {
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($data as &$employee) {
            foreach ($employee as $key => $value) {
                $employee[$key] = sanitize_output($value) ?: 'Bulunamadı';
            }
        }
        echo json_encode(['success' => true, 'data' => $data], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['success' => false, 'message' => 'Çalışan bulunamadı'], JSON_UNESCAPED_UNICODE);
    }

} catch (PDOException $e) {
    echo json_encode(['error' => 'Sorgu hatası: ' . $e->getMessage()]);
}

$conn = null;
?>