<?php
// CORS Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

// Timeout ve performance ayarları
set_time_limit(180);
ini_set('default_socket_timeout', 180);

// Parametreleri al - Support both single and separate parameter formats
$adaParselIlIlce = isset($_GET['ada']) ? $_GET['ada'] : null;

if ($adaParselIlIlce && strpos($adaParselIlIlce, '-') !== false) {
    // Old format: ada=20905-2-ANKARA or ada=20905-2-ANKARA-ALTINDAĞ
    $parts = explode('-', $adaParselIlIlce);
    if (count($parts) < 2 || count($parts) > 4) {
        http_response_code(400);
        die(json_encode([
            "status" => "error",
            "code" => 400,
            "error" => "Lütfen geçerli bir değer sağlayın. Örnek: ?ada=20905-2 veya ?ada=20905-2-ANKARA veya ?ada=20905-2-ANKARA-ALTINDAĞ"
        ], JSON_UNESCAPED_UNICODE));
    }
    $ada = (int)preg_replace('/[^0-9]/', '', $parts[0]);
    $parsel = (int)preg_replace('/[^0-9]/', '', $parts[1]);
    $il = isset($parts[2]) ? trim(strtoupper($parts[2])) : null;
    $ilce = isset($parts[3]) ? trim(strtoupper($parts[3])) : null;
} else {
    // New format: separate parameters
    $ada = isset($_GET['ada']) ? (int)preg_replace('/[^0-9]/', '', $_GET['ada']) : null;
    $parsel = isset($_GET['parsel']) ? (int)preg_replace('/[^0-9]/', '', $_GET['parsel']) : null;
    $il = isset($_GET['il']) ? trim(strtoupper($_GET['il'])) : null;
    $ilce = isset($_GET['ilce']) ? trim(strtoupper($_GET['ilce'])) : null;
}

// Validation
if (!$ada || !$parsel) {
    http_response_code(400);
    die(json_encode([
        "status" => "error",
        "code" => 400,
        "error" => "ada ve parsel zorunlu"
    ], JSON_UNESCAPED_UNICODE));
}

try {
    $pdo = new PDO("mysql:host=localhost;dbname=tapu;charset=utf8mb4", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Base query - direct integer comparison
    $sql = "SELECT 
                id, 
                il, 
                ilce, 
                MahalleKoyAdi AS 'Mahalle/Köy', 
                ZeminTip AS 'Zemin Tipi', 
                Ada, 
                Parsel, 
                CONCAT(Yuzolcum, ' m²') AS 'Yüzölçüm', 
                AnaTasinmazNitelik AS 'Nitelik', 
                Adi AS 'Adı', 
                Soyadi AS 'Soyadı', 
                BabaAdi AS 'Baba Adı', 
                TCKimlikNo AS 'TC Kimlik No', 
                EdinmeSebebi AS 'Edinme Sebebi', 
                CASE 
                    WHEN Tarih IS NOT NULL THEN Tarih
                    ELSE 'None'
                END AS Tarih, 
                Yevmiye
            FROM tapu 
            WHERE Ada = ? AND Parsel = ?";
    $params = [$ada, $parsel];
    
    // Optional filters - only add if not empty/null
    if (!empty($il)) {
        $sql .= " AND UPPER(TRIM(il)) = ?";
        $params[] = $il;
    }
    if (!empty($ilce)) {
        $sql .= " AND UPPER(TRIM(ilce)) = ?";
        $params[] = $ilce;
    }
    
    $sql .= " LIMIT 100";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!$results) {
        http_response_code(404);
        die(json_encode([
            "status" => "error",
            "code" => 404,
            "error" => "Kayıt bulunamadı"
        ], JSON_UNESCAPED_UNICODE));
    }
    
    echo json_encode([
        "status" => "success",
        "code" => 200,
        "data" => $results
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    http_response_code(500);
    die(json_encode([
        "status" => "error",
        "code" => 500,
        "error" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE));
}

$pdo = null;
?>