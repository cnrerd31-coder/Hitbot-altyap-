﻿<?php
// Veritabanı bağlantısı için gerekli bilgiler
$servername = "localhost";
$username = "root"; // Veritabanı kullanıcı adı
$password = ""; // Veritabanı şifresi
$dbname = "tapu"; // Veritabanı adı

// JSON çıktısı için Content-Type başlığı ayarlanıyor
header('Content-Type: application/json; charset=utf-8');

// Ada ve parsel bilgilerini tek bir parametreden (ada) al
$adaParsel = isset($_GET['ada']) ? $_GET['ada'] : null;

// Eğer gerekli parametre eksikse hata mesajı gönder
if (!$adaParsel) {
    http_response_code(400); // Bad Request
    echo json_encode([
        "error" => "Lütfen 'ada' parametresini sağlayın. Örnek: ?ada=186-1"
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Ada ve parseli ayır
$adaParselParts = explode('-', $adaParsel);

// Eğer ada veya parsel eksikse hata mesajı gönder
if (count($adaParselParts) !== 2 || empty($adaParselParts[0]) || empty($adaParselParts[1])) {
    http_response_code(400); // Bad Request
    echo json_encode([
        "error" => "Lütfen geçerli bir 'ada-parsel' değeri sağlayın. Örnek: ?ada=186-1"
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$ada = $adaParselParts[0];
$parsel = $adaParselParts[1];

try {
    // Veritabanı bağlantısını oluştur
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Veritabanında ada ve parsel kombinasyonu için sorgu
    $stmt = $conn->prepare("
        SELECT 
            id, 
            il, 
            ilce, 
            MahalleKoyAdi, 
            ZeminTip, 
            Ada, 
            Parsel, 
            Yuzolcum, 
            AnaTasinmazNitelik, 
            Adi, 
            Soyadi, 
            BabaAdi, 
            TCKimlikNo, 
            EdinmeSebebi, 
            CASE 
                WHEN Tarih IS NOT NULL THEN DATE_FORMAT(Tarih, '%d/%m/%Y') 
                ELSE NULL 
            END AS Tarih, 
            Yevmiye 
        FROM tapu 
        WHERE Ada = :ada AND Parsel = :parsel
    ");
    $stmt->bindParam(':ada', $ada, PDO::PARAM_STR);
    $stmt->bindParam(':parsel', $parsel, PDO::PARAM_STR);

    // Sorguyu çalıştır
    $stmt->execute();

    // Sonuçları al ve JSON formatına çevir
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($results) {
        // Verilerin istenen formatta döndüğünden emin olun
        $formattedResults = array_map(function ($row) {
            return [
                "id" => (int)$row["id"],
                "il" => $row["il"],
                "ilce" => $row["ilce"],
                "MahalleKoyAdi" => $row["MahalleKoyAdi"],
                "ZeminTip" => $row["ZeminTip"],
                "Ada" => $row["Ada"],
                "Parsel" => $row["Parsel"],
                "Yuzolcum" => $row["Yuzolcum"],
                "AnaTasinmazNitelik" => $row["AnaTasinmazNitelik"],
                "Adi" => $row["Adi"],
                "Soyadi" => $row["Soyadi"],
                "BabaAdi" => $row["BabaAdi"],
                "TCKimlikNo" => $row["TCKimlikNo"],
                "EdinmeSebebi" => $row["EdinmeSebebi"],
                "Tarih" => $row["Tarih"], // Eğer null ise null olarak döner
                "Yevmiye" => $row["Yevmiye"]
            ];
        }, $results);

        // JSON_UNESCAPED_UNICODE ile Türkçe karakterlerin doğru şekilde döndürülmesini sağlıyoruz.
        // JSON_PRETTY_PRINT ile düzenli bir görünüm sağlıyoruz.
        echo json_encode($formattedResults, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    } else {
        http_response_code(404); // Not Found
        echo json_encode([
            "error" => "Belirtilen ada ve parsel bilgileriyle eşleşen kayıt bulunamadı."
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode([
        "error" => "Veritabanı hatası: " . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

// Veritabanı bağlantısını kapat
$conn = null;
?>