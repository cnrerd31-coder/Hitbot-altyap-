﻿<?php
// Veritabanı bağlantısı
$servername = "localhost";
$username = "root"; // Veritabanı kullanıcı adı
$password = ""; // Veritabanı şifresi
$dbname = "tapu"; // Veritabanı adı

// Bağlantıyı kurma
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantı kontrolü
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ad ve Soyad'ı al
$adi = isset($_GET['adi']) ? $_GET['adi'] : '';
$soyadi = isset($_GET['soyadi']) ? $_GET['soyadi'] : '';

// Eğer Ad ve Soyad yoksa, hata mesajı döndür
if (empty($adi) || empty($soyadi)) {
    echo json_encode(["error" => "Ad ve Soyad girilmelidir."]);
    exit;
}

// SQL sorgusu: sadece aranan kişinin (Ad ve Soyad) verisini alıyoruz
$sql = "SELECT * FROM tapu WHERE Adi = '$adi' AND Soyadi = '$soyadi' LIMIT 1"; // Limit 1 ekleyerek sadece ilk bulduğumuzu alıyoruz

// Sorguyu çalıştır
$result = $conn->query($sql);

// Sonuç kontrolü
if ($result->num_rows > 0) {
    // Kayıt döndü
    $row = $result->fetch_assoc();
    $data = [
        'id' => $row['id'],
        'il' => $row['il'],
        'ilce' => $row['ilce'],
        'MahalleKoyAdi' => $row['MahalleKoyAdi'],
        'ZeminTip' => $row['ZeminTip'],
        'Ada' => $row['Ada'],
        'Parsel' => $row['Parsel'],
        'Yuzolcum' => $row['Yuzolcum'],
        'AnaTasinmazNitelik' => $row['AnaTasinmazNitelik'],
        'Adi' => $row['Adi'],
        'Soyadi' => $row['Soyadi'],
        'BabaAdi' => $row['BabaAdi'],
        'TCKimlikNo' => $row['TCKimlikNo'],
        'EdinmeSebebi' => $row['EdinmeSebebi'],
        // Tarihi formatı düzelt
        'Tarih' => str_replace('/', '-', $row['Tarih']),
        'Yevmiye' => $row['Yevmiye']
    ];

    // JSON verisini düzgün formatta döndür
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} else {
    echo json_encode(["error" => "No records found for this Ad and Soyad."]);
}

// Bağlantıyı kapatma
$conn->close();
?>
