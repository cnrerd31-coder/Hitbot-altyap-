﻿<?php
// Veritabanı bağlantısı
$servername = "localhost";
$username = "root"; // Veritabanı kullanıcı adı
$password = ""; // Veritabanı şifresi
$dbname = "tapu"; // Veritabanı adı

// Bağlantıyı kurma
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantı kontrolü
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// TC Kimlik numarasını al
$tc = isset($_GET['tc']) ? $_GET['tc'] : '';

// Eğer TC yoksa, hata mesajı döndür
if (empty($tc)) {
    echo json_encode(["error" => "TC kimlik numarası girilmelidir."]);
    exit;
}

// SQL sorgusu
$sql = "SELECT * FROM tapu WHERE TCKimlikNo = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $tc);
$stmt->execute();
$result = $stmt->get_result();

// Sonuçları JSON olarak döndür
if ($result->num_rows > 0) {
    $data = [];

    while ($row = $result->fetch_assoc()) {
        $data[] = [
            'id' => $row['id'],
            'il' => $row['il'],
            'ilce' => $row['ilce'],
            'MahalleKoyAdi' => $row['MahalleKoyAdi'],
            'ZeminTip' => $row['ZeminTip'],
            'Ada' => $row['Ada'],
            'Parsel' => $row['Parsel'],
            'Yuzolcum' => $row['Yuzolcum'],
            'AnaTasinmazNitelik' => $row['AnaTasinmazNitelik'],
            'Adi' => $row['Adi'],
            'Soyadi' => $row['Soyadi'],
            'BabaAdi' => $row['BabaAdi'],
            'TCKimlikNo' => $row['TCKimlikNo'],
            'EdinmeSebebi' => $row['EdinmeSebebi'],
            'Tarih' => str_replace('/', '-', $row['Tarih']),
            'Yevmiye' => $row['Yevmiye']
        ];
    }

    // JSON verisini düzgün formatta döndür
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} else {
    echo json_encode(["error" => "No records found for this TC."]);
}

// Bağlantıyı kapatma
$stmt->close();
$conn->close();
?>
