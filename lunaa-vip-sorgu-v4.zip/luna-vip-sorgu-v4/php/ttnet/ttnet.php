<?php
header('Content-Type: application/json');

$host = 'localhost';
$db = 'ttnet';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Connection failed: " . $e->getMessage()], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

if (isset($_GET['gsm'])) {
    $gsm = preg_replace('/\D/', '', $_GET['gsm']); // Remove all non-digit characters
    $stmt = $pdo->prepare("SELECT * FROM ttnet WHERE REPLACE(REPLACE(REPLACE(GSM, ' ', ''), '-', ''), '(', '') = ?");
    $stmt->execute([$gsm]);
    $row = $stmt->fetch();

    if ($row) {
        echo json_encode(["status" => "success", "data" => $row], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(["status" => "error", "message" => "No results found"], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}
?>