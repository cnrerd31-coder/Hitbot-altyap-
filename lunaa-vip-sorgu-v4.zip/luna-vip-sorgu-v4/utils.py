# utils.py
import logging
from functools import wraps
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes
from config import BOT_NAME, CHANNEL_1, CHANNEL_2

logger = logging.getLogger("luna")


async def is_user_in_channels(uid, bot):
    for ch in (CHANNEL_1, CHANNEL_2):
        if not ch:
            continue
        try:
            m = await bot.get_chat_member(ch, uid)
            if m.status in ("member", "administrator", "creator"):
                continue
            return False, ch
        except Exception as e:
            logger.error(f"channel check {ch}: {e}")
    return True, None


def channel_join_kb():
    rows = []
    for c in (CHANNEL_1, CHANNEL_2):
        if c:
            rows.append([InlineKeyboardButton(f"📢 {c}", url=f"https://t.me/{c.lstrip('@')}")])
    rows.append([InlineKeyboardButton("✅ Katıldım, Kontrol Et", callback_data="chk_join")])
    return InlineKeyboardMarkup(rows)


def ensure_channel_join(func):
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *a, **kw):
        uid = update.effective_user.id if update.effective_user else None
        if not uid:
            return
        ok, ch = await is_user_in_channels(uid, context.bot)
        if not ok:
            txt = f"🌙 <b>{BOT_NAME}</b>\n\nKanallara katıl:\n📢 {CHANNEL_1}\n📢 {CHANNEL_2}"
            if update.callback_query:
                await update.callback_query.answer("Önce kanallara katıl!", show_alert=True)
                try:
                    await update.callback_query.message.reply_text(
                        txt, parse_mode=ParseMode.HTML, reply_markup=channel_join_kb())
                except Exception:
                    pass
            else:
                await update.message.reply_text(
                    txt, parse_mode=ParseMode.HTML, reply_markup=channel_join_kb())
            return
        return await func(update, context, *a, **kw)
    return wrapper